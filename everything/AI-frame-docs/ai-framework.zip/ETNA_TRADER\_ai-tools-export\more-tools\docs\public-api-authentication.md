# Public API Authentication

This document describes the Public API authentication strategy — username/password flow with token-based sessions.

> **See also:** [Authentication Overview](./authentication.md) for strategy selection, state management, and shared concepts.

---

## Overview

Public API authentication uses a direct username/password flow against the backend's `/token` endpoint. Credentials are sent in HTTP headers, and the API returns an access token on success.

**When used:** When `useKeyCloakAuth === false` in MobileSettings (default).

---

## Login Flow

1. **User enters credentials** on Sign In screen
2. **UI calls `useLoginMutation`** (React Query hook)
3. **Hook invokes `authService.signIn(credentials)`** (via DI)
4. **Repository calls API** (`POST /token` with username/password in headers)
5. **API returns tokens** (`{ Token, RefreshToken, State }`)
6. **Repository validates response** (only `State === "Succeeded"` supported)
7. **Hook saves tokens:**
   - `tokenStore.setToken(accessToken)` — writes to memory + SecureStore
   - `tokenStore.setAuthenticatedFlag(true)` — persists auth status
   - `setSession()` — updates Zustand (triggers UI reactivity)
8. **Navigation redirects** to authenticated stack (tabs)

**Why validate `State` field?**

The API may return other states (e.g., MFA required, password reset needed). This implementation only handles the simple success case. Future enhancements can add support for multi-step flows.

**Files:**
- Hook: `src/features/auth/hooks/queries.ts`
- Repository: `src/infrastructure/repositories/PublicApiAuthRepository.ts`
- Port: `src/domain/ports/IAuthService.ts`

---

## Logout Flow

1. **User triggers logout** (e.g., taps "Sign Out" button)
2. **UI calls `useLogoutMutation`** (React Query hook)
3. **Hook invokes `authService.logout()`** (via DI)
4. **Repository calls API** (`POST /logout`) — best effort, errors caught internally
5. **Hook always clears local state:**
   - `tokenStore.clearToken()` — removes token from memory + SecureStore + deletes authenticated flag
   - `clearSession()` — resets Zustand (triggers UI reactivity)
6. **Navigation redirects** to Sign In screen

**Note:** The authenticated flag is cleared by **deletion** from SecureStore (not by calling `setAuthenticatedFlag(false)`). When the flag is deleted, subsequent reads return `false` by default.

**Why "best effort" for API call?**

If the API call fails (network error, server down), we still clear local state. This ensures the user can always log out from the app, even if the server is unreachable.

**Files:**
- Hook: `src/features/auth/hooks/queries.ts`
- Repository: `src/infrastructure/repositories/PublicApiAuthRepository.ts`

---

## Error Handling

### Login Errors

- **Network failure** — Caught by React Query, displayed via `authError` in Zustand
- **Invalid credentials** — API returns 401, caught by mutation, stored in Zustand
- **Unsupported State** (e.g., MFA) — Repository throws error, displayed to user

### Logout Errors

- **API call fails** — Logged but not thrown; local state always cleared
- **SecureStore fails** — Logged in dev mode; app continues (fallback to in-memory)

---

## Comparison with Keycloak

| Aspect | Public API | Keycloak |
|--------|------------|----------|
| **Protocol** | Custom token endpoint | OAuth2/OIDC standard |
| **Login UI** | Username/password form (in-app) | OAuth redirect (system browser) |
| **Credentials** | Sent in headers (`Username`, `Password`) | Never leave identity provider |
| **Token Refresh** | Not supported | Automatic via refresh token |
| **SSO Support** | No | Yes |

See [Keycloak Authentication](./keycloak-authentication.md) for Keycloak details.

---

## File Reference

| Concept | File Path |
|---------|-----------|
| **Port (Interface)** | `src/domain/ports/IAuthService.ts` |
| **Repository** | `src/infrastructure/repositories/PublicApiAuthRepository.ts` |
| **Login/Logout Hooks** | `src/features/auth/hooks/queries.ts` |
| **Sign In Form** | `src/features/auth/components/SignInBaseForm.tsx` |

---

## Related Documentation

- **[Authentication Overview](./authentication.md)** — Strategy selection, state management, session restoration
- **[Keycloak Authentication](./keycloak-authentication.md)** — Alternative auth strategy
- **[HTTP Infrastructure](./http-infrastructure.md)** — Axios clients, interceptors, token injection
