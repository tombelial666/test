# Framework QA Rule

**Version**: 1.0.0 | **Scope**: ETNA_TRADER AI Framework

## Goal

Ensure that any structural change to the AI framework (skills, agents, rules, scripts) is validated against the integrity checklist before being finalized.

## When to Apply

- **IMMEDIATELY** after adding, editing, or deleting any file in `.claude/` or `.cursor/`
- After modifying `scripts/sync-configs.js` or `scripts/sync-docs.js`
- After adding or removing a skill, agent, or rule
- Before marking a framework-change task as done

## Mandatory Action

After any framework change, run the checklist:

1. Open `.claude/framework-qa/FRAMEWORK_QA_CHECKLIST.md`
2. Work through each applicable section
3. Fix all failed checks before finalizing
4. If sync scripts were touched: verify `.cursor/` mirrors `.claude/` correctly via `node scripts/sync-configs.js --fix`

## Checklist Sections

| Section | When to run |
|---|---|
| Skills integrity | Any skill added, edited, or removed |
| Agents integrity | Any agent added, edited, or removed |
| Rules integrity | Any rule added, edited, or removed |
| Sync integrity | After any `.claude/` or `.cursor/` change |
| Artifact discipline | After any skill that produces task outputs |
| Anti-hallucination | After any QA or generation skill change |
| Docs accuracy | After CLAUDE.md / AGENTS.md / FRAMEWORK_INDEX.md changes |

## Do Not Skip

Do not finalize a framework edit without a passing checklist review.
A broken skill or misrouted agent discovered after sync propagation requires rollback across all repos.
