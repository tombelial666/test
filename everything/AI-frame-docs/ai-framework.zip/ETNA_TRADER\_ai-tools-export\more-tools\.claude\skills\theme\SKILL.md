---
name: theme
description: "Theme system skill for the Mobile Lite App — color tokens, light/dark mode, brand switching. This skill should be used when adding colors or styles to any component, implementing dark/light mode support, switching themes programmatically, reviewing components for hardcoded colors, adding a new brand, or understanding theme resolution priority. CRITICAL: No hardcoded colors. Use useThemeColors() from @/shared/theme/hooks exclusively."
---

# Theme System

Complete guide to using the theme and color token system in Mobile Lite App.

Brand/file details → `references/brand-and-file-locations.md`

---

## Core Rule

**Never hardcode colors. Always use `useThemeColors()` from `@/shared/theme/hooks`.**

```tsx
import { useThemeColors } from '@/shared/theme/hooks';

export function MyComponent() {
  const colors = useThemeColors();

  return (
    <View style={{ backgroundColor: colors.background.base }}>
      <Text style={{ color: colors.text.base }}>Hello</Text>
    </View>
  );
}
```

**Styling rule** — layout in `StyleSheet.create`, colors always inline:

```tsx
// ✅ Correct
const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },  // NO colors here
});
<View style={[styles.container, { backgroundColor: colors.background.base }]}>

// ❌ Wrong — colors in StyleSheet won't update on theme change
const styles = StyleSheet.create({
  container: { backgroundColor: '#fff' },
});
```

---

## Token Reference

### Core Tokens

```tsx
const colors = useThemeColors();

// Backgrounds
colors.background.base          // Main app background
colors.background.secondary     // Cards, elevated surfaces
colors.background.tertiary      // Nested surfaces

// Text
colors.text.base                // Primary body text
colors.text.secondary           // Helper/muted text
colors.text.tertiary            // Placeholders, captions
colors.text.disabled            // Disabled state

// Borders & Icons
colors.border.base              // General dividers
colors.icon.base                // Default icons
colors.icon.secondary           // Inactive/muted icons
colors.icon.disabled            // Disabled icons
```

### Sentiment Tokens (`?.` optional chaining required)

```tsx
// Brand (primary actions)
colors.background.brand?.base   // Primary button background
colors.text.onbrand?.base       // Text ON brand background
colors.text.brand?.base         // Brand-colored text
colors.icon.brand?.base         // Active tab icon

// Danger (destructive actions)
colors.background.danger?.base  // Delete/logout button
colors.text.ondanger?.base      // Text ON danger background

// Success / Warning / Info
colors.background.success?.base
colors.text.onsuccess?.base
colors.background.warning?.base
colors.background.info?.base
```

### Component Tokens

```tsx
// Form fields
colors.field.border.base        // Default input border
colors.field.border.focus       // Focused input
colors.field.border.error       // Error state
colors.field.background.base    // Input background
colors.field.text.base          // Input text
colors.field.text.placeholder   // Placeholder text

// Cards
colors.card.background.base
colors.card.border.base
colors.card.background.hover
colors.card.background.selected

// Navigation
colors.leftnav.background.base
colors.leftnav.icon.active
colors.topnav.background.base
```

---

## Common Patterns

### Screen Layout

```tsx
<View style={[styles.screen, { backgroundColor: colors.background.base }]}>
  <Text style={[styles.title, { color: colors.text.base }]}>Title</Text>
  <Text style={{ color: colors.text.secondary }}>Subtitle</Text>
</View>
```

### Input Field with States

```tsx
const [focused, setFocused] = useState(false);
const hasError = !!errorMessage;

<TextInput
  style={[
    styles.input,
    {
      borderColor: hasError
        ? colors.field.border.error
        : focused
        ? colors.field.border.focus
        : colors.field.border.base,
      backgroundColor: colors.field.background.base,
      color: colors.field.text.base,
    }
  ]}
  placeholderTextColor={colors.field.text.placeholder}
  onFocus={() => setFocused(true)}
  onBlur={() => setFocused(false)}
/>
```

### Primary / Danger Buttons

```tsx
// Primary
<TouchableOpacity style={{ backgroundColor: colors.background.brand?.base }}>
  <Text style={{ color: colors.text.onbrand?.base }}>Submit</Text>
</TouchableOpacity>

// Danger
<TouchableOpacity style={{ backgroundColor: colors.background.danger?.base }}>
  <Text style={{ color: colors.text.ondanger?.base }}>Delete</Text>
</TouchableOpacity>
```

### Tab Bar

```tsx
tabBarActiveTintColor: colors.icon.brand?.base,
tabBarInactiveTintColor: colors.icon.secondary,
tabBarStyle: {
  backgroundColor: colors.background.base,
  borderTopColor: colors.border.base,
}
```

---

## Theme Switching

```tsx
import { useTheme } from '@/shared/theme/hooks';

const { theme, isDark, toggleTheme, setTheme } = useTheme();

setTheme('light');    // Force light
setTheme('dark');     // Force dark
setTheme(null);       // Auto — follow system
toggleTheme();        // Toggle light ↔ dark
```

**Priority**: Manual override (AsyncStorage) → System theme → Light (fallback)

---

## Testing with Theme

```tsx
import { ThemeProvider } from '@/shared/theme/ThemeProvider';

const wrapper = ({ children }: { children: React.ReactNode }) => (
  <ThemeProvider>{children}</ThemeProvider>
);

render(<MyComponent />, { wrapper });
```

---

## ADR Reference

- [ADR-0008: Design Tokens System](../../../docs/adr/0008-design-tokens-system.md) — decision context, token architecture, and rationale for the theme system design.
