# ADR-0006: Navigation Layout and Header Architecture

**Status**: Accepted  
**Date**: 2025-12-29

## Context

The app uses Expo Router (on top of React Navigation) and currently has a root `Stack` in `app/_layout.tsx` with `(auth)` and `(tabs)` route groups. However, the `(tabs)` group itself uses a `Stack` instead of a real bottom tab navigator, meaning there is no native Tab Bar behavior. We need to define a native-first navigation architecture for the authenticated area (tabs + per-tab stacks + header behavior) that uses official Expo Router / React Navigation APIs, supports configurable header modes, and does not conflict with existing providers and `AuthGate`.

## Use Cases

- **UC1**: Пользователь переключается между основными табами (Home, Social, Watchlist, Opinions, Profile) через Bottom Tab Bar; Tab Bar отображает активный таб, а на корневых экранах табов показывается Main Header (Account Selector + Search).
- **UC2**: Из корневого экрана таба пользователь переходит на вложенный экран (например, `home/holdings`), где Tab Bar скрывается, а Header переключается в Detail-режим (Back Arrow + контекстный заголовок); для конкретных экранов можно конфигурировать состав Header (скрыть Back, Search и т.п.).
- **UC3**: При нажатии Back на вложенном экране пользователь возвращается на корневой экран таба, Tab Bar снова показывается, а Header возвращается в Main-режим, без неожиданных переключений табов или выхода из приватной области.

## Options Considered

### Option 1: Root Stack with `(auth)` / `(tabs)` groups + Tabs layout inside `(tabs)` + Stack per tab

**Summary**  
Сохранить текущий корневой `Stack` с группами `(auth)` и `(tabs)` в `app/_layout.tsx`. Внутри `app/(tabs)/_layout.tsx` использовать `<Tabs>` из Expo Router (который под капотом создаёт `BottomTabNavigator`). Для каждого таба (Home, Social, Watchlist, Opinions, Profile) создать подпапку с собственным `_layout.tsx`, который объявляет `Stack` для вложенных экранов таба.

**Pros**:
- Соответствует рекомендациям Expo Router: разделение auth/app через route groups и использование `<Tabs>` на уровне группы для нижней навигации.
- Чёткое разделение concern’ов:  
  - root `Stack` управляет переключением между `(auth)` и `(tabs)`;  
  - `Tabs` отвечает за выбор активного таба;  
  - внутренние `Stack`-layout’ы управляют вложенной навигацией в пределах таба.
- Нативное поведение Back: внутри таба `Stack` обрабатывает переходы между корневым и вложенными экранами, аппаратная/gesture-навигация работает как ожидается.
- Простая поддержка deep linking: Expo Router может мапить URL на нужную таб-группу и nested stack без кастомных контейнеров.
- Удобная точка для конфигурации Header: можно отключить header на уровне `Tabs` и использовать только Stack headers с кастомным `header` (наш `AppHeader`), управляя режимами Main/Detail через `options`.

**Cons**:
- Большее количество `_layout.tsx` файлов (root + `(auth)` + `(tabs)` + один per tab), что немного повышает когнитивную нагрузку.
- Для скрытия Tab Bar на вложенных экранах потребуется аккуратная конфигурация (логика вида «показывать Tab Bar только на первом маршруте nested stack»), хотя это стандартный паттерн React Navigation.

### Option 2: Только Stack-навигация в `(tabs)` + кастомный Tab Bar как обычный компонент

**Summary**  
Сохранить `Stack` внутри `app/(tabs)/_layout.tsx` и реализовать нижний Tab Bar как обычный React-компонент (layout-обёртка или компонент в каждом корневом экране таба). Переходы между «табами» будут обычными `Stack`-переходами на разные корневые экраны, а состояние активного таба и видимость Tab Bar управляются вручную.

**Pros**:
- Минимальное изменение текущей структуры: остаётся `Stack` внутри `(tabs)`.
- Полный контроль над внешним видом Tab Bar без оглядки на ограничения `BottomTabNavigator`.

**Cons**:
- Нарушает критический принцип **native-first, out-of-the-box**:  
  - Tab Bar перестаёт быть навигационным контейнером;  
  - deep linking и восстановление состояния становятся сложнее (нужно самим решать, какой «таб» активен по URL/стеку).
- Ручное управление активным табом и состоянием Tab Bar (потребуется собственный стор или контекст), дублирование логики, риск расхождения с системным back-стеком.
- Сложнее интегрировать с существующей auth-навигацией и 401-редиректами: при редиректе на `(auth)` нужно будет дополнительно очищать кастомное состояние «табов».
- Будущие изменения навигации (новые табы, вложенные сценарии) будут дороже, чем при прямом использовании `Tabs`/`Stack` из React Navigation.

### Option 3: Root Tabs (вместо root Stack) + Stack per tab (auth как отдельный таб/экраны)

**Summary**  
Заменить корневой `Stack` на корневой `Tabs` (или комбинированный Tabs + Stack), где одна из вкладок или стеков отвечает за auth-флоу, а остальные — за приватную часть приложения.

**Pros**:
- Теоретически уменьшает уровень вложенности навигации (меньше групп).
- Может упростить сценарии, где auth и приватные экраны логически смешиваются (что не наш случай).

**Cons**:
- Противоречит текущему уже принятому паттерну разделения auth/privileged зон через `(auth)` и `(tabs)` и `AuthGate`.
- Усложняет навигацию при логауте / 401-редиректе: нужно будет явно «выкидывать» пользователя на auth-стек внутри Tabs.
- Смешивает сценарии, где пользователь не должен видеть Tab Bar до аутентификации, с приватной частью.
- Не даёт существенных преимуществ по сравнению с Option 1, но требует заметного рефакторинга текущей навигации.

### Header Architecture Options

#### Header Option A: Глобальный AppShell над всей навигацией

**Summary**  
Оборачиваем корневой `Stack` в компонент `AppShell`, который всегда смонтирован один раз и сам рендерит `AppHeader` поверх навигации. `AppShell` определяет режим Header (main/detail/auth/none) на основе `usePathname()` / `useSegments()` из Expo Router, а внутренняя навигация (`Stack`, `Tabs`, nested `Stack`’и) не знает о Header напрямую.

**Pros**:
- По-настоящему один экземпляр `AppHeader` для всего приложения (общий shell для `(auth)` и `(tabs)`).
- Легко сделать общий layout над навигацией (фон, декоративные элементы), не завязанный на конкретный навигатор.

**Cons**:
- Header оказывается «снаружи» системы навигации React Navigation:  
  - сложнее получать доступ к `navigation`/`route` и per-screen `options`;  
  - нельзя использовать стандартный механизм `headerShown` / `header` на уровне `Stack`/`Tabs` — приходится дублировать часть логики роутинга внутри `AppShell`.
- Скрытие Header для отдельных экранов (например, одни auth-экраны без Header, другие — с Header) придётся реализовывать своей логикой на основе URL/segments, а не через единый источник правды (`screenOptions`/`options`).
- Усложняется сопровождение: любая доработка навигации (новые группы, nested stacks) требует синхронного апдейта логики в `AppShell`, чтобы Header не «отставал» от фактического стека.

#### Header Option B: Общий `AppHeader` как кастомный header у root `Stack`

**Summary**  
Используем официальный API React Navigation: на корневом `Stack` в `app/_layout.tsx` задаём `screenOptions={{ header: (props) => <AppHeader {...props} /> }}`. Таким образом, для всех экранов в root `Stack` (и внутри `(auth)`, и внутри `(tabs)`) используется один и тот же компонент `AppHeader`. Каждый конкретный экран/группа через `options` / `navigation.setOptions()` выставляет `title`, режим (`headerMode: "main" | "detail" | "none"`), флаги `headerShown`, `showBack`, `showSearch`, `showAccountSelector` и т.п.

**Pros**:
- Остаёмся строго внутри модели React Navigation: Header управляется через `Stack` и его официальный API (`header`, `headerShown`, `options`), без самописных контейнеров поверх навигации.
- Один и тот же компонент `AppHeader` используется и для auth-экранов, и для экранов в `(tabs)`, при этом режим и состав элементов легко настраиваются per-screen через `options`.
- Скрытие Header для отдельных экранов тривиально:  
  - либо через `options={{ headerShown: false }}` на экране,  
  - либо через свой флаг (`headerMode: "none"`) и возврат `null` внутри `AppHeader`.
- Вся информация о текущем экране (`route`, `navigation`, `options`) приходит в `AppHeader` из React Navigation, не нужно самому разбирать URL/segments.

**Cons**:
- Header технически является частью root `Stack`, поэтому если мы когда-то добавим другой root navigator поверх (например, modal stack / drawer), придётся аккуратно обновлять конфигурацию, чтобы не дублировать header.
- Для специфичных случаев, где нужен *совсем другой* layout (например, полноэкранный auth-экран без всего shell UI), нужно явно помнить про `headerShown: false` или отдельный `headerMode`, иначе `AppHeader` всё равно смонтируется.

## Decision

For navigation structure we chose **Option 1: Root Stack with `(auth)` / `(tabs)` groups + Tabs layout inside `(tabs)` + Stack per tab** because it:
- Наиболее точно следует философии Expo Router и React Navigation (file-based routing + Tabs/Stack как навигационные контейнеры, а не кастомные компоненты).
- Чётко разделяет auth и приватную часть приложения (через `(auth)` / `(tabs)` и `AuthGate`), не ломая текущую архитектуру провайдеров.
- Позволяет нативно реализовать требуемое поведение Tab Bar и Header (Main vs Detail) через официальные `screenOptions` / `options` и кастомный `header`, без ручного управления стеком.

For header architecture we chose **Header Option B: Общий `AppHeader` как кастомный header у root `Stack`** because it:
- **Строится поверх официального API React Navigation**: мы используем `header` / `headerShown` / `options` у `Stack`, а не обходим навигацию и не дублируем логику роутинга в отдельном shell-компоненте, как в Option A.
- **Делает конфигурацию хедера декларативной и пер-скриновой**: каждый экран (в `(auth)` и `(tabs)`) явно описывает свои требования к хедеру через `options` (`headerMode`, `headerShown`, `showBack`, `showSearch`, `showAccountSelector`), и `AppHeader` просто читает эти поля; в Option A та же логика размазывается по разбору URL/segments в `AppShell`.
- **Надёжнее поддерживает сценарии “часть экранов с хедером, часть без”**: чтобы скрыть хедер на конкретном auth-экране достаточно `headerShown: false` или `headerMode: "none"`, это однотипно для всех экранов и не требует дополнительных условий в `AppShell`.
- **Лучше масштабируется**: добавление новых стэков/групп/экранов не требует правок в централизованном `AppShell`, достаточно сконфигурировать `options` нового экрана; риск расхождения между фактическим стеком навигации и логикой отображения хедера значительно ниже, чем в Option A.

## Consequences

- **Структура роутов**  
  - Корневой `Stack` в `app/_layout.tsx` остаётся и управляет только переключением между `(auth)` и `(tabs)`.  
  - Внутри `app/(tabs)/_layout.tsx` используется единый `<Tabs>`-навигатор, объявляющий пять табов (Home, Social, Watchlist, Opinions, Profile); этот Tabs и его Tab Bar создаются один раз для всей приватной части приложения и не пересоздаются при переходах между экранами внутри `(tabs)`.  
  - Внутри каждой папки таба (`app/(tabs)/home`, `app/(tabs)/social`, и т.д.) добавляется собственный `_layout.tsx` с `Stack`, где:  
    - `index.tsx` — корневой экран таба;  
    - дополнительные файлы (например, `holdings.tsx`) — вложенные экраны.

- **Tab Bar visibility (официальные средства)**  
  - Tab Bar принадлежит `Tabs`-навигации в `app/(tabs)/_layout.tsx`.  
  - Скрытие Tab Bar на вложенных экранах реализуем через официальный API `tabBarStyle` + `useSegments()` из Expo Router, без кастомных контейнеров:  
    - в `app/(tabs)/_layout.tsx` вычисляем `isNestedRoute(segments)` на основе `useSegments()`, где Tab Bar показывается только когда активен корневой экран таба (сегменты вида `["(tabs)", "<tab>"]`), а при наличии третьего сегмента (например, `["(tabs)", "home", "holdings"]`) считаем маршрут вложенным;  
    - в `screenOptions` передаём массив стилей для `tabBarStyle`, где базовый стиль делает Tab Bar абсолютно позиционированным внизу экрана, а при `isNestedRoute(segments)` добавляется стиль `tabBarHidden` с `transform` (бар «уезжает» за пределы экрана) и `opacity: 0`;  
    - такой подход использует только официальные средства (`Tabs`, `tabBarStyle`, `useSegments`) и решает проблему визуальных «прыжков» layout, которые возникали при прямом использовании `{ display: "none" }`.  
  - Для задач этой фичи достаточно логики вида: Tab Bar показывается на `home/index` (и аналогичных root-экранах табов) и скрывается при переходе на `home/holdings` и другие вложенные экраны.

- **Tab Bar UI (кастомизация внешнего вида)**  
  - Внешний вид нижнего таб бара может быть кастомизирован через `tabBar`/`tabBarComponent` (например, овальная/плавающая вью внизу экрана), при этом навигационное состояние (`state`, активная таба, переходы) по‑прежнему остаётся под управлением `Tabs`/React Navigation; архитектура навигации, описанная выше, это не ограничивает.

- **Header modes (Main vs Detail, официальные средства)**  
  - Header контролируется `Stack`-навигацией внутри каждого таба (не `Tabs`).  
  - На уровне `_layout.tsx` каждого таба мы используем `Stack` с `screenOptions` и/или per-screen `options`, чтобы задавать:  
    - `headerShown: true`;  
    - `header: (props) => <AppHeader {...props} mode="main" ... />` для корневых экранов таба;  
    - `header: (props) => <AppHeader {...props} mode="detail" showBack title={...} ... />` для вложенных экранов.  
  - Таким образом, переключение режимов Header и видимость отдельных элементов (Back Arrow, Account Selector, Search, правые action-кнопки) реализуется через официальный API Stack header (`header`, `headerTitle`, `headerLeft`) без ручного управления стеком или кастомных навигационных контейнеров.
  - Возможность полностью скрыть Back Arrow (например, на корневых экранах или спец-сценариях) обеспечивается через проп `showBack` в `AppHeader`, который мапится на наличие/отсутствие `headerLeft` / отрисовку кнопки назад.

- **Взаимодействие с существующей архитектурой**  
  - `AuthGate` по-прежнему управляет тем, попадает ли пользователь в `(auth)` или `(tabs)`; выбранная архитектура навигации внутри `(tabs)` не требует изменений в `AuthProvider`, `HttpProvider` и других composition-провайдерах.  
  - 401-редиректы из HTTP-слоя продолжают работать через `router.replace("/sign-in")`, что возвращает пользователя в `(auth)`; при этом стек внутри `(tabs)` сбрасывается естественным образом.

- **Follow-up actions**  
  - Реализовать структуру роутов и layout’ов согласно Option 1 (Tabs + Stack per tab) в `app/(tabs)` и подпапках.  
  - Спроектировать и внедрить `AppHeader` и конфигурацию header options (Main vs Detail, видимость Back/Account/Search) на уровне `_layout.tsx` для табов.  
  - Добавить интеграционные тесты для сценариев UC1–UC3, включая проверку Tab Bar visibility и Header mode переключений.  
  - Обновить соответствующий task-документ (Navigation Layout (Tab Bar + Header) — Research + Target Architecture), чтобы он ссылался на этот ADR как на источник истины по структуре навигации.


