# Bug Report: [Short Description]

**Date**: YYYY-MM-DD | **Reporter**: [name]
**Severity**: Critical / Major / Minor
**Status**: Open / In Progress / Fixed / Closed

---

## Summary
[One sentence describing the bug]

---

## Environment

- **Platform**: iOS / Android / Both
- **Expo SDK**: [version]
- **App Version**: [version]
- **Device**: [device model / simulator]
- **OS Version**: [iOS/Android version]
- **Brand**: [etna / sogo / other]

---

## Steps to Reproduce

1. [Step 1]
2. [Step 2]
3. [Step 3]

---

## Expected Behavior
[What should happen]

---

## Actual Behavior
[What actually happens]

---

## Screenshots / Logs
[Attach screenshots, error logs, or stack traces]

```
[error log here]
```

---

## Root Cause Analysis

_Filled during investigation_

**Root Cause**: [Description of what's causing the bug]

**Affected Files**:
- `src/features/...`
- `src/infrastructure/...`

**Layer**: feature / domain / infrastructure / shared / app

---

## Fix

**Branch**: `fix/[ticket-id]-[slug]`
**PR**: [URL]

**Solution**: [Brief description of the fix]

**Tests Added**:
- `tests/unit/...` — [what the test validates]
- `tests/integration/...` — [what the test validates]

---

## Verification

- [ ] Bug no longer reproducible on affected platforms
- [ ] Regression tests passing
- [ ] No new issues introduced
- [ ] TypeScript and lint clean
