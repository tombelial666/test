# React Native + Expo Rules

Detailed rules for building performant, crash-free mobile features in Mobile Lite App.
Load the relevant section(s) based on what you're working on.

> **New Architecture (enabled in this project):** `newArchEnabled: true`. Naked strings crash. `&&0` renders "0".

---

## 1. Core Rendering — CRITICAL

### Never use `&&` with falsy values

`&&` with `0`, `""`, `NaN` renders the falsy value as text in RN → **crash or visual bug**.

```tsx
// ❌ Renders "0" on screen
{items.length && <List items={items} />}

// ✅ Use ternary
{items.length > 0 ? <List items={items} /> : null}

// ✅ Or explicit boolean
{!!items.length && <List items={items} />}
```

### Always wrap text in `<Text>`

Naked strings outside `<Text>` **crash** when New Architecture is enabled:

```tsx
// ❌ Crash on New Architecture
<View>Hello World</View>

// ✅ Required
<View><Text>Hello World</Text></View>
```

### Conditional rendering

```tsx
// ❌ Can crash if condition changes to 0
{count && <Badge count={count} />}

// ✅ Explicit boolean
{count > 0 && <Badge count={count} />}
{isLoading ? <Spinner /> : <Content />}
```

---

## 2. List Performance — HIGH

### Use FlashList for large lists

```tsx
import { FlashList } from "@shopify/flash-list";

<FlashList
  data={items}
  renderItem={({ item }) => <ItemCard item={item} />}
  estimatedItemSize={80}  // Required: average item height in px
  keyExtractor={(item) => item.id}
/>
```

### Stable renderItem with useCallback

```tsx
// ❌ New function reference on every render → re-renders all items
<FlatList renderItem={({ item }) => <ItemCard item={item} />} />

// ✅ Stable reference
const renderItem = useCallback(
  ({ item }: { item: Item }) => <ItemCard item={item} />,
  []
);
<FlatList renderItem={renderItem} />
```

### Never use ScrollView + map() for long lists

```tsx
// ❌ Renders ALL items → slow + memory issues
<ScrollView>
  {items.map((item) => <ItemCard key={item.id} item={item} />)}
</ScrollView>

// ✅ Virtualized
<FlashList data={items} renderItem={renderItem} estimatedItemSize={80} />
```

### keyExtractor must be stable

```tsx
// ❌ Index as key → broken animations + re-renders
keyExtractor={(_, index) => String(index)}

// ✅ Stable ID
keyExtractor={(item) => item.id}
```

---

## 3. Scroll Performance — HIGH

### Never track scroll position in useState

```tsx
// ❌ Causes re-render on EVERY scroll event
const [scrollY, setScrollY] = useState(0);
<ScrollView onScroll={(e) => setScrollY(e.nativeEvent.contentOffset.y)} />

// ✅ Use Reanimated shared value (no re-renders)
import { useSharedValue } from 'react-native-reanimated';
const scrollY = useSharedValue(0);
const scrollHandler = useAnimatedScrollHandler((event) => {
  scrollY.value = event.contentOffset.y;
});
<Animated.ScrollView onScroll={scrollHandler} scrollEventThrottle={16} />
```

---

## 4. Navigation — HIGH

### Use native navigators from Expo Router

```tsx
// ✅ Native stack (iOS/Android native transitions)
import { Stack } from 'expo-router';
<Stack />

// ✅ Native tabs
import { Tabs } from 'expo-router';
<Tabs />

// Navigation
import { router } from 'expo-router';
router.push('/profile');
router.replace('/home');
router.back();
```

### Screen header configuration

```tsx
<Stack.Screen
  options={{
    title: t('screen.title'),
    headerShown: true,
    headerBackTitle: '',  // iOS: remove "Back" text
  }}
/>
```

---

## 5. Animation — HIGH

### Use Reanimated for GPU-accelerated animations

```tsx
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withTiming,
} from 'react-native-reanimated';

// Press animation
const scale = useSharedValue(1);

const animatedStyle = useAnimatedStyle(() => ({
  transform: [{ scale: scale.value }],
}));

const handlePress = () => {
  scale.value = withSpring(0.95, { damping: 15 });
};

<Animated.View style={animatedStyle}>
  <Pressable onPress={handlePress}>...</Pressable>
</Animated.View>
```

### Never animate with setState

```tsx
// ❌ JS thread animation — janky
const [opacity, setOpacity] = useState(1);
// Animating via setOpacity causes re-renders on every frame

// ✅ Reanimated — runs on UI thread
const opacity = useSharedValue(1);
opacity.value = withTiming(0, { duration: 300 });
```

---

## 6. State Management — MEDIUM

### Derive values instead of duplicate state

```tsx
// ❌ Duplicate state — can get out of sync
const [items, setItems] = useState<Item[]>([]);
const [count, setCount] = useState(0);

// ✅ Derive from source
const [items, setItems] = useState<Item[]>([]);
const count = items.length; // Derived — always in sync
```

### Minimize state variables

```tsx
// ❌ 3 booleans that can conflict
const [isLoading, setIsLoading] = useState(false);
const [isSuccess, setIsSuccess] = useState(false);
const [isError, setIsError] = useState(false);

// ✅ Single status
type Status = 'idle' | 'loading' | 'success' | 'error';
const [status, setStatus] = useState<Status>('idle');
```

---

## 7. User Interface — MEDIUM

### Safe area insets

```tsx
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const insets = useSafeAreaInsets();

<View style={{ paddingTop: insets.top, paddingBottom: insets.bottom }}>
  {/* content */}
</View>
```

### Image component

This repo does not currently include `expo-image`. Use `Image` from `react-native` unless `expo-image` is explicitly added.

```tsx
import { Image } from 'react-native';

<Image
  source={{ uri: user.avatar }}
  style={{ width: 50, height: 50, borderRadius: 25 }}
  resizeMode="cover"
/>
```

### Pressable feedback

```tsx
// ✅ Native feedback with reduced opacity
<Pressable
  style={({ pressed }) => [
    styles.button,
    { opacity: pressed ? 0.7 : 1 },
  ]}
  onPress={onPress}
>
  <Text>Press me</Text>
</Pressable>
```

---

## 8. Platform — MEDIUM

### Platform-specific styling

```tsx
import { Platform } from 'react-native';

const shadowStyle = Platform.select({
  ios: {
    shadowColor: colors.border.base,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  android: {
    elevation: 4,
  },
});
```

---

## External references

- [Expo Router Docs](https://expo.github.io/router/docs)
- [React Native Performance](https://reactnative.dev/docs/performance)
- [Reanimated Docs](https://docs.swmansion.com/react-native-reanimated/)
- [FlashList](https://shopify.github.io/flash-list/)
