# Pack an OOXML folder into a .docx file (ZIP).
# Default: sample-ooxml -> packed-output.docx next to this script.
# .\Pack-Docx.ps1
# .\Pack-Docx.ps1 -SourceDir "C:\path\to\ooxml" -OutputDocx "C:\path\out.docx"

param(
    [string] $SourceDir = "",
    [string] $OutputDocx = ""
)

$ErrorActionPreference = "Stop"

$base = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $SourceDir) {
    $SourceDir = Join-Path $base "sample-ooxml"
}
if (-not $OutputDocx) {
    $OutputDocx = Join-Path $base "packed-output.docx"
}

$src = Resolve-Path -LiteralPath $SourceDir
$dst = $OutputDocx

if (-not (Test-Path -LiteralPath $src)) {
    Write-Error "OOXML folder not found: $SourceDir"
}

if (Test-Path -LiteralPath $dst) {
    Remove-Item -LiteralPath $dst -Force
}

Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::CreateFromDirectory(
    $src,
    $dst,
    [System.IO.Compression.CompressionLevel]::Optimal,
    $false
)
Write-Host "Created:" $dst
