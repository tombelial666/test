# Keycloak Session Management Guide

## Understanding Keycloak Session Timeouts

Keycloak has multiple session timeout settings that control how long users can stay logged in. Understanding these is crucial for mobile app user experience.

---

## Session Timeout Settings in Keycloak

### 1. **Client Session Idle** (Sliding Window ✅)

**Location:** Realm Settings → Tokens → Client Session Idle

**Behavior:**
- Resets every time the user makes an API call
- If user is active, session extends automatically
- Like an "inactivity timeout"

**Example:**
```
Client Session Idle: 30 minutes

Timeline (user is active):
0 min   → Login
15 min  → API call → Session extends to 45 min
25 min  → API call → Session extends to 55 min
40 min  → API call → Session extends to 70 min
...continues as long as user is active
```

**Mobile App Impact:** ✅ Good for mobile apps - users stay logged in while actively using

---

### 2. **Client Session Max** (Hard Limit 🔒)

**Location:** Realm Settings → Tokens → Client Session Max

**Behavior:**
- ABSOLUTE maximum session duration from login time
- Does NOT reset on activity
- Hard cutoff regardless of user activity
- Forces re-authentication after this time

**Example:**
```
Client Session Max: 4 minutes

Timeline (even if user is active):
0 min   → Login
1 min   → Access token refreshed ✅
2 min   → Access token refreshed ✅
3 min   → Access token refreshed ✅
4 min   → LOGGED OUT ❌ (Client Session Max reached)
```

**Mobile App Impact:** ⚠️ Can be frustrating if too short - forces re-login

---

## Recommended Settings for Mobile Apps

### Scenario 1: Short-lived sessions (Banking, Finance)
```
Access Token Lifespan:     5 minutes
Client Session Idle:       15 minutes
Client Session Max:        2 hours
```

**Behavior:**
- User is logged out after 15 minutes of inactivity
- User is forced to re-login after 2 hours, even if active
- Good for high-security apps

---

### Scenario 2: Long-lived sessions (Social, Productivity)
```
Access Token Lifespan:     15 minutes
Client Session Idle:       30 days
Client Session Max:        90 days
```

**Behavior:**
- User stays logged in for 30 days if inactive (app closed)
- User forced to re-login after 90 days maximum
- Good for user experience, less secure

---

### Scenario 3: Balanced (Recommended for most apps)
```
Access Token Lifespan:     5 minutes
Client Session Idle:       7 days
Client Session Max:        30 days
```

**Behavior:**
- User logged out after 7 days of inactivity
- User forced to re-login after 30 days maximum
- Good balance of security and UX

---

## Current Issue with Your Settings

**Your current settings:**
```
Access Token Lifespan:     1 minute
Client Session Max:        4 minutes
```

**Problem:** Users are logged out after 4 minutes, even if actively using the app!

**Why it's problematic:**
- Very frustrating user experience
- User interrupted mid-task
- Not practical for mobile apps

---

## How Automatic Refresh Works

### With Current Implementation:

```
Keycloak Settings:
- Access Token: 1 min
- Client Session Max: 4 min

User Activity Timeline:
0:00  → Login (tokens stored)
0:30  → API call (access token valid)
1:00  → API call → 401 → Auto-refresh ✅ → Request succeeds
1:30  → API call (new access token valid)
2:00  → API call → 401 → Auto-refresh ✅ → Request succeeds
2:30  → API call (new access token valid)
3:00  → API call → 401 → Auto-refresh ✅ → Request succeeds
3:30  → API call (new access token valid)
4:00  → API call → 401 → Refresh fails (Client Session Max) ❌
      → User logged out → Redirected to sign-in
```

**Key Point:** The refresh token (controlled by Client Session Max) has a **fixed expiration time from login**, NOT a sliding window.

---

## Answering Your Questions

### Q1: "If I use the app for 2 hours, will tokens be updated?"

**Answer:** It depends on your Keycloak settings:

**Current settings (4 min max):**
- ❌ No - You'll be logged out after 4 minutes

**If you set Client Session Idle to 2 hours:**
- ✅ Yes - Tokens refresh automatically while you're active

**If you set Client Session Max to 2 hours:**
- ✅ Yes - But you'll be logged out at 2 hours even if active

---

### Q2: "If set to 30 days, will user stay logged in without login?"

**Answer:** Yes, but it depends on which setting:

**Client Session Idle = 30 days:**
```
✅ User stays logged in for 30 days after last activity
✅ If user opens app after 29 days, session extends
❌ If user doesn't use app for 30 days, must re-login
```

**Client Session Max = 30 days:**
```
✅ User stays logged in for up to 30 days
⚠️  After 30 days, FORCED re-login even if actively using
```

**Both set to 30 days:**
```
✅ Best of both worlds
✅ User logged out after 30 days inactivity OR 30 days maximum
```

---

## Security Considerations

### Long Session Times (30 days)

**Pros:**
- ✅ Great user experience
- ✅ No annoying re-logins
- ✅ Feels like native app (always "logged in")

**Cons:**
- ⚠️  If device is stolen, attacker has access for 30 days
- ⚠️  If token is compromised, longer window for abuse
- ⚠️  User password changes don't immediately revoke sessions

**Mitigations:**
- Use device biometrics (FaceID/TouchID) for sensitive actions
- Implement "sensitive action" re-authentication (e.g., before payments)
- Add ability to revoke sessions from account settings
- Monitor for suspicious activity

---

### Short Session Times (15 minutes)

**Pros:**
- ✅ More secure
- ✅ Compromised tokens expire quickly
- ✅ Password changes take effect faster

**Cons:**
- ❌ Poor user experience
- ❌ Users get interrupted mid-task
- ❌ Annoying for mobile apps

---

## Recommended Action

### For Your App:

1. **Increase Client Session Max** to reasonable time:
   ```
   Client Session Max: 7 days (or 30 days for better UX)
   ```

2. **Set Client Session Idle** for inactivity timeout:
   ```
   Client Session Idle: 7 days (user logged out if inactive)
   ```

3. **Keep Access Token short** for security:
   ```
   Access Token Lifespan: 5 minutes
   ```

### How to Configure in Keycloak:

1. Go to **Realm Settings** → **Tokens** tab
2. Find **Client Session Idle** → Set to `7 days` (or `30 days`)
3. Find **Client Session Max** → Set to `30 days` (or `90 days`)
4. **Save**

---

## Testing Your Settings

To verify token refresh is working:

1. Set short timeouts for testing:
   ```
   Access Token: 1 minute
   Client Session Idle: 10 minutes
   Client Session Max: 10 minutes
   ```

2. Login to the app

3. Make API calls every 30 seconds for 5 minutes
   - You should see refresh logs in console
   - Access token refreshes automatically

4. Wait 10 minutes without activity
   - Next API call should log you out
   - "Client Session Max" reached

5. After testing, set production values:
   ```
   Access Token: 5 minutes
   Client Session Idle: 7 days
   Client Session Max: 30 days
   ```

---

## Summary

| Setting | Purpose | Recommendation | Impact |
|---------|---------|----------------|--------|
| **Access Token Lifespan** | How often to refresh | 5-15 min | Security (short = more secure) |
| **Client Session Idle** | Inactivity timeout | 7-30 days | UX (long = stay logged in) |
| **Client Session Max** | Absolute maximum | 30-90 days | Security (long = more convenient) |

**Your current 4-minute max is NOT practical for mobile apps!** Increase to at least 7-30 days for good user experience.

---

## Related Documentation

- [Authentication](./authentication.md) - Token refresh implementation
- [HTTP Infrastructure](./http-infrastructure.md) - HTTP interceptors
- [State Management](./state-management.md) - Session state management
