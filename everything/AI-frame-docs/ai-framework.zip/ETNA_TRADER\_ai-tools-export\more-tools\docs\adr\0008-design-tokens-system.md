# ADR-0008: Design Tokens System

**Status**: Accepted
**Date**: 2026-02-06

## Context

The app currently has hardcoded colors scattered across components (#007AFF, #fff, rgb() values), making it difficult to maintain visual consistency, implement proper dark mode, or customize colors for white-label brands. We need a scalable design token system that:

- Eliminates hardcoded colors
- Provides full TypeScript typing with autocomplete
- Supports light/dark themes with system detection
- Works natively with Expo/React Native
- Enables brand-specific color customization
- Can be enforced via linting/pre-commit hooks

## Use Cases

- UC1: Developer adds new UI component - accesses colors via typed hook with autocomplete
- UC2: User switches light/dark mode - all colors update instantly
- UC3: Designer updates brand color - single source of truth propagates changes
- UC4: White-label deployment - brand-specific color values without code changes
- UC5: AI agent writes UI code - clear rules prevent hardcoded colors

## Options Considered

### Option 1: JSON Config from CDN (Dynamic Load)

**Description**: Store color tokens in JSON files hosted on CDN, fetched at app startup.

**Pros**:
- Colors updatable without app release
- Centralized management for multiple brands
- Non-developers can edit JSON files
- A/B testing of color schemes possible

**Cons**:
- ❌ **Offline support broken** - app fails without network on first launch
- ❌ **No TypeScript autocomplete** - JSON requires runtime parsing, no compile-time safety
- ❌ **Slower startup** - network fetch adds latency (200-500ms)
- ❌ **Bundle size overhead** - requires HTTP client, JSON parser, fallback logic
- ❌ **Hot-reload broken** - developers can't see color changes instantly during development
- ❌ **Versioning complexity** - CDN cache invalidation, version mismatches
- ❌ **Single point of failure** - CDN outage = broken app colors

**Evaluation**: ❌ Fails offline requirement and TypeScript typing requirement

---

### Option 2: In-App Typed Tokens (Static TypeScript Objects)

**Description**: Define color tokens as TypeScript objects in `src/shared/theme/tokens/`, import directly in code.

**Pros**:
- ✅ **Full TypeScript support** - autocomplete, type safety, compile-time errors
- ✅ **Offline by default** - colors bundled with app, no network needed
- ✅ **Zero latency** - no startup fetch, instant access
- ✅ **Hot-reload works** - Metro bundler reloads on file changes
- ✅ **Minimal bundle size** - just JavaScript objects (~5-10KB for full token set)
- ✅ **Git-based versioning** - colors tracked in source control
- ✅ **Brand customization** - different color files per brand in `src/shared/brand/*/colors.ts`
- ✅ **Lint-able** - ESLint can enforce token usage vs hardcoded colors
- ✅ **Simple architecture** - no HTTP layer, no runtime parsing

**Cons**:
- Color updates require app release (acceptable for native apps)
- Developers must edit TypeScript files (this is standard for native dev)

**Evaluation**: ✅ Meets all requirements perfectly

---

### Option 3: Library (tamagui, nativewind, dripsy)

**Description**: Use third-party design system library for theming.

**Libraries Evaluated**:
- **tamagui**: React Native UI kit with theming (~500KB)
- **nativewind**: Tailwind CSS for React Native (~200KB)
- **dripsy**: Responsive theming system (~100KB)

**Pros**:
- Pre-built theming infrastructure
- Community support and documentation
- May include additional UI components

**Cons**:
- ❌ **Large bundle size** - 100-500KB vs 5-10KB for custom solution
- ❌ **Learning curve** - team must learn library-specific APIs
- ❌ **Over-engineering** - we only need color tokens, not full UI kit
- ❌ **Vendor lock-in** - hard to migrate away from library patterns
- ❌ **Update dependencies** - library bugs/breaking changes out of our control
- ❌ **May not support exact naming convention** - our hierarchy is specific (location.compound.component.usage.sentiment.prominence-interaction)
- ❌ **White-label complexity** - libraries may not support brand-specific token overrides easily

**Evaluation**: ❌ Too much overhead for our specific needs

---

## Decision

We chose **Option 2: In-App Typed Tokens** because:

1. **Meets all requirements**: TypeScript typing, offline support, hot-reload, minimal bundle size, white-label ready
2. **Best DX**: Autocomplete, compile-time safety, instant feedback
3. **Simplest architecture**: No network layer, no external dependencies
4. **Full control**: Custom naming convention, brand overrides, linting rules
5. **Native-first**: Designed for Expo/React Native from the ground up

## Consequences

### What Becomes Easier

- **Type safety**: TypeScript prevents typos and invalid token names at compile time
- **Refactoring**: Rename tokens with confidence using IDE find-replace
- **Consistency**: Single source of truth ensures visual consistency
- **Dark mode**: Light/dark variants defined side-by-side in token files
- **White-label**: Brand-specific colors in `src/shared/brand/*/colors.ts` with same structure
- **Debugging**: Stack traces point directly to token usage in code
- **Code review**: PRs show exact color changes in git diff

### What Becomes Harder

- **Color updates**: Require app release (but this is standard for native apps)
- **Non-dev edits**: Designers must communicate with developers for color changes (acceptable trade-off)

### Follow-up Actions

1. Create token type definitions following naming convention
2. Define light/dark theme token values
3. Implement `useThemeColors()` hook for accessing tokens
4. Create pre-commit hook to block hardcoded colors
5. Write documentation and AI agent rules
6. Refactor existing components to use tokens

## Implementation Architecture

See [docs/design-tokens.md](../design-tokens.md) for file structure, usage examples, token reference, and migration guide.

## Related Decisions

- ADR-0006: Navigation Layout and Header Architecture - colors will integrate with header theming
- White-label configuration (docs/white-label-configuration.md) - brand color files align with brand assets structure
