# Localization (i18n) Guide

This document describes how to use, extend, and maintain the internationalization system in the mobile app.

**ADR Reference**: [ADR-0009: Localization Strategy](./adr/0009-localization-strategy.md)

---

## Supported Languages

| Locale | Language |
|--------|----------|
| `en` | English (default, source of truth) |
| `es` | Spanish |
| `zh-TW` | Chinese (Traditional) |
| `zh-CN` | Chinese (Simplified) |
| `ru` | Russian |
| `fr` | French |

---

## Using Translations in Components

### Basic Usage

```tsx
import { useTranslation } from "react-i18next";

function MyComponent() {
  const { t } = useTranslation();

  return <Text>{t("profile.language")}</Text>;
}
```

### With Namespace

```tsx
const { t } = useTranslation("common"); // default namespace
const label = t("languages.english"); // "English"
```

### Interpolation

```tsx
// Translation file:
// "greeting": "Hello, {{name}}!"

t("greeting", { name: "Alice" }); // "Hello, Alice!"
```

---

## Translation File Structure

All translation files live in:

```
src/shared/localization/locales/
├── en/
│   └── common.json      ← SOURCE OF TRUTH
├── es/
│   └── common.json
├── zh-TW/
│   └── common.json
├── zh-CN/
│   └── common.json
├── ru/
│   └── common.json
└── fr/
    └── common.json
```

### Adding a New Translation Key

1. Add the key to `en/common.json` first (source of truth):
   ```json
   {
     "myFeature": {
       "newKey": "New text in English"
     }
   }
   ```

2. Add the same key to all other language files:
   ```json
   // es/common.json
   { "myFeature": { "newKey": "Nuevo texto en español" } }

   // zh-TW/common.json
   { "myFeature": { "newKey": "新的繁體中文文字" } }

   // zh-CN/common.json
   { "myFeature": { "newKey": "新的简体中文文字" } }

   // ru/common.json
   { "myFeature": { "newKey": "Новый текст на русском" } }

   // fr/common.json
   { "myFeature": { "newKey": "Nouveau texte en français" } }
   ```

3. Run validation to confirm all keys are in sync:
   ```bash
   npm run i18n:validate-keys
   ```

---

## Adding a New Language

1. Create locale directory: `src/shared/localization/locales/<locale-code>/`
2. Add `common.json` with all keys from `en/common.json` translated
3. Update `SUPPORTED_LOCALES` in `src/shared/localization/utils.ts`:
   ```ts
   export const SUPPORTED_LOCALES: SupportedLocale[] = [
     "en", "es", "zh-TW", "zh-CN", "ru", "fr",
     "de", // ← add new locale
   ];
   ```
4. Update `SupportedLocale` type in `src/store/slices/localization.slice.ts`:
   ```ts
   export type SupportedLocale = "en" | "es" | "zh-TW" | "zh-CN" | "ru" | "fr" | "de";
   ```
5. Add locale mapping in `mapToSupportedLocale()` in `utils.ts` if needed
6. Add resource bundle in `src/shared/localization/i18n.ts`
7. Add language option in `LanguageSelector.tsx`

---

## Changing Language Programmatically

```tsx
import { useStore } from "@/store";

function MyComponent() {
  const setLocale = useStore((state) => state.setLocale);

  const handleLanguageChange = async () => {
    await setLocale("es"); // Updates store + AsyncStorage + i18n
  };
}
```

---

## Validation Scripts

### Check for hardcoded text

```bash
npm run i18n:validate-hardcoded
```

Scans `src/features/` for hardcoded UI text that should use `t()`.
**Exit 1** = violations found → must fix before committing.

### Check translation key consistency

```bash
# Warning mode (allows commit, shows warnings)
npm run i18n:validate-keys

# Strict mode (blocks if keys missing — used in CI/CD)
npm run i18n:validate-keys:strict
```

### Run all validations

```bash
npm run i18n:validate          # hardcoded + keys (warning mode)
npm run i18n:validate:strict   # hardcoded + keys (strict mode, used in CI/CD)
```

---

## CI/CD Integration

The `prebuild` script runs validation automatically before building:

```json
"prebuild": "npm run i18n:validate"
```

For CI/CD pipelines, use strict mode to block deployments with incomplete translations:

```bash
# In CI/CD pipeline
npm run i18n:validate:strict
```

---

## Pre-commit Hook (Husky not configured)

Husky is not currently set up in this project. To add pre-commit validation manually:

1. Install Husky: `npm install --save-dev husky`
2. Initialize: `npx husky init`
3. Add hook: `echo "npm run i18n:validate-hardcoded" > .husky/pre-commit`

The hook will block commits containing hardcoded text.

---

## Architecture

The localization system follows the project's layered architecture:

| Layer | File | Responsibility |
|-------|------|----------------|
| **Store** | `src/store/slices/localization.slice.ts` | Global locale state, persistence |
| **Shared** | `src/shared/localization/i18n.ts` | i18next configuration |
| **Shared** | `src/shared/localization/utils.ts` | Locale mapping utilities |
| **Shared** | `src/shared/localization/locales/` | Translation JSON files |
| **Composition** | `src/composition/LocalizationProvider.tsx` | Initialization on app start |
| **Features** | `src/features/profile/components/LanguageSelector.tsx` | Language selection UI |

### Provider Placement

```tsx
<AppInitializationProvider>
  <LocalizationProvider>  ← Initializes locale after app startup
    <AuthProvider>
      ...
```

---

## Rules for AI Agents

- **NEVER** hardcode UI text in components — always use `t("key")`
- **ALWAYS** add new keys to ALL 6 language files simultaneously
- **English (`en`)** is the source of truth — all other locales must have identical keys
- Run `npm run i18n:validate` after adding/changing translation keys
- See [ADR-0009](./adr/0009-localization-strategy.md) for architectural decisions
