# Documentation

This folder contains detailed technical documentation for the mobile app project.

## 📖 Documentation Index

### Architecture & Structure
- **[Project Structure](./project-structure.md)** - Complete directory layout, import boundaries, naming conventions, and how to add new features

### Authentication & Security
- **[Authentication](./authentication.md)** - Overview: strategy selection, state management, session restoration, design decisions
  - **[Public API Authentication](./public-api-authentication.md)** - Username/password login/logout flows
  - **[Keycloak Authentication](./keycloak-authentication.md)** - OAuth2/OIDC flow, PKCE, token refresh, configuration
  - **[Keycloak Session Management](./keycloak-session-management.md)** - Session timeouts, Client Session Idle vs Max, recommended settings

### Infrastructure
- **[HTTP Infrastructure](./http-infrastructure.md)** - Axios client setup, authentication, interceptors, token management, and API integration patterns

### Development Practices
- **[Testing Guide](./testing-guide.md)** - Testing strategy, unit vs integration tests, factories, mocking, and best practices

### Configuration
- **[Environment Variables](./environment-variables.md)** - All environment variables, API configuration, and setup guide
- **[White-Label Configuration](./white-label-configuration.md)** - Multi-brand setup, asset management, environment configuration

### Decision Records
- **[ADR (Architecture Decision Records)](./adr/README.md)** - Technical decisions with context, alternatives, and rationale

---

## Quick Start

For a high-level overview and quick reference, see [AGENTS.md](../AGENTS.md) or [Claude.md](../Claude.md) in the project root.

## Contributing

When adding new documentation:
1. Keep files focused on a single topic
2. Use clear headings and code examples
3. Update this README with links to new docs
4. Cross-reference related documentation where appropriate

