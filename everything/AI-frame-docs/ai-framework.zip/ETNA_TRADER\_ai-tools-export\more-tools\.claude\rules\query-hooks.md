# React Query Hooks Pattern

## Overview

Each feature has a `hooks/queries.ts` file containing React Query hooks for API data fetching. This centralizes query logic, keys, and cache management.

## File Location

```
src/features/<feature>/hooks/queries.ts
```

## Structure

```ts
// features/portfolio/hooks/queries.ts
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useApi } from "@/composition/ApiProvider";

// 1. Query keys — centralized for easy invalidation
export const portfolioKeys = {
  all: ["portfolio"] as const,
  positions: () => [...portfolioKeys.all, "positions"] as const,
  position: (id: string) => [...portfolioKeys.all, "position", id] as const,
};

// 2. Query hooks
export function usePositionsQuery() {
  const { portfolioService } = useApi();
  return useQuery({
    queryKey: portfolioKeys.positions(),
    queryFn: () => portfolioService.getPositions(),
  });
}

export function usePositionQuery(id: string) {
  const { portfolioService } = useApi();
  return useQuery({
    queryKey: portfolioKeys.position(id),
    queryFn: () => portfolioService.getPosition(id),
    enabled: !!id,
  });
}

// 3. Mutation hooks with cache invalidation
export function useClosePositionMutation() {
  const { portfolioService } = useApi();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (id: string) => portfolioService.closePosition(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: portfolioKeys.all });
    },
  });
}
```

## Cross-Feature Query Usage

When a feature needs data from another feature's domain, **import the query hook from the owning feature**:

```ts
// features/trading/screens/PlaceOrderScreen.tsx
import { usePositionsQuery } from "@/features/portfolio/hooks/queries";
import { useOrdersQuery } from "../hooks/queries";
```

**Rule**: Query hooks live in the feature that "owns" the data. Other features import them.

## When to Create Query Hooks

| Situation | Recommendation |
|-----------|----------------|
| Query used in **1 place** | Inline `useQuery` in component is OK |
| Query used in **2-3 places** | Consider creating a shared hook |
| Query used in **3+ places** | Create shared hook in `queries.ts` |
| Complex invalidation logic | Create shared mutation hook |
| Need optimistic updates | Create shared mutation hook |

## Naming Conventions

- **Query hooks**: `use<Entity>Query`, `use<Entity>sQuery` (plural for lists)
- **Mutation hooks**: `use<Action><Entity>Mutation`
- **Query keys**: `<feature>Keys` object with factory functions

## Cache Invalidation

Always invalidate related queries after mutations:

```ts
export function usePlaceOrderMutation() {
  const { orderService } = useApi();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: PlaceOrderInput) => orderService.placeOrder(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: orderKeys.all });
      queryClient.invalidateQueries({ queryKey: portfolioKeys.positions() });
      queryClient.invalidateQueries({ queryKey: ["balance"] });
    },
  });
}
```
