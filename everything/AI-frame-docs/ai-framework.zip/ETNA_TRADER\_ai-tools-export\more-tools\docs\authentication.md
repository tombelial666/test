# Authentication

This document provides a high-level overview of authentication in the mobile app. For strategy-specific details, see:

- **[Public API Authentication](./public-api-authentication.md)** — Username/password flow with token-based sessions
- **[Keycloak Authentication](./keycloak-authentication.md)** — OAuth2/OIDC flow with SSO support
- **[Keycloak Session Management](./keycloak-session-management.md)** — Session timeouts and recommended settings

---

## Two Auth Strategies

The app implements two authentication strategies:

1. **Public API Authentication** — Direct username/password against backend `/token` endpoint
2. **Keycloak Authentication** — OAuth2/OIDC Authorization Code Flow with PKCE via system browser

The `useKeyCloakAuth` flag in `MobileSettings` determines which strategy to use. The `AuthProvider` selects the appropriate implementation at runtime.

**Why two strategies?**

Different deployments have different identity requirements:
- **Public API** — Direct authentication for simple deployments
- **Keycloak** — Enterprise SSO scenarios with centralized identity management (SSO, social login, MFA, RBAC)

---

## Auth Strategy Selection

The `AuthProvider` reads `settings.useKeyCloakAuth` from Zustand store:
- **`false`** → `PublicApiAuthRepository`
- **`true`** → `KeycloakAuthRepository`

Both implementations share the same `IAuthService` interface, enabling seamless switching without affecting feature code. The `AuthProvider` is the only component aware of concrete implementations.

**File:** `src/composition/AuthProvider.tsx`

---

## State Management

Authentication state lives in **three layers**, each serving a distinct purpose:

### 1. SecureStore (Persistent Storage)

- Encrypted native storage provided by Expo
- Stores: token string + authenticated boolean flag
- Survives app restarts; enables automatic session restoration
- Accessed on app startup (bootstrap) and during login/logout

### 2. TokenStore (In-Memory Singleton)

- Caches token in memory, syncs with SecureStore
- Provides fast synchronous access for HTTP interceptors
- Pattern: read from memory (fast), write to memory + SecureStore (fire-and-forget)

**File:** `src/infrastructure/http/core/TokenStore.ts`

### 3. Zustand Session Slice (UI Reactivity)

- Global app state: `isAuthenticated`, `authError`
- Enables React components to reactively respond to auth state changes
- Set on login, cleared on logout, restored on startup

**File:** `src/store/slices/session.slice.ts`

**Why three layers?**
- **SecureStore** = persistence (survives restarts)
- **TokenStore** = performance (synchronous access for interceptors)
- **Zustand** = reactivity (UI updates automatically)

---

## Session Restoration

Session restoration happens on app startup in two phases:

### Phase 1: TokenStore Bootstrap (HttpProvider)
- Loads token from SecureStore to in-memory cache
- Happens once before any other providers

**File:** `src/composition/HttpProvider.tsx`

### Phase 2: Session Restoration (AppInitializationProvider)

1. **Call `restoreSession` use-case:**
   - Check `authenticated` flag from SecureStore
   - Check token from TokenStore (in-memory)
   - If both exist → `setSession()` (restores Zustand session)
   - Otherwise → `clearSession()` (ensures clean state)
2. **Fetch mobile settings** (including `useKeyCloakAuth` flag)
3. **Show app UI** once initialization completes

**Why check both flag and token?** The authenticated flag is a faster check than validating the token. If the flag is `false` or the token is missing, we skip restoration.

**Files:**
- Use-case: `src/application/auth/restoreSession.ts`
- Orchestration: `src/composition/AppInitializationProvider.tsx`

---

## 401 Handling (Automatic Logout)

The HTTP client includes a response interceptor that detects 401 responses:

1. **API returns 401** (token expired or invalid)
2. **If Keycloak auth**: interceptor attempts token refresh first (see [Keycloak Authentication](./keycloak-authentication.md#5-token-refresh-automatic))
3. **If refresh fails or not available**: clears auth state and redirects to `/sign-in`

**File:** `src/infrastructure/http/core/httpClients.ts`

---

## Key Design Decisions

### Why Not Store Tokens in Zustand Alone?

**Problem:** Zustand resets on app restart (in-memory only).
**Solution:** SecureStore persists tokens across restarts.

### Why Separate Authenticated Flag from Token?

**Problem:** Token validation is expensive (requires parsing/decoding).
**Solution:** Boolean flag provides fast check: "does user have a valid session?"

### Why Repository Doesn't Throw on Logout Errors?

**Problem:** If logout API fails, user is stuck in logged-in state.
**Solution:** Repository catches errors. Caller always clears local state (security-first).

### Why Pass Services to Zustand Actions (DI)?

**Problem:** Slices importing repositories breaks layer boundaries (store -> infrastructure).
**Solution:** Actions receive services as parameters, passed by composition layer.

---

## Error Handling

### Login Errors

- **Network failure** — Caught by React Query, displayed via `authError` in Zustand
- **Invalid credentials** — API returns 401, caught by mutation, stored in Zustand
- **Unsupported State** (e.g., MFA) — Repository throws error, displayed to user

### Logout Errors

- **API call fails** — Logged but not thrown; local state always cleared
- **SecureStore fails** — Logged in dev mode; app continues (fallback to in-memory)

### Session Restoration Errors

- **SecureStore unavailable** — Logged; token set to `null`; app continues
- **Token corrupted** — Cleared during bootstrap; user must re-authenticate

---

## File Reference

| Concept | File Path |
|---------|-----------|
| **Port (Interface)** | `src/domain/ports/IAuthService.ts` |
| **Public API Repository** | `src/infrastructure/repositories/PublicApiAuthRepository.ts` |
| **Keycloak Repository** | `src/infrastructure/repositories/KeycloakAuthRepository.ts` |
| **Keycloak Config** | `src/shared/config/keycloakConfig.ts` |
| **Token Storage** | `src/infrastructure/http/core/TokenStore.ts` |
| **Token Refresh** | `src/infrastructure/http/core/tokenRefresh.ts` |
| **Session Slice** | `src/store/slices/session.slice.ts` |
| **Public API Hooks** | `src/features/auth/hooks/queries.ts` |
| **Keycloak Hooks** | `src/features/auth/hooks/keycloakQueries.ts` |
| **Strategy Selection** | `src/composition/AuthProvider.tsx` |
| **Session Restoration** | `src/application/auth/restoreSession.ts` |
| **Orchestration** | `src/composition/AppInitializationProvider.tsx` |
| **Token Bootstrap** | `src/composition/HttpProvider.tsx` |
| **401 Interceptor** | `src/infrastructure/http/core/httpClients.ts` |
| **Sign In (Public API)** | `src/features/auth/components/SignInBaseForm.tsx` |
| **Sign In (Keycloak)** | `src/features/auth/components/SignInKeycloakForm.tsx` |
| **OAuth Callback** | `app/(auth)/callback.tsx` |
| **Auth Layout** | `app/(auth)/_layout.tsx` |
| **AuthGate** | `src/features/auth/components/AuthGate.tsx` |

---

## Related Documentation

- **[Public API Authentication](./public-api-authentication.md)** — Login/logout flows, error handling
- **[Keycloak Authentication](./keycloak-authentication.md)** — OAuth flow, token refresh, configuration
- **[Keycloak Session Management](./keycloak-session-management.md)** — Session timeouts, recommended settings
- **[HTTP Infrastructure](./http-infrastructure.md)** — Axios clients, interceptors, token injection
- **[State Management](./state-management.md)** — React Query vs Zustand patterns
- **[Project Structure](./project-structure.md)** — Layer boundaries and DI patterns
