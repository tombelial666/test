#!/usr/bin/env node

/**
 * Hardcoded Color Detection Script
 *
 * Detects hardcoded hex/rgb/rgba color values in TypeScript/JavaScript files.
 * Excludes token definition files, tests, and configuration files.
 *
 * Exit codes:
 * - 0: No violations found
 * - 1: Hardcoded colors detected
 */

const fs = require('fs');
const { execSync } = require('child_process');

// Regex patterns for detecting hardcoded colors
const HEX_COLOR_PATTERN = /#([0-9A-Fa-f]{3}){1,2}\b/g;
const RGB_PATTERN = /rgb\s*\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*\)/g;
const RGBA_PATTERN = /rgba\s*\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*,\s*[\d.]+\s*\)/g;
const NAMED_COLORS_PATTERN = /(?:^|[^\w-])(?:color|backgroundColor|borderColor|tintColor|placeholderTextColor)\s*[:=]\s*["'](?:red|blue|green|white|black|yellow|orange|purple|pink|gray|grey|brown|cyan|magenta|lime|olive|navy|teal|aqua|maroon|silver|fuchsia|indigo|violet|gold)["']/gi;

// Files and directories to exclude from checking
const EXCLUDE_PATTERNS = [
  // Token definition files
  /src\/shared\/theme\/tokens\//,
  /src\/shared\/theme\/colors\.[jt]s$/,  // Old colors file
  /src\/shared\/brand\/.*\/colors\.[jt]sx?$/,

  // Configuration files
  /tailwind\.config\.[jt]s$/,
  /\.config\.[jt]s$/,

  // Test files
  /\.(test|spec)\.[jt]sx?$/,
  /__tests__\//,
  /tests\//,

  // Build/dependency directories
  /node_modules\//,
  /\.expo\//,
  /\.next\//,
  /dist\//,
  /build\//,
  /coverage\//,

  // This script itself
  /check-hardcoded-colors\.(c?js)$/,
];

// Allowlist: Comments and specific contexts where colors are acceptable
const ALLOWLIST_CONTEXTS = [
  /\/\/.+/g,   // Single-line comments
  /\/\*.+?\*\//gs,  // Multi-line comments
];

/**
 * Check if file should be excluded from checking
 */
function shouldExcludeFile(filePath) {
  return EXCLUDE_PATTERNS.some(pattern => pattern.test(filePath));
}

/**
 * Get all staged files (git diff --cached) or all tracked files
 */
function getFilesToCheck(stagedOnly = false) {
  try {
    const command = stagedOnly
      ? 'git diff --cached --name-only --diff-filter=ACMR'
      : 'git ls-files';

    const output = execSync(command, { encoding: 'utf-8' });
    const files = output.trim().split('\n').filter(Boolean);

    // Filter for TypeScript/JavaScript files
    return files.filter(file => {
      return (
        /\.[jt]sx?$/.test(file) &&
        !shouldExcludeFile(file) &&
        fs.existsSync(file)
      );
    });
  } catch (error) {
    console.error('Error getting files:', error.message);
    return [];
  }
}

/**
 * Remove allowlisted contexts from content
 */
function removeAllowlistedContent(content) {
  let cleaned = content;
  ALLOWLIST_CONTEXTS.forEach(pattern => {
    cleaned = cleaned.replace(pattern, '');
  });
  return cleaned;
}

/**
 * Check file for hardcoded colors
 */
function checkFile(filePath) {
  const content = fs.readFileSync(filePath, 'utf-8');
  const lines = content.split('\n');
  const cleanedContent = removeAllowlistedContent(content);

  const violations = [];

  // Check for hex colors
  let match;
  while ((match = HEX_COLOR_PATTERN.exec(cleanedContent)) !== null) {
    const lineNumber = content.substring(0, match.index).split('\n').length;
    const line = lines[lineNumber - 1];
    violations.push({
      file: filePath,
      line: lineNumber,
      type: 'HEX',
      value: match[0],
      context: line.trim(),
    });
  }

  // Check for RGB colors
  while ((match = RGB_PATTERN.exec(cleanedContent)) !== null) {
    const lineNumber = content.substring(0, match.index).split('\n').length;
    const line = lines[lineNumber - 1];
    violations.push({
      file: filePath,
      line: lineNumber,
      type: 'RGB',
      value: match[0],
      context: line.trim(),
    });
  }

  // Check for RGBA colors
  while ((match = RGBA_PATTERN.exec(cleanedContent)) !== null) {
    const lineNumber = content.substring(0, match.index).split('\n').length;
    const line = lines[lineNumber - 1];
    violations.push({
      file: filePath,
      line: lineNumber,
      type: 'RGBA',
      value: match[0],
      context: line.trim(),
    });
  }

  // Check for named colors
  while ((match = NAMED_COLORS_PATTERN.exec(cleanedContent)) !== null) {
    const lineNumber = content.substring(0, match.index).split('\n').length;
    const line = lines[lineNumber - 1];
    violations.push({
      file: filePath,
      line: lineNumber,
      type: 'NAMED',
      value: match[0],
      context: line.trim(),
    });
  }

  return violations;
}

/**
 * Main execution
 */
function main() {
  const args = process.argv.slice(2);
  const stagedOnly = args.includes('--staged');
  const verbose = args.includes('--verbose');

  if (args.includes('--help')) {
    console.log(`
Usage: node check-hardcoded-colors.js [options]

Options:
  --staged    Check only staged files (for pre-commit hook)
  --verbose   Show detailed output
  --help      Show this help message

Description:
  Detects hardcoded color values (hex, rgb, rgba, named colors) in source files.
  Excludes token definitions, tests, and configuration files.

Exit codes:
  0 - No violations found
  1 - Hardcoded colors detected
`);
    process.exit(0);
  }

  console.log('🔍 Checking for hardcoded colors...\n');

  const files = getFilesToCheck(stagedOnly);

  if (files.length === 0) {
    console.log('No files to check.');
    process.exit(0);
  }

  if (verbose) {
    console.log(`Checking ${files.length} files...\n`);
  }

  let totalViolations = 0;
  const violationsByFile = {};

  files.forEach(file => {
    const violations = checkFile(file);
    if (violations.length > 0) {
      violationsByFile[file] = violations;
      totalViolations += violations.length;
    }
  });

  if (totalViolations === 0) {
    console.log('✅ No hardcoded colors found!');
    process.exit(0);
  }

  // Print violations
  console.log(`❌ Found ${totalViolations} hardcoded color(s) in ${Object.keys(violationsByFile).length} file(s):\n`);

  Object.entries(violationsByFile).forEach(([file, violations]) => {
    console.log(`\n📄 ${file}:`);
    violations.forEach(v => {
      console.log(`   Line ${v.line}: ${v.type} color "${v.value}"`);
      if (verbose) {
        console.log(`   Context: ${v.context}`);
      }
    });
  });

  console.log('\n💡 Fix: Replace hardcoded colors with design tokens from useThemeColors() hook.');
  console.log('   See: docs/design-tokens.md\n');

  process.exit(1);
}

// Run if executed directly
if (require.main === module) {
  main();
}

module.exports = {
  checkFile,
  getFilesToCheck,
  shouldExcludeFile 
};
