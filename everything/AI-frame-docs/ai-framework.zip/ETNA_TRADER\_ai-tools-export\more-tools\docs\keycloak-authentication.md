# Keycloak Authentication

This document describes the Keycloak authentication strategy — OAuth2/OIDC flow with PKCE for mobile applications.

> **See also:** [Authentication Overview](./authentication.md) for strategy selection, state management, and shared concepts.
> **See also:** [Keycloak Session Management](./keycloak-session-management.md) for session timeout settings and recommendations.

---

## Overview

Keycloak authentication uses **Authorization Code Flow with PKCE** (Proof Key for Code Exchange), the recommended secure OAuth2 flow for mobile applications. User credentials never enter the app — authentication happens in a system browser controlled by Keycloak.

**When used:** When `useKeyCloakAuth === true` in MobileSettings.

**Key differences from Public API:**

| Aspect | Public API | Keycloak |
|--------|------------|----------|
| **Protocol** | Custom token endpoint | OAuth2/OIDC standard |
| **User Interaction** | Username/password form | Browser-based OAuth redirect |
| **Token Type** | Custom API token | JWT (access + refresh + ID token) |
| **Credentials** | Sent to app backend | Never leave identity provider |
| **Token Refresh** | Not supported | Automatic via refresh token |
| **SSO Support** | No | Yes |

---

## OAuth2/OIDC Flow (Step-by-Step)

### 1. Discovery Phase (On App Startup)

The app fetches Keycloak's OpenID configuration to discover endpoints:

```
GET https://{keycloak-server}/realms/{realm}/.well-known/openid-configuration
```

Returns: `authorization_endpoint`, `token_endpoint`, `end_session_endpoint`, supported scopes, etc.

**Why Discovery?** Ensures the app always uses correct endpoints, even if Keycloak configuration changes.

### 2. Login Initiation (User Taps "Sign In")

1. **App generates PKCE challenge** (cryptographically secure random string)
2. **App opens system browser** with authorization URL:
   ```
   https://{keycloak-server}/realms/{realm}/protocol/openid-connect/auth?
     client_id={mobile-app}
     &redirect_uri={myapp:/callback}
     &response_type=code
     &scope=openid profile email
     &code_challenge={PKCE_challenge}
     &code_challenge_method=S256
   ```
3. **User authenticates** in Keycloak's login page (credentials never sent to app)
4. **Keycloak redirects back** to app with authorization code:
   ```
   myapp:/callback?code={authorization_code}&state={state}
   ```

**Why System Browser?**
- **Security**: Credentials never enter the app
- **SSO**: If user is already logged into Keycloak, no re-authentication needed
- **Trust**: Users recognize Keycloak's domain

### 3. Token Exchange (App Receives Callback)

1. **App extracts authorization code** from redirect URL
2. **App exchanges code for tokens** via POST to token endpoint:
   ```
   POST https://{keycloak-server}/realms/{realm}/protocol/openid-connect/token
   Body:
     grant_type=authorization_code
     &code={authorization_code}
     &redirect_uri={myapp:/callback}
     &client_id={mobile-app}
     &code_verifier={PKCE_verifier}
   ```
3. **Keycloak returns tokens**:
   ```json
   {
     "access_token": "eyJhbGc...",
     "refresh_token": "eyJhbGc...",
     "id_token": "eyJhbGc...",
     "expires_in": 300,
     "refresh_expires_in": 1800,
     "token_type": "Bearer"
   }
   ```

**Why PKCE?** Prevents authorization code interception attacks. Even if an attacker intercepts the code, they can't exchange it without the verifier.

### 4. Token Storage

After successful token exchange:

1. **Access Token** — Stored in TokenStore (memory + SecureStore)
2. **Refresh Token** — Stored separately in SecureStore (never in memory except during refresh)
3. **ID Token** — Stored in SecureStore (used for logout hint)
4. **Code Verifier** — Stored in SecureStore temporarily (cleared after exchange)
5. **Authenticated Flag** — Set to `true` in SecureStore
6. **Session State** — Updated in Zustand (triggers UI navigation)

Uses the same three-layer storage as Public API — see [Authentication Overview](./authentication.md#state-management).

### 5. Token Refresh (Automatic)

Keycloak access tokens are **short-lived** (typically 5-15 minutes). The app refreshes them automatically.

**Refresh Flow:**

1. **HTTP interceptor detects 401** on an API response
2. **Check if refresh token exists** and is not expired
3. **Request new access token**:
   ```
   POST https://{keycloak-server}/realms/{realm}/protocol/openid-connect/token
   Body:
     grant_type=refresh_token
     &refresh_token={refresh_token}
     &client_id={mobile-app}
   ```
4. **Keycloak returns fresh tokens** (new access token + new refresh token)
5. **Update TokenStore** with new tokens
6. **Retry original request** with new access token

**Concurrent 401 deduplication:** If multiple requests fail with 401 simultaneously, only one refresh request is sent — others reuse the same promise. See `src/infrastructure/http/core/tokenRefresh.ts`.

**When refresh token expires:**
- User must re-authenticate (full OAuth flow again)
- App clears session and redirects to Sign In screen

For session timeout configuration, see [Keycloak Session Management](./keycloak-session-management.md).

### 6. Logout Flow

1. **User triggers logout**
2. **App calls Keycloak's logout endpoint**:
   ```
   GET https://{keycloak-server}/realms/{realm}/protocol/openid-connect/logout?
     id_token_hint={id_token}
   ```
3. **Keycloak invalidates tokens** server-side
4. **App clears local state** (same as Public API logout)

**Why ID Token Hint?** Helps Keycloak identify which session to terminate, enabling proper SSO logout across all apps.

**Note on logout redirect:** The mobile app does NOT use `post_logout_redirect_uri` because React Native's networking layer has issues with custom URI schemes in URL parameters. The `id_token_hint` is sufficient for Keycloak to invalidate the session.

---

## Configuration

### Keycloak Config File

**File:** `src/shared/config/keycloakConfig.ts`

```typescript
export const KEYCLOAK_REALM_NAME = "your-realm-name";
export const KEYCLOAK_AUTH_SERVER_URL = "https://keycloak.example.com";
export const KEYCLOAK_CLIENT_ID = "your-mobile-app-client-id";
export const KEYCLOAK_SCOPES = ["openid", "profile", "email"];
export const KEYCLOAK_TIMEOUT = 5000;

// Redirect URI is dynamically constructed from brand configuration
export function getKeycloakRedirectUri(scheme: string): string {
  return `${scheme}:/callback`;  // Single slash - treats /callback as PATH (not HOST)
}
```

### OAuth Redirect URI

The redirect URI is **automatically constructed** from brand configuration — no manual `.env` entry needed.

**URI Format:** `{scheme}:/callback` (single slash!)
- Single slash `(:/callback)` treats `/callback` as **PATH** (correct for Android intent filters)
- Double slash `(://callback)` treats `callback` as **HOST** (incorrect)

**Example redirect URIs:**
- ETNA brand: `etna-mobile:/callback`
- Sogo brand: `sogo-mobile:/callback`

**Where to configure:** Edit `/brand-config.js`:

```javascript
const myBrand = {
  appName: "My App",
  slug: "my-app",
  scheme: "my-app",  // ← Used for OAuth redirect URI
  bundleIdentifier: "com.mycompany.myapp",  // For app store
  package: "com.mycompany.myapp",            // For Google Play
};
```

**Important:**
- Use `scheme` for OAuth redirect (e.g., `my-app:/callback`)
- `bundleIdentifier`/`package` are only for app store identification
- The same `scheme` is registered in `app.config.ts` for deep linking

**Register in Keycloak:** Add to **Valid Redirect URIs** in Keycloak Admin Console:
```
my-app:/callback
```

See [White-Label Configuration](./white-label-configuration.md) for multi-brand setup.

### Android Deep Linking Setup

Android requires an **intent filter** in `AndroidManifest.xml` to handle OAuth callback deep links. This is configured automatically using a custom Expo config plugin.

**Plugin:** `plugins/with-oauth-deep-linking.cjs`

**What it does:**
1. Reads the app's custom URL scheme from `app.config.ts` (e.g., `"etna-mobile"`)
2. Adds an intent filter to `AndroidManifest.xml` with:
   - **Scheme:** Your app's custom scheme (e.g., `etna-mobile`)
   - **Path:** `/callback` (to match the OAuth redirect URI format)
   - **Categories:** `BROWSABLE` + `DEFAULT` (required for deep linking)

**Configuration in `app.config.ts`:**

```typescript
export default ({ config }: ConfigContext): ExpoConfig => {
  const brandConfig = getBrandConfig(BRAND);

  return {
    name: brandConfig.appName,
    slug: brandConfig.slug,
    scheme: brandConfig.scheme, // ← Used by OAuth deep linking plugin
    plugins: [
      "expo-router",
      "./plugins/with-oauth-deep-linking.cjs", // ← OAuth deep linking
      ["./plugins/with-android-network-security.cjs", { ... }],
    ],
    // ...
  };
};
```

**Generated intent filter in `AndroidManifest.xml`:**

```xml
<intent-filter android:autoVerify="true" data-generated="true">
  <action android:name="android.intent.action.VIEW"/>
  <data android:scheme="etna-mobile" android:path="/callback"/>
  <category android:name="android.intent.category.BROWSABLE"/>
  <category android:name="android.intent.category.DEFAULT"/>
</intent-filter>
```

**Why separate plugin?**
- OAuth deep linking is a distinct concern from network security
- Keeps plugins focused on single responsibility
- Easier to maintain and understand

**When to rebuild:**
- After changing the `scheme` in `app.config.ts`
- After modifying the plugin code
- First time setup: `npx expo prebuild --clean`

> **Note:** iOS doesn't require manual intent filter configuration — the `scheme` in `app.config.ts` is sufficient.

### OAuth Callback Handling

The OAuth redirect is handled automatically by `expo-auth-session`, but **Android requires a route file** for Expo Router to match the deep link path.

**Route file:** `app/(auth)/callback.tsx`

**Why needed?**
- **Android:** Expo Router requires a matching route for deep links with paths (`/callback`)
- **iOS:** Not strictly required, but kept for consistency
- The route rarely renders — `expo-auth-session` intercepts the redirect before the component mounts

**How it works:**
1. Keycloak redirects to `{scheme}:/callback?code=xxx&state=yyy`
2. **Android/iOS opens the app** via deep link (Android uses intent filter, iOS uses scheme)
3. **Expo Router matches** `app/(auth)/callback.tsx` (prevents "Unmatched Route" error)
4. `WebBrowser.maybeCompleteAuthSession()` (in `SignInKeycloakForm.tsx`) **intercepts** the redirect
5. `expo-auth-session` extracts the authorization code
6. `SignInKeycloakForm` receives the result and exchanges code for tokens
7. `AuthGate` detects authenticated user and redirects to `/(tabs)`

The callback screen shows a loading indicator, but it's rarely seen because the redirect happens so quickly.

---

## Error Handling

- **Authorization cancelled** — User cancelled browser, no error stored
- **Authorization failed** — Keycloak returned error, stored in Zustand `authError`
- **Token exchange failed** — Network or server error, stored in Zustand `authError`
- **Refresh token expired** — Session cleared, user redirected to Sign In

---

## File Reference

| Concept | File Path |
|---------|-----------|
| **Port (Interface)** | `src/domain/ports/IAuthService.ts` |
| **Repository** | `src/infrastructure/repositories/KeycloakAuthRepository.ts` |
| **Keycloak Config** | `src/shared/config/keycloakConfig.ts` |
| **Keycloak DTO** | `src/infrastructure/dto/KeycloakTokenResponseDTO.ts` |
| **Token Refresh** | `src/infrastructure/http/core/tokenRefresh.ts` |
| **Login Hook** | `src/features/auth/hooks/keycloakQueries.ts` |
| **Sign In Form** | `src/features/auth/components/SignInKeycloakForm.tsx` |
| **OAuth Callback Route** | `app/(auth)/callback.tsx` (required for Android) |
| **OAuth Deep Linking Plugin** | `plugins/with-oauth-deep-linking.cjs` |
| **ADR** | `docs/adr/0007-keycloak-oauth-implementation.md` |

---

## Related Documentation

- **[Authentication Overview](./authentication.md)** — Strategy selection, state management, session restoration
- **[Keycloak Session Management](./keycloak-session-management.md)** — Session timeouts, Client Session Idle vs Max
- **[Public API Authentication](./public-api-authentication.md)** — Alternative auth strategy
- **[HTTP Infrastructure](./http-infrastructure.md)** — Axios clients, interceptors
- **[Android Network Security](./android-network-security.md)** — Custom CA certificates configuration for Android
