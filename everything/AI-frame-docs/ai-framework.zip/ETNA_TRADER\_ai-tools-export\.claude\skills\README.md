# ETNA_TRADER Skills

AI workflow skills for ETNA_TRADER — a C# / .NET + TypeScript trading system with SQL Server, EF/NHibernate, Unity DI, NLog/Serilog, and an ACAT frontend built with Vite.

## Core Workflow Skills

| Skill | Purpose |
|---|---|
| `/nf` | New trading feature discovery and scope shaping |
| `/ct` | Technical decomposition with TDD-first plan (.NET + TypeScript) |
| `/si` | Structured implementation and execution |
| `/sr` | Multi-agent pre-merge review (with db-migration agent gate) |

### Typical Flow

- **Full flow**: `/nf` → `/ct` → `/si` → `/sr`
- **Fast flow** (clear requirements): `/ct` → `/si` → `/sr`
- **Review loop**: `/si` → `/sr` → `/si` (fixes) → `/sr`

## Supporting Skills

| Skill | Purpose |
|---|---|
| `/parallelization` | Split implementation into isolated workers (frontend + backend, independent services) |
| `/udoc` | Update docs and changelog from a completed task |

## QA Skills

| Skill | Purpose |
|---|---|
| `/qa` | Senior QA workflow: test plan, test cases, automation, architecture, coverage review |
| `/qa-orchestrator` | Context-aware QA entry: builds context bundle from work item / task carrier, then routes to `/qa` |

Invoke `/qa` with an optional mode:
```
/qa [feature-name]                 → auto-detect mode
/qa [task-path] test plan          → FULL (plan + TCs + automation outline)
/qa [task-path] test cases         → TCs only
/qa [task-path] automate           → Automation (Playwright/pytest or C# NUnit)
/qa [task-path] architecture       → Test architecture design
/qa [task-path] coverage review    → Coverage audit with gap analysis
```

Use `/qa-orchestrator` when context is not yet gathered (work item ID, no task folder, scattered multi-repo scope).

## AI-Assisted Quality Skills

| Skill | Purpose |
|---|---|
| `/ai-settings` | Delivery quality automation: release notes, AC, style check, test gaps, pre-commit |

Invoke `/ai-settings` with an optional mode argument:
```
/ai-settings RELEASE_NOTES
/ai-settings ACCEPTANCE_CRITERIA
/ai-settings REPO_STYLE_ALIGNMENT
/ai-settings UNIT_TEST_OPPORTUNITIES
/ai-settings PRE_COMMIT_CHECK
```

## Meta Skills

| Skill | Purpose |
|---|---|
| `/skill-creator` | Guide for creating new ETNA_TRADER-specific skills |

## Workflow Diagram

```
/nf → /ct → /si → /sr
              ↑         ↓
              └─── (fixes if NEEDS FIXES)

/ai-settings   ← anytime: release notes, style check, pre-commit, AC
/udoc          ← after implementation complete
```

## ETNA_TRADER Rules (enforced across all skills)

### C# / .NET
- **Layer boundaries**: Contracts ← Services ← DAL ← API (never skip layers)
- **ConfigureAwait(false)**: on all `await` in service/repository code
- **CancellationToken**: last parameter in every `async` method, always propagated
- **Namespaces**: `Etna.Trader.*`, `Etna.Trading.*`, `Etna.Common.*`
- **Interfaces**: `I` prefix, PascalCase (`IOrderService`, `IAccountRepository`)
- **Logging**: NLog or Serilog with structured (named) parameters — no string interpolation

### TypeScript / ACAT Frontend
- **Named exports only** — no `export default` from components
- **Props interface**: co-located, named `<Component>Props`
- **No hardcoded CSS colors** in `.tsx` files — use CSS custom properties

### Database (SSDT)
- **Backward compatibility**: 3-phase column removal (stop writing → deprecate → drop)
- **Data migration idempotency**: `_MigrationHistory` guard in every PostDeployment script
- **DATETIME2** not `DATETIME`; **DECIMAL(18,6)** for prices
- **Index naming**: `IX_`, `UQ_`, `PK_`, `FK_`, `DF_`, `CK_` prefixes

### Testing
- **Unit tests**: `qa/<Project>.Tests/` — pure logic, builders/factories, NSubstitute mocks
- **Integration tests**: `qa/<Project>.IntegrationTests/` — tag `[Category("Integration")]`
- **Test runner**: `dotnet test qa/<Project>.Tests/` or `dotnet test qa/Etna.Tests.sln`

## Full Reference

See `docs/architecture.md` and `docs/dev-workflow/` for complete ETNA_TRADER developer workflow documentation.
