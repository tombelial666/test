# ADR-0002: AppInitializationProvider for Startup Orchestration

**Status**: Accepted
**Date**: 2025-12-07

## Context

The mobile app requires multiple tasks to be executed during startup: fetching mobile settings, initializing push notifications, establishing socket connections, configuring biometric authentication, and managing token refresh. Currently, there is no centralized mechanism to orchestrate these tasks, control their execution order, or manage dependencies between them. As we implement the first Zustand store for mobile settings, we need to decide where and how initialization logic should live.

## Use Cases

- **UC1: Mobile Settings Fetch**: Load app configuration (feature flags, URLs, display settings) once at startup before showing Sign In screen
- **UC2: Future Push Notifications**: Initialize OneSignal and register device for push notifications after settings are loaded
- **UC3: Future Socket Initialization**: Establish WebSocket connection for real-time data after authentication tokens are available
- **UC4: Future Biometric Auth**: Configure local authentication based on settings (`enableTouchID` flag)
- **UC5: Future Token Refresh**: Setup Keycloak token refresh timer based on authentication method from settings
- **UC6: Splash Screen**: Show loading indicator until critical startup tasks complete (only for unauthenticated users; authenticated users see app content immediately)
- **UC7: Sign In Customization**: Display Sign In screen with content customized based on fetched settings

## Options Considered

### Option 1: Distributed Initialization (Each Provider Handles Its Own)

Each provider independently manages its initialization in `useEffect`:
- Settings provider → fetches settings
- `PushNotificationsProvider` → initializes push
- `SocketProvider` → establishes socket
- All happen in parallel based on provider nesting order

**Pros**:
- Modular and decoupled
- Each provider is self-contained
- Easy to add/remove individual providers
- Follows single responsibility principle

**Cons**:
- No control over execution order or dependencies
- Cannot ensure settings load before push notifications init
- Difficult to show single loading state for all startup tasks
- Race conditions between interdependent tasks
- No centralized place to manage startup flow
- Cannot easily implement "wait for critical tasks before showing UI"

### Option 2: AppInitializationProvider (Centralized Orchestration)

Create dedicated `AppInitializationProvider` that orchestrates all startup tasks:
- Centralized location for startup sequence
- Controls execution order and dependencies
- Manages single loading state for entire initialization
- Other providers remain passive (no initialization logic)

**Pros**:
- Centralized control over startup sequence
- Easy to add dependencies (e.g., "push after settings")
- Single loading state for entire app initialization
- Clear visibility of what happens at startup
- Matches mental model from old app (`authConfiguration()`)
- Can show splash screen until critical tasks complete
- Easy to implement retry logic for failed tasks
- Can prioritize critical vs. non-critical startup tasks

**Cons**:
- Slightly more complex provider
- Less modular than Option 1
- All startup logic in one place (could grow large)
- Requires updating provider when adding new startup tasks

### Option 3: Composition Root Pattern (Hybrid Approach)

Mix of both: critical tasks in `AppInitializationProvider`, optional tasks in individual providers:
- Settings → AppInitializationProvider (critical)
- Push notifications → separate provider (optional)
- Socket → AppInitializationProvider (critical for authenticated users)

**Pros**:
- Balance between centralization and modularity
- Critical path is clear and controlled
- Optional features remain decoupled

**Cons**:
- Ambiguity about what goes where
- Complexity of two initialization paths
- Harder to understand startup flow
- Still has race condition issues for optional features

## Decision

We chose **Option 2: AppInitializationProvider** because:

1. **Startup sequence is inherently sequential**: Settings must load before Sign In can be customized; tokens must exist before sockets connect; settings determine if biometric auth is enabled
2. **Single loading experience**: Users should see one splash screen for all startup tasks, not multiple loading states
3. **Visibility and maintainability**: Having all startup tasks in one provider makes it easy to understand app boot flow and diagnose issues
4. **First implementation sets pattern**: As the first Zustand store and startup orchestration, this establishes a clear, understandable pattern for the team

## Consequences

**Implementation**:
- Create `src/composition/AppInitializationProvider.tsx`
- Provider wraps app content and shows splash screen during initialization
- Uses Zustand store actions to fetch settings
- Returns `null` or `<SplashScreen />` while `isLoading === true`
- Renders children once initialization completes (success or graceful failure)

**Provider Stack Order** (in `app/_layout.tsx`):
```tsx
<HttpProvider>                      // 1. Bootstrap TokenStore
  <ApiProvider>                     // 2. Create repositories
    <QueryProvider>                 // 3. React Query client
      <AppInitializationProvider>   // 4. Orchestrate startup (NEW)
        <AuthProvider>              // 5. Auth strategy selection
          <ThemeProvider>           // 6. Theme
            <ToastProvider>         // 7. Toasts
              <Stack />             // 8. App content
```

**Future Additions**:
- Push notifications: add to `AppInitializationProvider` after settings
- Socket init: add after authentication check
- Biometric auth: add based on settings flag
- Token refresh timer: add based on Keycloak flag

**Testing**:
- Integration test: verify settings fetch before children render
- Integration test: verify graceful degradation (children render even if fetch fails)
- Integration test: verify splash screen shown during initialization

**Files Affected**:
- `src/composition/AppInitializationProvider.tsx` (new)
- `src/shared/ui/common/loaders/LoadingView.tsx` (new, used by splash)
- `app/_layout.tsx` (add AppInitializationProvider to provider stack)

**Note**: `StoreProvider` was later removed as it was empty. Zustand store is accessed directly via `useStore()` hook.

**Trade-offs Accepted**:
- Less modularity in exchange for clearer startup flow
- Single provider grows as more startup tasks added (mitigate with helper functions/hooks)
- Must update provider for each new startup task (benefit: forces conscious decision about initialization order)

