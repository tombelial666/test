# Expo Development Guidelines

## Project Structure (Expo Router)

```
app/
├── _layout.tsx          ← Root layout: all providers + RootLayoutNav
├── (tabs)/
│   ├── _layout.tsx      ← Tab bar configuration
│   └── index.tsx        ← First tab screen
└── (stack)/
    └── details.tsx      ← Stack screens
```

## Provider Order (`app/_layout.tsx`)

Providers must be nested in this exact order:

```tsx
<HttpProvider>
  <BrandProvider>
    <ApiProvider>
      <QueryProvider>
        <AppInitializationProvider>
          <LocalizationProvider>
            <AuthProvider>
              <ThemeProvider>
                <ToastProvider>
                  <RootLayoutNav />
                </ToastProvider>
              </ThemeProvider>
            </AuthProvider>
          </LocalizationProvider>
        </AppInitializationProvider>
      </QueryProvider>
    </ApiProvider>
  </BrandProvider>
</HttpProvider>
```

## Expo Router Conventions

### File-Based Routing
- `app/index.tsx` → `/`
- `app/profile.tsx` → `/profile`
- `app/(tabs)/home.tsx` → tab screen `/home`
- `app/(stack)/details.tsx` → stack screen `/details`
- `app/[id].tsx` → dynamic route `/:id`

### Navigation

```tsx
import { router, Link, useLocalSearchParams } from 'expo-router';

// Programmatic
router.push('/profile');
router.replace('/home');
router.back();

// Component
<Link href="/profile">Go to Profile</Link>

// Dynamic params
const { id } = useLocalSearchParams<{ id: string }>();
```

### Screen Layout Options

```tsx
import { Stack } from 'expo-router';

export default function Layout() {
  return (
    <Stack screenOptions={{ headerShown: false }} />
  );
}
```

## Environment Variables

```bash
# Required (API)
EXPO_PUBLIC_PRIMARY_API_URL=https://api.example.com
EXPO_PUBLIC_PRIMARY_API_KEY=your-key
EXPO_PUBLIC_SECONDARY_API_URL=https://api-secondary.example.com
EXPO_PUBLIC_SECONDARY_API_KEY=your-secondary-key

# White-label (typically set by npm scripts)
BRAND=etna          # etna | sogo
APP_ENV=development # development | production

# Optional
EXPO_PUBLIC_USE_SECONDARY_API=false
```

Access in code:
```ts
const apiUrl = process.env.EXPO_PUBLIC_PRIMARY_API_URL;
```

**Only `EXPO_PUBLIC_*` variables are accessible client-side.**

## New Architecture (`newArchEnabled: true`)

New Architecture (Fabric + TurboModules) is enabled in this repo:
- `app.config.ts`: `newArchEnabled: true`
- `android/gradle.properties`: `newArchEnabled=true`

Implications:
- All native libraries must support New Architecture
- Use `useLayoutEffect` carefully — timing differs from web
- Third-party libs: verify New Architecture compatibility before adding

## Expo-Specific APIs

```tsx
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as SecureStore from 'expo-secure-store';

// Safe area padding
const insets = useSafeAreaInsets();
<View style={{ paddingTop: insets.top }} />

// Secure storage (used in HttpProvider for TokenStore)
await SecureStore.setItemAsync('key', 'value');
const value = await SecureStore.getItemAsync('key');
```

## Import Rules

```tsx
// ✅ Always use @/ path alias
import { useThemeColors } from '@/shared/theme/hooks';
import { useApi } from '@/composition/ApiProvider';
import { useStore } from '@/store';

// ❌ Never import infrastructure in features
import { AccountRepository } from '@/infrastructure/repositories/AccountRepository';

// ❌ Never use relative cross-feature imports
import { something } from '../../../shared/theme/hooks';
```

## Common Pitfalls

- **Strings must be wrapped** in `<Text>` — naked strings cause crashes on New Architecture
- **Never use `&&` with numbers** → use ternary: `{count > 0 ? <Badge /> : null}`
- **Never hardcode colors** — use `useThemeColors()` from `@/shared/theme/hooks`
- **Never import `infrastructure`** in feature components (violates layer boundaries)
- **Always add translations** — never hardcode UI text, use `t("key")`
