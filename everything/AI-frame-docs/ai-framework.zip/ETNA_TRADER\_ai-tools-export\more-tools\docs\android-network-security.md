# Android Network Security Configuration

This document explains how to configure custom CA certificates for Android HTTPS connections.

## Overview

The app uses a custom Expo config plugin (`plugins/with-android-network-security.cjs`) that automatically:

1. **Copies CA certificates** from `assets/certificates/` to Android resources
2. **Creates network security config** XML file to trust custom certificates
3. **Configures AndroidManifest** to use the network security config
4. **Enables cleartext traffic** for development (Metro bundler uses HTTP)

This allows the app to trust custom CA certificates for API connections over HTTPS.

> **Note:** For OAuth deep linking configuration, see [Keycloak Authentication - Android Setup](./keycloak-authentication.md#android-deep-linking-setup).

## Setup Instructions

### 1. Place CA Certificates

CA certificate files are located in `assets/certificates/`:

```
assets/
  certificates/
    cer1.crt
    cer2.crt
    cer3.crt
    cer4.crt
```

**Supported formats:** `.cer`, `.crt`, `.pem`, `.der`

### 2. Certificate Names Configuration

Certificate names are configured in `app.config.ts`:

```typescript
plugins: [
  "expo-router",
  // OAuth deep linking (separate plugin)
  "./plugins/with-oauth-deep-linking.cjs",
  // Network security configuration
  [
    "./plugins/with-android-network-security.cjs",
    {
      certificates: ["cer1", "cer2", "cer3", "cer4"],
    },
  ],
],
```

**Important:** The names in the array must match your certificate filenames (without the extension).

### 3. Build and Run

**Normal Development Workflow:**

Simply run:
```bash
npm run android:etna
```

The `expo run:android` command **automatically runs prebuild** if needed. The plugin will execute during prebuild and configure everything.

**When to Run Prebuild Explicitly:**

You only need to run `npx expo prebuild --clean` manually when:
- **After changing config plugins** - If you modify `app.config.ts` or the plugin itself
- **After adding/removing certificates** - When you change the certificate list
- **If you encounter build issues** - A clean prebuild can fix stale configurations

## How It Works

### Network Security Config

The plugin creates `android/app/src/main/res/xml/network_security_config.xml`:

```xml
<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="true">
        <trust-anchors>
            <certificates src="system" />
            <certificates src="@raw/cer1" />
            <certificates src="@raw/cer2" />
            <certificates src="@raw/cer3" />
            <certificates src="@raw/cer4" />
        </trust-anchors>
    </base-config>
</network-security-config>
```

And adds to AndroidManifest.xml:

```xml
<application
  android:networkSecurityConfig="@xml/network_security_config"
  android:usesCleartextTraffic="true"
  ...>
```

This tells Android to trust:
- **System certificates** (default Android CA certificates)
- **Your custom CA certificates** (from assets/certificates/)
- **Cleartext HTTP traffic** (for development Metro bundler)

### Certificate Processing

1. **Sanitization:** Certificate names are sanitized for Android resource naming rules (lowercase, a-z/0-9/_)
2. **Copy:** Certificates are copied to `android/app/src/main/res/raw/` (without file extension)
3. **Reference:** XML references certificates as `@raw/{sanitized_name}`

Example:
- Input: `SectigoPublicServerAuthenticationRootR46.crt`
- Sanitized: `sectigopublicserverauthenticationrootr46`
- Referenced as: `@raw/sectigopublicserverauthenticationrootr46`

## Cleartext Traffic (Development)

The plugin sets `android:usesCleartextTraffic="true"` to allow HTTP connections for:
- **Metro bundler** (development server at `http://localhost:8081`)
- **Development APIs** (if needed)

**Production Note:** If your production API is HTTPS-only, this setting is safe because:
- The setting only *permits* cleartext, it doesn't force it
- All your API calls use HTTPS (configured in environment variables)
- This is a common practice for React Native apps

If you want to disable cleartext for production builds, you would need to make this conditional based on build type (requires additional configuration).

## Troubleshooting

### Certificates Not Found

**Error:** `⚠️ Certificate [name] not found in assets/certificates/`

**Solution:**
- Verify certificate files are in `assets/certificates/`
- Check filenames match exactly (case-sensitive)
- Ensure file extension is one of: `.cer`, `.crt`, `.pem`, `.der`
- Update the certificate names in `app.config.ts` if needed

### SSL/TLS Connection Errors

**Symptoms:** API calls fail with certificate errors

**Check:**
1. Certificates are in `assets/certificates/` before prebuild
2. Certificate names in `app.config.ts` match filenames (without extension)
3. Network security config was created (check `android/app/src/main/res/xml/network_security_config.xml`)
4. AndroidManifest has `android:networkSecurityConfig="@xml/network_security_config"`
5. Run `npx expo prebuild --clean` to regenerate

### Plugin Not Running

**Symptoms:** No changes to AndroidManifest or missing files

**Solution:**
- Ensure plugin is listed in `app.config.ts` plugins array
- Run `npx expo prebuild --clean` to force regeneration
- Check console output for plugin messages (`✓ Copied certificate`, etc.)

## File Structure

After prebuild, the plugin creates:

```
android/
  app/
    src/
      main/
        res/
          raw/
            cer1    # Copied certificate (no extension, sanitized name)
            cer2
            cer3
            cer4
          xml/
            network_security_config.xml  # Generated config
        AndroidManifest.xml              # Modified with networkSecurityConfig attribute
```

## Development vs Production

- **Development:** Works with `expo run:android` (runs prebuild automatically)
- **Production:** Works with EAS Build (prebuild runs automatically)
- **Expo Go:** Not supported (requires native code)

## Related Documentation

- [Keycloak Authentication](./keycloak-authentication.md) - OAuth flow and Android deep linking setup
- [Keycloak Session Management](./keycloak-session-management.md) - Session configuration
- [Project Structure](./project-structure.md) - App architecture
