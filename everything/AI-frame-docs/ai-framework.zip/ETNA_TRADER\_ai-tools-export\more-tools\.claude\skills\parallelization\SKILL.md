---
name: parallelization
description: "Optional workflow skill: orchestrate parallel implementation by spawning scoped developer workers and merging results safely."
context: fork
allowed-tools:
  - Read
  - Grep
  - Glob
  - Task
  - Bash
---

# Parallelization (Optional)

Use this skill when you believe part of the work can be done in parallel **without increasing merge risk**.

## Principle

- **Developer is given scope**: each worker implements **one** scoped work item (typically one acceptance criterion or one screen).
- **No extra ceremony**: do not require "announce decision" rituals.
- **Safety first**:
  - **Git writes are forbidden unless explicitly approved** (branch/commit/push/merge).
  - If git writes are not approved, workers still produce results but do not create branches or commits.
  - **Task docs are orchestrator-owned in parallel mode**: workers must not edit shared task documents (to avoid conflicts). The orchestrator updates task docs after applying/merging worker outputs.

## Critical Rule (true parallelism)

To maximize concurrency, **spawn ALL worker Task calls in a SINGLE assistant message**.

## Inputs

Provide at minimum:

- `task_document_path`: path to task doc (file or directory)

Optionally:

- `branch_name`: main feature branch name (if applicable)
- `git_writes_approved`: `true|false` (must be explicit)

## Good Candidates for Parallel Work (MobileLiteApp)

- Separate screens that don't share state
- Independent domain entities + their mappers
- Separate React Query hooks for unrelated data
- Independent Zustand store slices
- Separate test suites for different features

## Bad Candidates (do NOT parallelize)

- Shared Zustand store changes
- Changes to the same repository or mapper
- Changes to `composition/ApiProvider.tsx`
- Changes to auth interceptors
- Navigation structure changes

## Workflow

### 1) Identify parallelizable work items

- Read the task doc and list the acceptance criteria/work items.
- Select only items that can be implemented **independently** (different files/areas, no shared touching).

### 2) Spawn `developer-agent` workers

For each selected item, spawn a worker:

```
Use Task tool:
subagent_type: "developer-agent"
prompt: "Implement criterion [N] (scoped work item) for task at [task_path].

Inputs:
- task_document_path: [task_document_path]
- criterion_number: [N]
- branch_name: [branch_name or 'none']
- git_writes_approved: [true|false]

Constraints:
- Implement ONLY criterion [N]
- Follow TDD (RED→GREEN→REFACTOR) inside scope
- Do NOT do any git operations unless git_writes_approved=true
- Do NOT edit shared task documents; return notes for orchestrator to update docs
- Follow MobileLiteApp architecture: no infra imports in features, use @/ alias, no hardcoded colors/strings

Return JSON result when done."
```

### 3) Consolidate results

- Collect each worker's JSON.
- If `git_writes_approved=true` and branches/commits exist:
  - Merge each sub-branch into the main feature branch.
- If `git_writes_approved=false`:
  - Apply changes manually based on worker outputs.
- Update the task document (checkboxes/changelog/tests) **once**, after applying worker outputs.

### 4) Run validation

```bash
npx tsc --noEmit 2>&1 | head -20
npm run lint 2>&1 | head -20
npm test -- --passWithNoTests --silent 2>&1 | tail -20
```

## Output (to orchestrator)

Return:

- Which criteria were executed in parallel
- Worker JSON summaries
- Any conflicts/merge risks discovered
- What remains to be done sequentially
