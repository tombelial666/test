## Mobile App Architecture (Expo + TypeScript + React Query + Zustand + Axios + Jest)

**TL;DR**: We use strict layers — app (routing) → features (UI + query hooks) → application (use-cases when needed) → domain (entities/ports) → infrastructure (HTTP/DTO/mappers/repos) → composition (providers/DI), plus store (Zustand) and shared (design system, utils, theme, config). Server state lives in React Query, global app state in Zustand. HTTP uses Axios with two singleton clients passed to repositories via DI; authentication via interceptors and in-memory TokenStore. Use-cases exist only where the UI must orchestrate rules/steps; trivial CRUD calls services directly via React Query hooks.

---

## 📚 Detailed Documentation

> **⚠️ IMPORTANT: All AI agents must read the documentation files below before planning or implementing any changes.** Understanding the project structure, architecture patterns, and conventions is essential for maintaining code quality and consistency.

- **[Project Structure](./docs/project-structure.md)** - Directory layout, import boundaries, and naming conventions
- **[HTTP Infrastructure](./docs/http-infrastructure.md)** - Axios clients, interceptors, authentication, and API integration
- **[Authentication](./docs/authentication.md)** - Overview: strategy selection, state management, session restoration, design decisions
  - **[Public API Authentication](./docs/public-api-authentication.md)** - Username/password login/logout flows
  - **[Keycloak Authentication](./docs/keycloak-authentication.md)** - OAuth2/OIDC flow, PKCE, token refresh, configuration
  - **[Keycloak Session Management](./docs/keycloak-session-management.md)** - Session timeouts, Client Session Idle vs Max, and configuration guide
- **[State Management](./docs/state-management.md)** - React Query vs Zustand, store patterns, and initialization
- **[Design Tokens](./docs/design-tokens.md)** - Color token system, theming, and usage guide
- **[Theme System Guide](./docs/theme-system-guide.md)** - Complete guide to theme behavior, runtime changes, and color usage
- **[Testing Guide](./docs/testing-guide.md)** - Testing strategy, factories, and best practices
- **[White-Label Configuration](./docs/white-label-configuration.md)** - Multi-brand setup and configuration
- **[Localization (i18n)](./docs/localization.md)** - i18n system, adding translations, validation scripts
- **[ADR (Architecture Decision Records)](./docs/adr/README.md)** - Technical decisions with context and rationale

---

## 📝 Architecture Decision Records (ADR)

When making significant technical decisions, create an ADR to document the reasoning.

**Location**: `docs/adr/`

**When to create ADR**:
- Technology/library choices
- Architectural patterns
- API design decisions
- Trade-offs with long-term impact

**How to create**:
1. Copy `docs/adr/TEMPLATE.md` → `docs/adr/NNNN-short-title.md`
2. Fill sections: Context → Use Cases → Options (with pros/cons) → Decision → Consequences
3. Update index in `docs/adr/README.md`

**Keep it concise** — ADR should be readable in 1-2 minutes.

---

## Quick Reference

### Layers Overview

```
/app/           → Expo Router (routes/layouts only)
/src/features/  → Feature UI + hooks/queries.ts (React Query hooks)
/src/application/ → Use-cases (orchestration when needed)
/src/domain/    → Entities, Value Objects, Ports (interfaces)
/src/infrastructure/ → HTTP clients, DTO, mappers, repositories
/src/composition/ → DI providers (wiring layer)
/src/store/     → Zustand store (global app state)
/src/shared/    → Design system, utils, theme
/tests/         → All tests (unit & integration)
```

### Import Rules (Boundaries)

- **features** → may import: `application`, `domain`, `shared`, `store`, other features' query hooks
- **features** → must NOT import: `infrastructure`
- **application** → imports only: `domain`
- **infrastructure** → implements: `domain/ports/*`
- **composition** → composes everything (only place that wires infra/ports/store)

### Path Aliases

```json
{ "@/*": ["src/*"] }
```

---

## Repository Pattern (No API Layer)

Repositories receive HTTP client via constructor (DI) and make HTTP calls directly:

```ts
// infrastructure/repositories/AccountRepository.ts
export class AccountRepository implements IAccountService {
  constructor(private readonly client: HttpClient) {}

  async getAccounts(): Promise<Account[]> {
    const { data } = await this.client.get<AccountListDTO>("/accounts");
    return data.accounts.map(accountMapper.toDomain);
  }
}
```

Repositories are instantiated in `ApiProvider` with HTTP client singletons.

---

## React Query Hooks

Each feature has `hooks/queries.ts` with query/mutation hooks:

```ts
// features/account/hooks/queries.ts
export function useAccountsQuery() {
  const { accountService } = useApi();
  return useQuery({
    queryKey: ["accounts"],
    queryFn: () => accountService.getAccounts(),
  });
}
```

Cross-feature: import query hooks from the feature that owns the data.

---

## Design Tokens (Color System)

**NO hardcoded colors** (`#007AFF`, `rgb()`, `rgba()`) in TSX files. Use design tokens exclusively.

### Quick Usage

```tsx
import { useThemeColors } from '@/shared/theme/hooks';

function MyComponent() {
  const colors = useThemeColors();

  return (
    <View style={{ backgroundColor: colors.background.base }}>
      <Text style={{ color: colors.text.base }}>Hello</Text>
      <TouchableOpacity
        style={{ backgroundColor: colors.background.brand?.base }}
      >
        <Text style={{ color: colors.text.onbrand?.base }}>
          Brand Button
        </Text>
      </TouchableOpacity>
    </View>
  );
}
```

### Token Categories

**Core tokens**: `text.base`, `background.base`, `icon.base`, `border.base`
**Sentiment tokens**: `text.brand?.base`, `text.danger?.base`, `text.success?.base` (use `?.`)
**Component tokens**: `link.text.hover`, `field.border.focus`, `control.background.checked`
**Compound tokens**: `card.background.base`, `table.background.header`, `leftnav.icon.active`

### Theme Switching

```tsx
import { useTheme } from '@/shared/theme/hooks';

const { theme, isDark, toggleTheme, setTheme } = useTheme();
```

**Full Guide**: [docs/design-tokens.md](./docs/design-tokens.md) | **Skill**: `/design-tokens` | **ADR**: [docs/adr/0008-design-tokens-system.md](./docs/adr/0008-design-tokens-system.md)

---

## Use-Cases (When to Create Them)

- **Don't add use-cases** for trivial CRUD (single port call, no rules/side-effects): call the service directly via React Query
- **Add a use-case** only when the UI must orchestrate steps/rules: multiple ports, pre-IO domain validation, optimistic updates + rollback, cache invalidation, cross-API flows, feature flags/tenants, offline queueing, analytics/auditing, dedup/idempotency, consistent error mapping

### Minimal Example

```ts
// application/trading/placeOrder.ts
export const createPlaceOrder = (deps: Deps) => async (input: Input) => {
  if (input.qty <= 0) throw new Error("QTY_ZERO");
  await deps.trading.placeOrder(input);
  await deps.portfolio.refreshCache?.();
};
```

---

## Providers Setup

Providers are nested in `app/_layout.tsx` following this order:

```tsx
<HttpProvider>
  <BrandProvider>
    <ApiProvider>
      <QueryProvider>
        <AppInitializationProvider>
        <LocalizationProvider>
            <AuthProvider>
                <ThemeProvider>
                <ToastProvider>
                  <RootLayoutNav />
                </ToastProvider>
              </ThemeProvider>
              </AuthProvider>
        </LocalizationProvider>
        </AppInitializationProvider>
      </QueryProvider>
    </ApiProvider>
  </BrandProvider>
</HttpProvider>
```

**Provider Responsibilities:**
- `HttpProvider`: Bootstraps TokenStore (loads token from SecureStore to memory)
- `BrandProvider`: White-label brand configuration (must wrap AuthProvider)
- `ApiProvider`: Creates service repositories with HTTP client DI
- `QueryProvider`: React Query client for server state
- `AppInitializationProvider`: Orchestrates startup (session restore + settings fetch)
- `AuthProvider`: Selects auth strategy based on settings (Public API vs Keycloak), uses brand config for redirect URI
- `ThemeProvider`: Design tokens + theme switching (light/dark mode, manual override, persistence)
- `LocalizationProvider`: Initializes i18n locale (AsyncStorage → device language → fallback "en")
- `ToastProvider`: Toast notifications (ready for future use)

See [Project Structure](./docs/project-structure.md) for details.

---

## Environment Variables

Required variables:
- API: `EXPO_PUBLIC_PRIMARY_API_URL`, `EXPO_PUBLIC_PRIMARY_API_KEY`
- Secondary API: `EXPO_PUBLIC_SECONDARY_API_URL`, `EXPO_PUBLIC_SECONDARY_API_KEY`
- White-label: `BRAND`, `APP_ENV`
- API switching: `EXPO_PUBLIC_USE_SECONDARY_API` (optional: true|false)

See [Environment Variables](./docs/environment-variables.md) for complete configuration guide.

---

## Adding a New Feature

1. Create `features/<feature>/` with `components/`, `screens/`, `hooks/`, `index.ts`
2. Add `hooks/queries.ts` with React Query hooks and query keys
3. Add ports/entities in `domain/*` (if needed)
4. Implement repository in `infrastructure/repositories/*` with HttpClient DI
5. Add DTO/mapper in `infrastructure/*`
6. Register repository in `composition/ApiProvider.tsx`
7. Add use-case in `application/<feature>/*` (if orchestration needed)
8. Add route in `app/(tabs|stack)/*`

Detailed guide in [Project Structure](./docs/project-structure.md).
