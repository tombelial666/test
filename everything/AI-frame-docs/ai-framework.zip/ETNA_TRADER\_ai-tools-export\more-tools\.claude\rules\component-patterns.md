# Component Development Patterns

## File Organization
- **Location**: `src/features/<feature>/components/` for feature components, `src/shared/ui/` for shared
- **Naming**: PascalCase (`UserCard.tsx`, `PrimaryButton.tsx`)
- **Exports**: Named exports only

```tsx
// ✅ Correct
export function UserCard({ user }: UserCardProps) { ... }

// ❌ Avoid
export default function UserCard() { ... }
```

## Color — Never Hardcode

Always use design tokens via `useThemeColors()` from `@/shared/theme/hooks`:

```tsx
import { useThemeColors } from '@/shared/theme/hooks';

export function PrimaryButton({ title, onPress }: Props) {
  const colors = useThemeColors();

  return (
    <TouchableOpacity
      style={{ backgroundColor: colors.background.brand?.base }}
      onPress={onPress}
    >
      <Text style={{ color: colors.text.onbrand?.base }}>{title}</Text>
    </TouchableOpacity>
  );
}
```

**Never**: `backgroundColor: '#007AFF'`, `color: 'rgb(0,0,0)'`, `borderColor: 'rgba(0,0,0,0.1)'`

## TypeScript Props

```tsx
interface ComponentProps {
  title: string;
  onPress?: () => void;
  variant?: 'primary' | 'secondary';
}

export function MyComponent({ title, onPress, variant = 'primary' }: ComponentProps) {
  // ...
}
```

## Styling Pattern

```tsx
import { StyleSheet } from 'react-native';
import { useThemeColors } from '@/shared/theme/hooks';

export function MyComponent() {
  const colors = useThemeColors();

  return (
    <View style={[styles.container, { backgroundColor: colors.background.base }]}>
      <Text style={[styles.title, { color: colors.text.base }]}>Hello</Text>
    </View>
  );
}

// Only non-color styles in StyleSheet.create
const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  title: { fontSize: 18, fontWeight: '600' },
});
```

## Component Composition

```tsx
export function Card({ children, style }: CardProps) {
  const colors = useThemeColors();

  return (
    <View
      style={[
        styles.card,
        {
          backgroundColor: colors.card.background.base,
          borderColor: colors.card.border.base,
        },
        style,
      ]}
    >
      {children}
    </View>
  );
}
```

## Testing

- **Location**: `tests/unit/` or `tests/integration/` (mirrors `src/` structure)
- **Framework**: Jest + React Testing Library

```tsx
import { ThemeProvider } from '@/shared/theme/ThemeProvider';

const wrapper = ({ children }: { children: React.ReactNode }) => (
  <ThemeProvider>{children}</ThemeProvider>
);

describe('MyComponent', () => {
  it('renders correctly', () => {
    render(<MyComponent />, { wrapper });
    expect(screen.getByText('Hello')).toBeTruthy();
  });
});
```

## Best Practices

- `React.memo()` for expensive pure components
- `useCallback` / `useMemo` for stable references in list items
- Never inline object creation in render when possible
- Feature-specific components stay in `src/features/<feature>/components/`
- Shared/reusable components go in `src/shared/ui/`
