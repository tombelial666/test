---
name: react-native-expo
description: |
  React Native + Expo best practices for Mobile Lite App.

  **Use this skill when:**
  - Implementing React Native components, animations, or gestures
  - Optimizing list performance (FlatList, FlashList)
  - Working with navigation (Expo Router, Stack, Tabs)
  - Reviewing components for RN-specific crashes or anti-patterns
  - Implementing state management with hooks or Reanimated
  - Working with Expo SDK APIs (SecureStore, Image, SafeArea)

  **Contains 30+ rules** for preventing crashes, optimizing performance, and following RN/Expo best practices.

  NOT for design token naming (use `/design-tokens`). NOT for i18n (use `/localization`).
allowed-tools:
  - Read
  - Grep
---

# React Native + Expo Best Practices

Best practices for building performant, crash-free mobile features in this project.

## When to use this skill

- Implementing or reviewing React Native components
- Optimizing list rendering or scroll performance
- Adding animations or gesture handling
- Working with Expo Router navigation
- Questions about RN-specific patterns or pitfalls

## Related skills

- `/design-tokens` — color token naming and theming decisions
- `/localization` — i18n and translation questions

## Instructions

When this skill is invoked:

1. **Identify the relevant section(s)** from the reference table below
2. **Load only the needed section** from `references/rules.md` using Grep to find the section header (e.g., `## 3. Scroll Performance`), then Read the relevant line range
3. **Apply rules by priority:**
   - **CRITICAL** (prevent crashes): Core Rendering
   - **HIGH** (major performance): List Performance, Scroll, Navigation, Animation
   - **MEDIUM** (moderate impact): State Management, User Interface, Platform

### Example requests

- *"Optimize this FlatList"* → Load section 2 (List Performance) from `references/rules.md`
- *"Add a press animation"* → Load section 5 (Animation) from `references/rules.md`
- *"Review this component for RN best practices"* → Load section 1 (Core Rendering) first, then scan for relevant patterns

## Reference sections

| # | Section | Priority | When to load |
|---|---------|----------|--------------|
| 1 | Core Rendering | CRITICAL | Always scan for `&&` and string-outside-Text issues |
| 2 | List Performance | HIGH | FlatList, FlashList, ScrollView+map |
| 3 | Scroll Performance | HIGH | Scroll position tracking, scroll events |
| 4 | Navigation | HIGH | Stack, tabs, expo-router, headers |
| 5 | Animation | HIGH | Reanimated, gestures, press states |
| 6 | State Management | MEDIUM | useState, derived state |
| 7 | User Interface | MEDIUM | Safe areas, images, Pressable |
| 8 | Platform | MEDIUM | iOS/Android differences, shadows |

## Supporting files

- `references/rules.md` - Full rules reference with code examples
