# ADR-0001: API Versioning Strategy

**Status**: Accepted  
**Date**: 2025-12-04 (updated)

## Context

The mobile app needs to support multiple API versions (v1, v2) for the primary API. Version prefixes (e.g., `/v1/orders`, `/v2/orders`) are part of the endpoint path. Most endpoints use v1, but specific repositories may need v2 for all their endpoints.

**Key constraints**:
- Primary API uses versioned endpoints (`/v1/...`, `/v2/...`)
- Secondary API does NOT use versioning (no prefix)
- Version is a property of the repository/domain, not the HTTP transport layer
- When migrating to v2, there will be DTO/mapper/type changes anyway — version change is explicit

## Use Cases

- **UC1**: Most repositories use v1 by default
- **UC2**: Specific repositories (e.g., OrderRepository) use v2 for all endpoints
- **UC3**: Secondary API repositories don't use version prefix at all
- **UC4**: Future: partial migration (some methods v1, some v2) should be possible

## Options Considered

### Option 1: Version in HTTP Client (defaultApiVersion in factory)

Add `defaultApiVersion` to HTTP client options with interceptor prepending version.

**Pros**:
- Centralized version logic
- Automatic for all requests

**Cons**:
- Primary and Secondary API have different versioning needs — one uses versions, other doesn't
- Version is infrastructure concern, but it's really a domain/repository concern
- Hard to have mixed versions in same repository
- Interceptor logic adds complexity

### Option 2: Settings Getter in Repository Constructor

Pass `getSettings()` function to repository, check feature flags at runtime.

**Pros**:
- Runtime flexibility based on mobile settings

**Cons**:
- Every repository depends on settings even if not needed
- Complex wiring in ApiProvider
- Business requirement changed: flags like `useOrderVerificationApiV2` are no longer used
- Pollutes repository constructor with unnecessary dependency

### Option 3: BaseRepository with apiVersion Property (Chosen)

Create `BaseRepository` abstract class with `protected apiVersion` property and `versionedPath()` helper. Each repository inherits and can override version.

**Pros**:
- Version is a property of the repository (where it belongs)
- Clean OOP pattern with inheritance
- DRY: helper method in one place
- Easy override per repository
- Repositories for non-versioned APIs (secondary) simply don't use `versionedPath()`
- No changes to HTTP client needed
- Explicit and readable: `this.versionedPath("/orders")`
- TypeScript-friendly: protected readonly with override

**Cons**:
- Requires inheritance (acceptable for repositories)
- Version change requires code change (but so do DTO/mapper changes for v2)

## Decision

We chose **Option 3 (BaseRepository with apiVersion property)** because:

1. Version is a domain/repository concern, not HTTP transport concern
2. Primary and Secondary APIs have different versioning needs — this approach handles both
3. Clean OOP pattern with explicit override when needed
4. No unnecessary dependencies (no settings getter)
5. When v2 is needed, repository simply overrides `apiVersion = "v2"`
6. Non-versioned API repositories don't use `versionedPath()` at all

## Implementation

### BaseRepository

```typescript
// infrastructure/repositories/BaseRepository.ts
import type { HttpClient } from "@/infrastructure/http/core/httpClientFactory";

export abstract class BaseRepository {
  protected readonly apiVersion: string = "v1";

  constructor(protected readonly client: HttpClient) {}

  /**
   * Prepends API version to path: "/orders" → "/v1/orders"
   * Use for versioned APIs (primary). Skip for non-versioned APIs (secondary).
   */
  protected versionedPath(path: string): string {
    const cleanPath = path.startsWith("/") ? path : `/${path}`;
    return `/${this.apiVersion}${cleanPath}`;
  }
}
```

### Repository with Default v1

```typescript
// infrastructure/repositories/PortfolioRepository.ts
export class PortfolioRepository extends BaseRepository implements IPortfolioService {
  // Uses inherited apiVersion = "v1"

  async getPositions(): Promise<Position[]> {
    const { data } = await this.client.get<PositionListDTO>(
      this.versionedPath("/portfolio/positions")
    );
    return data.positions.map(positionMapper.toDomain);
  }
}
```

### Repository with v2 Override

```typescript
// infrastructure/repositories/OrderRepository.ts
export class OrderRepository extends BaseRepository implements IOrderService {
  protected readonly apiVersion = "v2"; // Override to v2 for all order endpoints

  async verifyOrder(orderId: string): Promise<OrderVerification> {
    const { data } = await this.client.get<OrderVerificationDTO>(
      this.versionedPath(`/trading/orders/${orderId}/verify`)
    );
    return orderMapper.toDomain(data);
  }

  async getOrders(): Promise<Order[]> {
    const { data } = await this.client.get<OrderListDTO>(
      this.versionedPath("/trading/orders")
    );
    return data.orders.map(orderMapper.toDomain);
  }
}
```

### Repository for Non-Versioned API (Secondary)

```typescript
// infrastructure/repositories/WidgetRepository.ts
export class WidgetRepository extends BaseRepository implements IWidgetService {
  // Don't use versionedPath() — secondary API has no version prefix

  async getWidgets(): Promise<Widget[]> {
    const { data } = await this.client.get<WidgetListDTO>("/widgets");
    return data.widgets.map(widgetMapper.toDomain);
  }
}
```

### ApiProvider (Simplified)

```typescript
// composition/ApiProvider.tsx
export function ApiProvider({ children }: { children: React.ReactNode }) {
  const services = useMemo<ApiContextValue>(() => ({
    // Primary API (versioned)
    portfolioService: new PortfolioRepository(httpClientPrimary),
    orderService: new OrderRepository(httpClientPrimary), // Uses v2 internally
    
    // Secondary API (non-versioned)
    widgetService: new WidgetRepository(httpClientSecondary),
  }), []);

  return <ApiContext.Provider value={services}>{children}</ApiContext.Provider>;
}
```

## Consequences

### What Becomes Easier

- Adding new versioned repositories (just extend BaseRepository)
- Migrating specific repository to v2 (override `apiVersion`)
- Supporting mixed versioning needs (primary vs secondary API)
- Testing (version is just a property, no mocking needed)
- Code readability (`this.versionedPath()` is explicit)

### What Becomes Harder

- Partial migration within single repository (some methods v1, some v2) — requires manual path construction for exceptions
- Version change requires code change (but this is acceptable since DTO/mapper changes are needed anyway)

### HTTP Client Changes

The HTTP client factory no longer handles versioning:
- Remove `defaultApiVersion` from `HttpClientOptions`
- Remove `apiVersion` from `RequestConfig`
- Remove version prepending logic from request interceptor

Version is now purely a repository concern.

## Future Considerations

If partial migration within a repository is needed (some methods v1, some v2):

```typescript
export class MixedRepository extends BaseRepository {
  protected readonly apiVersion = "v1"; // Default

  async methodUsingV1(): Promise<Data> {
    return this.client.get(this.versionedPath("/endpoint")); // → /v1/endpoint
  }

  async methodUsingV2(): Promise<Data> {
    return this.client.get("/v2/endpoint"); // Explicit v2 path
  }
}
```

This is acceptable for rare edge cases. If a repository needs significant mixed versions, consider splitting into separate repositories.
