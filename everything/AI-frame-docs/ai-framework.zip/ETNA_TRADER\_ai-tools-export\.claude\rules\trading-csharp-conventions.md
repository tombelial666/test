# C# Coding Conventions — ETNA_TRADER

## Namespace Patterns

Follow the `Etna.<Layer>.<Sublayer>` hierarchy:

```csharp
// Contracts (interfaces, DTOs, enums — no implementation)
namespace Etna.Trading.Contracts.Orders;
namespace Etna.Trading.Contracts.Accounts;
namespace Etna.Trading.Contracts.Positions;
namespace Etna.Common.Contracts;

// Services (business logic)
namespace Etna.Trader.FrontOffice.Services;
namespace Etna.Trading.Services.Orders;
namespace Etna.Trading.Services.Accounts;

// DAL — Entity Framework
namespace Etna.Dao.EntityFramework.Repositories;
namespace Etna.Dao.EntityFramework.Entities;

// DAL — NHibernate
namespace Etna.Dao.NHibernate.Repositories;
namespace Etna.Dao.NHibernate.Mappings;

// Infrastructure / Common
namespace Etna.Common.NLog;
namespace Etna.Common.Serilog;
namespace Etna.Common.Unity;
namespace Etna.Common.Extensions;
```

### Layer Import Rules

```
Contracts   ← no dependencies on Services/DAL
Services    ← depends on Contracts only
DAL         ← depends on Contracts only
API         ← depends on Services (via Contracts interfaces)
Infrastructure ← depends on Contracts
```

Never import a higher layer from a lower layer. Never import DAL directly from API controllers (go through Services).

## Interface Naming

- Prefix with `I`, PascalCase: `IOrderService`, `IAccountRepository`
- Interface file name matches: `IOrderService.cs`
- Implementation file: `OrderService.cs` (no suffix needed)

```csharp
// Contracts layer — interface
namespace Etna.Trading.Contracts.Orders;

public interface IOrderService
{
    Task<OrderDto> PlaceOrderAsync(PlaceOrderRequest request, CancellationToken cancellationToken);
    Task<OrderDto?> GetOrderAsync(string orderId, CancellationToken cancellationToken);
    Task CancelOrderAsync(string orderId, CancellationToken cancellationToken);
}

// Repository interface — always in Contracts or DAL.Contracts
public interface IOrderRepository
{
    Task<Order?> GetByIdAsync(string id, CancellationToken cancellationToken);
    Task<IReadOnlyList<Order>> GetByAccountAsync(string accountId, OrderQueryParams query, CancellationToken cancellationToken);
    Task<Order> AddAsync(Order order, CancellationToken cancellationToken);
    Task UpdateAsync(Order order, CancellationToken cancellationToken);
}
```

## Async/Await Patterns

### ConfigureAwait(false)

Use `ConfigureAwait(false)` in **all library/service/repository code** (not in ASP.NET controller actions where synchronization context matters):

```csharp
// ✅ Service layer — always ConfigureAwait(false)
public async Task<OrderDto> PlaceOrderAsync(PlaceOrderRequest request, CancellationToken cancellationToken)
{
    var account = await _accountRepository.GetByIdAsync(request.AccountId, cancellationToken).ConfigureAwait(false);
    if (account is null)
        throw new NotFoundException($"Account '{request.AccountId}' not found.");

    var order = _orderFactory.Create(request, account);
    order = await _orderRepository.AddAsync(order, cancellationToken).ConfigureAwait(false);

    await _eventPublisher.PublishAsync(new OrderPlacedEvent(order), cancellationToken).ConfigureAwait(false);

    return _orderMapper.ToDto(order);
}

// ✅ Repository layer — always ConfigureAwait(false)
public async Task<Order?> GetByIdAsync(string id, CancellationToken cancellationToken)
{
    return await _dbContext.Orders
        .AsNoTracking()
        .FirstOrDefaultAsync(o => o.Id == id, cancellationToken)
        .ConfigureAwait(false);
}

// Controller actions — ConfigureAwait not required (ASP.NET Core has no sync context)
[HttpPost]
public async Task<ActionResult<OrderDto>> PlaceOrder([FromBody] PlaceOrderRequest request, CancellationToken cancellationToken)
{
    var result = await _orderService.PlaceOrderAsync(request, cancellationToken);
    return CreatedAtAction(nameof(GetOrder), new { orderId = result.Id }, result);
}
```

### CancellationToken Propagation

- Every `async` public method accepts `CancellationToken cancellationToken` as the last parameter
- Pass it through to every downstream `async` call
- Never ignore a passed-in token; never create a new `CancellationTokenSource` just to discard the caller's token

```csharp
// ✅ Always propagate
public async Task<IReadOnlyList<PositionDto>> GetPositionsAsync(
    string accountId,
    CancellationToken cancellationToken)
{
    var positions = await _positionRepository
        .GetByAccountAsync(accountId, cancellationToken)
        .ConfigureAwait(false);

    return positions.Select(_positionMapper.ToDto).ToList();
}

// ❌ Never swallow the token
public async Task<IReadOnlyList<PositionDto>> GetPositionsAsync(string accountId)
{
    var positions = await _positionRepository
        .GetByAccountAsync(accountId, CancellationToken.None)  // ← wrong
        .ConfigureAwait(false);
    // ...
}
```

## Logging Patterns

### NLog (Etna.Common.NLog)

```csharp
using NLog;

public class OrderService : IOrderService
{
    private static readonly ILogger Log = LogManager.GetCurrentClassLogger();

    public async Task<OrderDto> PlaceOrderAsync(PlaceOrderRequest request, CancellationToken cancellationToken)
    {
        Log.Info("Placing order | AccountId={AccountId} Symbol={Symbol} Side={Side} Qty={Quantity}",
            request.AccountId, request.Symbol, request.Side, request.Quantity);

        try
        {
            var order = await PlaceInternalAsync(request, cancellationToken).ConfigureAwait(false);

            Log.Info("Order placed successfully | OrderId={OrderId} AccountId={AccountId}",
                order.Id, order.AccountId);

            return _mapper.ToDto(order);
        }
        catch (Exception ex)
        {
            Log.Error(ex, "Failed to place order | AccountId={AccountId} Symbol={Symbol}",
                request.AccountId, request.Symbol);
            throw;
        }
    }
}
```

### Serilog (Etna.Common.Serilog)

```csharp
using Serilog;

public class AccountService : IAccountService
{
    private readonly ILogger _log = Log.ForContext<AccountService>();

    public async Task<AccountDto?> GetAccountAsync(string accountId, CancellationToken cancellationToken)
    {
        _log.Debug("Fetching account {AccountId}", accountId);

        var account = await _repository.GetByIdAsync(accountId, cancellationToken).ConfigureAwait(false);

        if (account is null)
        {
            _log.Warning("Account not found {AccountId}", accountId);
            return null;
        }

        return _mapper.ToDto(account);
    }
}
```

### Logging Rules

- Log **entry and exit** of high-value operations (order placement, cancel, amend)
- Log **structured data** (named parameters), never string interpolation: `{AccountId}` not `$"{accountId}"`
- Log **at the right level**: Debug for verbose traces, Info for business events, Warning for recoverable issues, Error for exceptions
- Never log **sensitive data**: passwords, full card numbers, raw auth tokens
- Never log inside tight loops (per-tick market data processing); use counters/aggregates

## Unity DI Registration (Etna.Common.Unity)

```csharp
// Etna.Trader.Api/Composition/TradingModule.cs
using Unity;

public static class TradingModule
{
    public static IUnityContainer RegisterTradingServices(this IUnityContainer container)
    {
        // Services — transient per request
        container.RegisterType<IOrderService, OrderService>(new HierarchicalLifetimeManager());
        container.RegisterType<IAccountService, AccountService>(new HierarchicalLifetimeManager());
        container.RegisterType<IPositionService, PositionService>(new HierarchicalLifetimeManager());

        // Repositories — transient
        container.RegisterType<IOrderRepository, OrderRepository>(new TransientLifetimeManager());
        container.RegisterType<IAccountRepository, AccountRepository>(new TransientLifetimeManager());

        // Mappers — singleton (stateless)
        container.RegisterType<IOrderMapper, OrderMapper>(new ContainerControlledLifetimeManager());
        container.RegisterType<IPositionMapper, PositionMapper>(new ContainerControlledLifetimeManager());

        return container;
    }
}
```

### Registration Lifetime Guidelines

| Type | Lifetime | Reason |
|------|----------|--------|
| Stateless mappers | Singleton | No mutable state |
| Services | Per-request (Hierarchical) | May hold request-scoped state |
| Repositories | Transient | EF DbContext is not thread-safe |
| EF DbContext | Per-request | Unit of work pattern |
| NHibernate Session | Per-request | Same reasoning |

## Null Handling

### Nullable Reference Types

Enabled project-wide (`<Nullable>enable</Nullable>` in `.csproj`).

```csharp
// Return null-annotated type when absence is valid
Task<Order?> GetOrderAsync(string id, CancellationToken ct);

// Non-null guarantee via guard
public OrderService(IOrderRepository repository, ILogger<OrderService> logger)
{
    _repository = repository ?? throw new ArgumentNullException(nameof(repository));
    _logger = logger ?? throw new ArgumentNullException(nameof(logger));
}
```

### Guard Clauses (fail fast, fail clearly)

```csharp
public async Task<OrderDto> PlaceOrderAsync(PlaceOrderRequest request, CancellationToken cancellationToken)
{
    ArgumentNullException.ThrowIfNull(request);
    ArgumentException.ThrowIfNullOrWhiteSpace(request.AccountId);
    ArgumentException.ThrowIfNullOrWhiteSpace(request.Symbol);

    if (request.Quantity <= 0)
        throw new ArgumentOutOfRangeException(nameof(request.Quantity), "Quantity must be positive.");

    // rest of method
}
```

### Null-Conditional / Null-Coalescing

```csharp
// ✅ Null-conditional for optional chaining
var symbol = order?.Symbol ?? throw new InvalidOperationException("Order has no symbol.");

// ✅ Null-coalescing for defaults
var pageSize = queryParams.PageSize > 0 ? queryParams.PageSize : 50;

// ✅ Pattern matching for typed null check
if (result is not null)
{
    ProcessResult(result);
}
```

## General Conventions

- **`var`** for local variables when the type is obvious from the right-hand side; explicit type when not
- **`record`** for immutable DTOs and value objects (C# 9+)
- **`init`** property setters for immutable data classes
- **File-scoped namespaces** (`namespace Etna.Trading.Services;`) — one per file
- **Primary constructors** (C# 12) allowed for simple service/repo constructors
- **Expression-bodied members** for single-line properties and simple methods
- **`string.Empty`** not `""` for empty string initialization
- **`is null` / `is not null`** not `== null` / `!= null`
- No magic numbers — use named constants or enums
- No `Thread.Sleep` — use `Task.Delay` with a `CancellationToken`
- No `async void` — use `async Task` (except for event handlers, which require `async void`)
