# Testing Architecture

## File Naming

- Unit tests: `*.spec.ts` or `*.spec.tsx`
- Integration tests: `*.integration.spec.ts` or `*.integration.spec.tsx`

**Examples:**

```
src/infrastructure/mappers/positionMapper.ts
tests/unit/infrastructure/mappers/positionMapper.spec.ts

src/features/portfolio/screens/PortfolioScreen.tsx
tests/integration/features/portfolio/screens/PortfolioScreen.integration.spec.tsx
```

## When to Write Tests

### Unit Test — logic is isolated & deterministic
- **domain**: entities, value-objects, invariants, pure validation
- **infrastructure**: DTO ↔ model mappers, formatters, repositories with mocked HTTP
- **shared**: utilities (date, currency, number), small presentational components
- **store**: selectors and slices/reducers (no real IO)
- Hooks that are pure or can be tested with mocked deps

### Integration Test — real flow across layers
- Feature facade hooks using React Query (queries/mutations + cache invalidation)
- Screens with real providers: `ApiProvider`, `QueryProvider`, `StoreProvider`, `HttpProvider`
- Use-case scenarios: validation → port calls → side-effects (analytics, cache)
- Navigation and error flows (e.g., 401 redirect via `HttpProvider`)
- Cross-API cases (primary/secondary) and cache coherence

### Optional / Not Required
- Thin glue without logic already covered by an integration test higher up

## Factories & Mocks

Keep reusable builders in `/tests/factories`. Never import from `src/`:

```
/tests/factories
  /domain/entities/
    Position.factory.ts
    Order.factory.ts
  /infrastructure/dto/
    PositionDTO.factory.ts
    OrderDTO.factory.ts
  /scenarios/
    portfolioScenario.factory.ts
  factoryCore.ts           ← makeFactory, seq, deepMerge
```

**Factory core:**

```ts
// tests/factories/factoryCore.ts
export type DeepPartial<T> = { [K in keyof T]?: T[K] extends object ? DeepPartial<T[K]> : T[K] };

export function makeFactory<T>(defaults: () => T) {
  const build = (overrides?: DeepPartial<T>): T => Object.assign(defaults(), overrides ?? {});
  (build as any).list = (n = 1, map?: (i: number) => DeepPartial<T>) =>
    Array.from({ length: n }, (_, i) => build(map?.(i)));
  return build as typeof build & { list: (n?: number, map?: (i: number) => DeepPartial<T>) => T[] };
}
```

**Domain factory example:**

```ts
// tests/factories/domain/entities/Position.factory.ts
import { makeFactory } from "../../factoryCore";
import type { Position } from "@/domain/entities/Position";

export const positionFactory = makeFactory<Position>(() => ({
  id: "pos_1",
  symbol: "AAPL",
  quantity: 10,
  averagePrice: { cents: 12345, currency: "USD" },
}));
```

## Config Files

- Root Jest config: `/jest.config.js`
- Global setup: `/tests/setup.ts`

## Path Mirroring

```
src/domain/entities/Order.ts
tests/unit/domain/entities/Order.spec.ts

src/application/trading/placeOrder.ts
tests/integration/application/trading/placeOrder.integration.spec.ts

src/features/trading/screens/PlaceOrderScreen.tsx
tests/integration/features/trading/screens/PlaceOrderScreen.integration.spec.tsx
```

## Test Style

- Clear **Arrange → Act → Assert** structure
- Descriptive titles: `it("submits order and invalidates positions")`
- Mock only external dependencies (ports/HTTP), not internals
- Use snapshots sparingly and only for stable presentational output
