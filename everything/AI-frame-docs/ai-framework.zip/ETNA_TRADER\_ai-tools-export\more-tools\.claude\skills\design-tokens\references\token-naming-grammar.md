# Token Naming Grammar

**Version**: 1.0.0

Reference for naming design tokens when creating or reviewing them.

---

## 1. Full Grammar

Token names are composed of **up to 7 parts**:

```
location.compoundComponent.component.usage.sentiment.prominence-interaction
```

- **Context** (3 sub-parts): `location.compoundComponent.component`
- **Usage**: element the token applies to
- **Modifier** (3 sub-parts): `sentiment.prominence-interaction`

Parts set to `default` are **omitted** from the stored name.

### Delimiters

- Parts separated by `.` (dot)
- The `interaction` suffix uses `-` (dash) and appears **only at the end**

---

## 2. Context (Location / Compound Component / Component)

### Location

| Value | Description |
|-------|-------------|
| `default` | Main content area (omitted) |
| `marketing` | Marketing pages |
| `login` | Login pages |
| `sidepanel` | Right side panel |

### Compound Component

| Value | Description |
|-------|-------------|
| `default` | Not inside a compound component (omitted) |
| `card` | Inside cards |
| `table` | Inside table items |
| `filter` | Inside filters |
| `leftnav` | Left navigation |
| `topnav` | Top navigation |

### Component

| Value | Description |
|-------|-------------|
| `default` | Not inside a specific component (omitted) |
| `tooltip` | Inside tooltip |
| `link` | Link component |
| `control` | Controls (checkbox, radio, toggle) |
| `field` | Fields (input, search, etc.) |

---

## 3. Usage

What element the token is applied to:

| Value | Description |
|-------|-------------|
| `background` | Background color |
| `text` | Text color |
| `icon` | Icon color |
| `border` | Border color |
| `shell` | Shell/container color |

---

## 4. Modifier (Sentiment / Prominence / Interaction)

### Sentiment

| Value | Description |
|-------|-------------|
| `default` | No sentiment (omitted) |
| `brand` | Brand color |
| `success` | Success state |
| `warning` | Warning state |
| `danger` | Danger/error state |
| `info` | Informational state |
| `trial` | Trial state |
| `accent` | Accent color |
| `on*` | Element ON a sentiment background (see below) |

#### `on*` Sentiment Rule

`on*` means "this element is placed on a sentiment-colored background".

Allowed values: `onbrand`, `onsuccess`, `onwarning`, `ondanger`, `oninfo`, `ontrial`, `onaccent`

**Not allowed**: `ondefault`

Examples:
- `icon.brand` — icon uses the brand color on a default background
- `icon.onbrand` — icon is placed on a brand-colored background (needs contrast-safe color)

### Prominence

| Value | Description |
|-------|-------------|
| `strong` | Highest prominence |
| `base` | Default prominence |
| `secondary` | Lower prominence |
| `tertiary` | Lowest prominence |

### Interaction (dash-delimited suffix)

| Value | Description |
|-------|-------------|
| `-default` | No interaction (omitted) |
| `-hover` | Hover state |
| `-active` | Active/pressed state |
| `-disabled` | Disabled state |
| `-selected` | Selected state |

---

## 5. Omission Rules

Any part set to `default` is dropped from the final token name:

- `default.default.default` context → omit entirely
- `default` sentiment → omit
- `-default` interaction → omit

**Conceptual** (fully expanded): `default.default.default.icon.default.secondary-default`
**Stored**: `icon.secondary`

---

## 6. Token Creation Workflow

When creating a token:

1. Choose **exactly one** value from each group: Location, Compound Component, Component, Usage, Sentiment, Prominence, Interaction
2. Apply the `on*` prefix to sentiment when needed (still exactly one sentiment)
3. Apply omission rules — drop all `default` parts
4. Validate the final name:
   - Interaction (`-hover`, etc.) appears only at the end
   - No extra dots
   - No `ondefault`
   - Parts follow order: `context.usage.sentiment.prominence-interaction`

---

## 7. General vs Context Tokens

- **General tokens** (no context parts): system defaults — updating them propagates to all components using them
- **Context tokens** (with context parts): overrides for a specific location/component

Rule of thumb:
- Universal meaning → create/adjust a **general token**
- Meaning differs inside a context only → create a **context override token**

---

## 8. Canonical Examples

| Example | Expanded (conceptual) | Stored |
|---------|----------------------|--------|
| Secondary icon | `default.default.default.icon.default.secondary-default` | `icon.secondary` |
| Brand button text | `default.default.default.text.brand.strong-default` | `text.brand.strong` |
| Field border hover on brand background | `default.default.field.border.onbrand.secondary-hover` | `field.border.onbrand.secondary-hover` |
| Context override (filter field bg) | — | `filter.field.background.base` |
| Disabled control icon in card | `default.card.control.icon.default.secondary-disabled` | `card.control.icon.secondary-disabled` |

---

## 9. Validation Checklist

Before finalizing a token name:

- [ ] Each part uses only allowed values from the tables above
- [ ] Interaction (`-hover`, `-active`, etc.) appears only at the end
- [ ] No `ondefault` is used
- [ ] All `default` parts are omitted from the final name
- [ ] Parts separated by `.` (except interaction which uses `-`)
- [ ] Order follows: `context.usage.sentiment.prominence-interaction`
