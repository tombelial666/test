"""Фикстуры для проверки структуры tasks/output (см. input-folder-dual-output.mdc)."""

from __future__ import annotations

from pathlib import Path

import pytest


@pytest.fixture(scope="session")
def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


@pytest.fixture
def tasks_output(repo_root: Path) -> Path:
    return repo_root / "tasks" / "output"


@pytest.fixture
def tasks_input(repo_root: Path) -> Path:
    return repo_root / "tasks" / "input"
