# Design Tokens System

Comprehensive guide for using design tokens in the mobile app.

---

## Table of Contents

- [Overview](#overview)
- [Quick Start](#quick-start)
- [Token Structure](#token-structure)
- [Usage Guide](#usage-guide)
- [Theme Switching](#theme-switching)
- [Adding New Tokens](#adding-new-tokens)
- [Brand Customization](#brand-customization)
- [Migration Guide](#migration-guide)
- [Troubleshooting](#troubleshooting)

---

## Overview

### What Are Design Tokens?

Design tokens are the visual design atoms of the design system — specifically named entities that store visual design attributes. We use them to maintain a consistent UI across the app.

**In this app**: Design tokens replace all hardcoded color values with semantic, themed variables.

### Why Design Tokens?

See [ADR-0008: Design Tokens System](./adr/0008-design-tokens-system.md) for the full rationale, options considered, and decision context.

### Architecture

See [ADR-0008: Implementation Architecture](./adr/0008-design-tokens-system.md#implementation-architecture) for the file structure.

---

## Quick Start

### 1. Import the Hook

```tsx
import { useThemeColors } from '@/shared/theme/hooks';
```

### 2. Use Tokens in Your Component

```tsx
function MyButton() {
  const colors = useThemeColors();

  return (
    <TouchableOpacity
      style={{
        backgroundColor: colors.background.brand?.base,
        padding: 16,
        borderRadius: 8
      }}
    >
      <Text style={{ color: colors.text.onbrand?.base }}>
        Click Me
      </Text>
    </TouchableOpacity>
  );
}
```

### 3. Run the App

Colors automatically adapt to light/dark mode!

---

## Token Structure

### Naming Convention

Tokens follow this hierarchy:

```
location.compoundcomponent.component.usage.sentiment.prominence-interaction
```

**Parts** (defaults are omitted):
- **Location**: `default` | `login` | `marketing` | `sidepanel`
- **Compound Component**: `default` | `card` | `table` | `filter` | `leftnav` | `topnav`
- **Component**: `default` | `link` | `field` | `control` | `tooltip`
- **Usage**: `background` | `text` | `icon` | `border` | `shell`
- **Sentiment**: `default` | `brand` | `success` | `warning` | `danger` | `info` | `onbrand` | `ondanger` | ...
- **Prominence**: `base` | `secondary` | `tertiary` | `strong`
- **Interaction**: `-hover` | `-active` | `-disabled` | `-selected`

### Examples

| Token Path | Meaning |
|------------|---------|
| `text.base` | Primary text color (default context) |
| `background.brand?.base` | Brand color background |
| `text.onbrand?.base` | Text on brand background |
| `field.border.focus` | Input field focus border |
| `link.text.hover` | Link hover state |
| `card.background.base` | Card background |
| `table.text.header` | Table header text |

---

## Usage Guide

### Core Tokens (Most Common)

#### Text Colors

```tsx
const colors = useThemeColors();

<Text style={{ color: colors.text.base }}>Primary</Text>
<Text style={{ color: colors.text.secondary }}>Secondary</Text>
<Text style={{ color: colors.text.tertiary }}>Tertiary</Text>
<Text style={{ color: colors.text.disabled }}>Disabled</Text>
```

#### Backgrounds

```tsx
<View style={{ backgroundColor: colors.background.base }}>
  <View style={{ backgroundColor: colors.background.secondary }}>
    <View style={{ backgroundColor: colors.background.tertiary }}>
```

#### Borders

```tsx
<View
  style={{
    borderWidth: 1,
    borderColor: colors.border.base
  }}
/>
```

### Sentiment Tokens

Sentiment tokens convey meaning (brand, success, error, etc.).

```tsx
// Brand (primary actions)
<TouchableOpacity
  style={{ backgroundColor: colors.background.brand?.base }}
>
  <Text style={{ color: colors.text.onbrand?.base }}>
    Sign In
  </Text>
</TouchableOpacity>

// Success
<View style={{ backgroundColor: colors.background.success?.base }}>
  <Text style={{ color: colors.text.onsuccess?.base }}>
    Success!
  </Text>
</View>

// Danger (destructive actions)
<TouchableOpacity
  style={{ backgroundColor: colors.background.danger?.base }}
>
  <Text style={{ color: colors.text.ondanger?.base }}>
    Delete
  </Text>
</TouchableOpacity>

// Warning
<Text style={{ color: colors.text.warning?.base }}>
  Warning message
</Text>

// Info
<Text style={{ color: colors.text.info?.base }}>
  Info message
</Text>
```

**Note**: Use optional chaining (`?.`) for sentiment tokens.

### Component Tokens

#### Links

```tsx
const [pressed, setPressed] = useState(false);

<Pressable
  onPressIn={() => setPressed(true)}
  onPressOut={() => setPressed(false)}
>
  <Text
    style={{
      color: pressed
        ? colors.link.text.active
        : colors.link.text.base
    }}
  >
    Click here
  </Text>
</Pressable>
```

#### Form Fields

```tsx
const [focused, setFocused] = useState(false);
const [hasError, setHasError] = useState(false);

<TextInput
  style={{
    backgroundColor: colors.field.background.base,
    borderWidth: 1,
    borderColor: hasError
      ? colors.field.border.error
      : focused
      ? colors.field.border.focus
      : colors.field.border.base,
    color: colors.field.text.base,
    padding: 12
  }}
  placeholderTextColor={colors.field.text.placeholder}
  onFocus={() => setFocused(true)}
  onBlur={() => setFocused(false)}
/>
```

#### Controls (Checkbox, Radio, Toggle)

```tsx
const [checked, setChecked] = useState(false);

<TouchableOpacity
  onPress={() => setChecked(!checked)}
  style={{
    backgroundColor: checked
      ? colors.control.background.checked
      : colors.control.background.base,
    borderWidth: 1,
    borderColor: checked
      ? colors.control.border.checked
      : colors.control.border.base,
    width: 24,
    height: 24
  }}
>
  {checked && (
    <Icon
      name="check"
      color={colors.control.icon.checked}
    />
  )}
</TouchableOpacity>
```

### Compound Component Tokens

#### Cards

```tsx
<View
  style={{
    backgroundColor: colors.card.background.base,
    borderWidth: 1,
    borderColor: colors.card.border.base,
    borderRadius: 8,
    padding: 16
  }}
>
  <Text style={{ color: colors.text.base }}>
    Card Content
  </Text>
</View>
```

#### Tables

```tsx
<View style={{ backgroundColor: colors.table.background.base }}>
  <View style={{ backgroundColor: colors.table.background.header }}>
    <Text style={{ color: colors.table.text.header }}>
      Header
    </Text>
  </View>
  <View style={{ backgroundColor: colors.table.background.row }}>
    <Text style={{ color: colors.table.text.cell }}>
      Cell
    </Text>
  </View>
</View>
```

#### Navigation

```tsx
function NavItem({ active }: { active: boolean }) {
  const colors = useThemeColors();

  return (
    <View style={{ backgroundColor: colors.leftnav.background.base }}>
      <Text
        style={{
          color: active
            ? colors.leftnav.text.active
            : colors.leftnav.text.base
        }}
      >
        Navigation Item
      </Text>
      <Icon
        color={active
          ? colors.leftnav.icon.active
          : colors.leftnav.icon.base
        }
      />
    </View>
  );
}
```

---

## Theme Switching

### Accessing Theme State

```tsx
import { useTheme } from '@/shared/theme/hooks';

function ThemeControls() {
  const {
    theme,           // 'light' | 'dark'
    isDark,          // boolean
    isManualOverride, // boolean
    setTheme,        // (theme: 'light' | 'dark') => void
    toggleTheme,     // () => void
    resetToSystem    // () => void
  } = useTheme();

  return (
    <View>
      <Text>Current theme: {theme}</Text>
      <Text>Is dark mode: {isDark ? 'Yes' : 'No'}</Text>
      <Text>Manual override: {isManualOverride ? 'Yes' : 'No'}</Text>

      <Button title="Toggle Theme" onPress={toggleTheme} />
      <Button title="Set Light" onPress={() => setTheme('light')} />
      <Button title="Set Dark" onPress={() => setTheme('dark')} />
      <Button title="Reset to System" onPress={resetToSystem} />
    </View>
  );
}
```

### Theme Persistence

- **System theme**: Automatically detected via `useColorScheme()`
- **Manual override**: Persisted to `AsyncStorage` (survives app restarts)
- **Reset**: `resetToSystem()` clears manual override

---

## Adding New Tokens

### 1. Define in Type System

Edit `src/shared/theme/tokens/types.ts`:

```ts
export interface TextTokens {
  base: ColorValue;
  secondary: ColorValue;
  // Add new token
  newToken: ColorValue;  // ← Add here
}
```

### 2. Add Light Theme Value

Edit `src/shared/theme/tokens/light.ts`:

```ts
export const lightTheme: ThemeTokens = {
  text: {
    base: '#000000',
    secondary: '#666666',
    newToken: '#YOUR_LIGHT_COLOR',  // ← Add here
  },
  // ...
};
```

### 3. Add Dark Theme Value

Edit `src/shared/theme/tokens/dark.ts`:

```ts
export const darkTheme: ThemeTokens = {
  text: {
    base: '#FFFFFF',
    secondary: '#EEEEEE',
    newToken: '#YOUR_DARK_COLOR',  // ← Add here
  },
  // ...
};
```

### 4. Use the New Token

```tsx
const colors = useThemeColors();

<Text style={{ color: colors.text.newToken }}>
  Using new token
</Text>
```

TypeScript will autocomplete and type-check!

---

For brand customization (adding new brands, overriding colors per brand), see [docs/theme-system-guide.md](./theme-system-guide.md#adding-a-new-brand).

---

## Migration Guide

### Replacing Hardcoded Colors

**Before:**
```tsx
<View style={{ backgroundColor: '#FFFFFF' }}>
  <Text style={{ color: '#000000' }}>Hello</Text>
  <View style={{ borderColor: '#CCCCCC' }} />
</View>
```

**After:**
```tsx
import { useThemeColors } from '@/shared/theme/hooks';

function MyComponent() {
  const colors = useThemeColors();

  return (
    <View style={{ backgroundColor: colors.background.base }}>
      <Text style={{ color: colors.text.base }}>Hello</Text>
      <View style={{ borderColor: colors.border.base }} />
    </View>
  );
}
```

### StyleSheet Migration

**Before:**
```tsx
const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FFFFFF',
  },
  text: {
    color: '#000000',
  },
});
```

**After:**
```tsx
function MyComponent() {
  const colors = useThemeColors();

  const styles = StyleSheet.create({
    container: {
      backgroundColor: colors.background.base,
    },
    text: {
      color: colors.text.base,
    },
  });

  return <View style={styles.container} />;
}
```

Or use inline styles for colors:

```tsx
const styles = StyleSheet.create({
  container: {
    padding: 16,  // Non-color styles
    borderRadius: 8,
  },
});

function MyComponent() {
  const colors = useThemeColors();

  return (
    <View
      style={[
        styles.container,
        { backgroundColor: colors.background.base }
      ]}
    />
  );
}
```

---

## Troubleshooting

### Token Returns `undefined`

**Problem**: `colors.text.brand.base` causes error

**Solution**: Sentiment tokens are optional. Use optional chaining:
```tsx
colors.text.brand?.base
```

Or provide fallback:
```tsx
colors.text.brand?.base ?? colors.text.base
```

### Wrong Colors in Dark Mode

**Check**:
1. Is `ThemeProvider` wrapping your app? (See `app/_layout.tsx`)
2. Are dark theme colors defined in `src/shared/theme/tokens/dark.ts`?
3. Test theme manually: `const { theme, setTheme } = useTheme();`

### TypeScript Errors

**Problem**: TypeScript doesn't recognize token path

**Solution**:
1. Ensure hook is imported: `import { useThemeColors } from '@/shared/theme/hooks';`
2. Check token exists in `src/shared/theme/tokens/types.ts`
3. Restart TypeScript server in VS Code

### Pre-commit Hook Blocks Commit

**Problem**: Commit blocked due to hardcoded colors

**Solution**:
1. Replace hardcoded colors with design tokens
2. Use `useThemeColors()` hook
3. Run `npm test` to verify
4. Commit will succeed once fixed

---

## Resources

- **ADR**: [docs/adr/0008-design-tokens-system.md](./adr/0008-design-tokens-system.md)
- **Skill**: Use `/design-tokens` command for interactive guidance
- **Rules**: `.claude/rules/design-tokens.md` - AI agent rules
- **Types**: `src/shared/theme/tokens/types.ts` - TypeScript definitions
- **Light Theme**: `src/shared/theme/tokens/light.ts` - Light mode colors
- **Dark Theme**: `src/shared/theme/tokens/dark.ts` - Dark mode colors

---

## Best Practices

1. **✅ DO**: Use semantic tokens (`text.brand`, `background.success`)
2. **✅ DO**: Use optional chaining for sentiment tokens (`brand?.base`)
3. **✅ DO**: Provide fallbacks when needed (`brand?.base ?? text.base`)
4. **✅ DO**: Use TypeScript autocomplete to discover tokens
5. **❌ DON'T**: Hardcode colors (`#007AFF`, `rgb(0,0,0)`)
6. **❌ DON'T**: Skip `useThemeColors()` hook
7. **❌ DON'T**: Create new tokens unnecessarily - reuse existing ones

---

**Questions?** Run `/design-tokens` command or check the [ADR](./adr/0008-design-tokens-system.md).
