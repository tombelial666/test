"""Автотесты: выдача в tasks/output согласно input-folder-dual-output (both / withF / withoutF)."""

from __future__ import annotations

from pathlib import Path

import pytest

from output_layout_checks import (
    ALLOWED_BRANCHES_BOTH,
    OUT_ID_PATTERN,
    branch_dirs_nonempty,
    iter_out_ids,
    out_dirs_for_slug,
    path_has_forbidden_withF_withoutF_nesting,
    slug_from_stem,
    stem_from_input_path,
    allowed_branches_for_out_id,
)


def test_out_id_directories_match_pattern(tasks_output: Path) -> None:
    for p in tasks_output.iterdir():
        if not p.is_dir():
            continue
        if p.name in ("__pycache__",):
            continue
        assert OUT_ID_PATTERN.match(p.name), (
            f"Каталог в tasks/output должен иметь вид <slug>-vN>, получено: {p.name!r}"
        )


def test_no_flat_withF_or_withoutF_next_to_readme(tasks_output: Path) -> None:
    """Устаревшая плоская схема tasks/output/withF без OUT_ID не допускается."""
    for p in tasks_output.iterdir():
        if not p.is_dir():
            continue
        assert p.name not in ("withF", "withoutF"), (
            f"Запрещена плоская папка tasks/output/{p.name}/ без уровня OUT_ID"
        )


def test_no_forbidden_nested_withF_withoutF_anywhere(tasks_output: Path) -> None:
    if not tasks_output.is_dir():
        pytest.skip("нет tasks/output")
    for p in tasks_output.rglob("*"):
        if p.is_dir() and path_has_forbidden_withF_withoutF_nesting(p):
            pytest.fail(f"Запрещённая вложенность withF/withoutF: {p}")


def test_out_id_children_are_only_allowed_branches(
    tasks_output: Path, tasks_input: Path
) -> None:
    """Прямые дети OUT_ID — только withoutF, withF и/или withFThenWithoutF."""
    allowed_names = ALLOWED_BRANCHES_BOTH
    for out_id in iter_out_ids(tasks_output):
        for child in out_id.iterdir():
            if not child.is_dir():
                continue
            assert child.name in allowed_names, (
                f"Неожиданная ветка {child.name!r} внутри {out_id}"
            )


@pytest.mark.parametrize(
    "slug,branches",
    [
        ("test", ALLOWED_BRANCHES_BOTH),
    ],
)
def test_both_flow_has_three_nonempty_branches(
    tasks_output: Path, slug: str, branches: frozenset[str]
) -> None:
    """
    Для исходника из input/both/ с данным slug ожидаются три ветки с файлами.
    Параметр — согласован с примером tasks/input/both/test → test-v1.
    """
    matches = out_dirs_for_slug(tasks_output, slug)
    assert matches, f"Нет каталога tasks/output/{slug}-v*/ для both/{slug}"

    for out_id in matches:
        missing = [b for b in branches if not (out_id / b).is_dir()]
        assert not missing, f"{out_id}: отсутствуют папки {missing}"

        nonempty = branch_dirs_nonempty(out_id, branches)
        empty = [k for k, ok in nonempty.items() if not ok]
        assert not empty, f"{out_id}: пустые или без файлов ветки: {empty}"


def test_each_both_input_file_has_matching_output_bundle(
    tasks_input: Path, tasks_output: Path
) -> None:
    """Для каждого файла в tasks/input/both/ есть OUT_ID с полным набором веток both."""
    both = tasks_input / "both"
    if not both.is_dir():
        pytest.skip("нет tasks/input/both/")
    files = [p for p in both.iterdir() if p.is_file() and not p.name.startswith(".")]
    if not files:
        pytest.skip("нет файлов в both/")

    for src in files:
        slug = slug_from_stem(stem_from_input_path(src))
        outs = out_dirs_for_slug(tasks_output, slug)
        assert outs, f"Для both/{src.name} (slug={slug!r}) нет ни одного tasks/output/{slug}-v*/"

        ok_any = False
        for out_id in outs:
            nonempty = branch_dirs_nonempty(out_id, ALLOWED_BRANCHES_BOTH)
            if all(nonempty.values()):
                ok_any = True
                break
        assert ok_any, (
            f"Для both/{src.name} ни один из {outs!r} не содержит все три непустые ветки "
            f"{sorted(ALLOWED_BRANCHES_BOTH)}"
        )


def test_withF_only_and_withoutF_only_layouts_when_present(
    tasks_input: Path, tasks_output: Path
) -> None:
    """Если для slug есть только withF или только withoutF во входе — в OUT_ID нет лишних веток."""
    for out_id in iter_out_ids(tasks_output):
        slug = out_id.name.rsplit("-v", 1)[0]
        expected = allowed_branches_for_out_id(out_id, tasks_input, slug)
        if expected is None:
            continue
        present = {p.name for p in out_id.iterdir() if p.is_dir()}
        assert present <= expected, (
            f"{out_id}: лишние ветки {present - expected} (ожидалось подмножество {expected})"
        )
        assert present >= expected, (
            f"{out_id}: не хватает веток {expected - present} (ожидалось {expected})"
        )
