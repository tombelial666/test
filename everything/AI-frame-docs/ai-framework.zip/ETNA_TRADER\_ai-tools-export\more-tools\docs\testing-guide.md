# Testing Guide

This document describes the testing strategy, structure, and conventions for the mobile app.

---

## Testing Philosophy

- **Where**: All tests live under `/tests` (not inside `src`)
- **Structure**: `/tests/unit` and `/tests/integration` mirror the exact directory structure of `src/` for any tested file
- **Coverage**: Focus on deterministic logic and critical flows
- **Isolation**: Mock only external dependencies, not internals of the unit under test

---

## File Naming

- **Unit tests**: `*.spec.ts` or `*.spec.tsx`
- **Integration tests**: `*.integration.spec.ts` or `*.integration.spec.tsx`

### Examples (Path Mirroring)

```
src/infrastructure/mappers/positionMapper.ts
tests/unit/infrastructure/mappers/positionMapper.spec.ts

src/features/portfolio/screens/PortfolioScreen.tsx
tests/integration/features/portfolio/screens/PortfolioScreen.integration.spec.tsx
```

---

## When to Write Unit Tests

Create a unit test when logic is **isolated & deterministic**:

- **Domain**: entities, value objects, invariants, pure validation
- **Infrastructure**: DTO ↔ model mappers, formatters, repositories with mocked HTTP
- **Shared**: utilities (date, currency, number), small presentational components
- **Store**: selectors and slices/reducers (no real IO)
- **Hooks**: that are pure or can be tested with mocked dependencies

---

## When to Write Integration Tests

Create an integration test when you need a **real flow across layers**:

- Feature facade hooks using React Query (queries/mutations + cache invalidation)
- Screens with real providers: `ApiProvider`, `QueryProvider`, `HttpProvider`, `AppInitializationProvider`
- Use-case scenarios: validation → port calls → side-effects (analytics, cache)
- Navigation and error flows (e.g., 401 redirect via `HttpProvider`)
- Cross-API cases (primary/secondary) and cache coherence

---

## Optional / Not Required

Don't test:
- Thin glue code without logic that is already covered by integration tests higher up
- Third-party library functionality
- Simple type definitions

---

## Test Structure

Use clear **Arrange → Act → Assert** structure:

```ts
describe("positionMapper", () => {
  it("maps DTO to domain Position", () => {
    // Arrange
    const dto: PositionDTO = {
      id: "pos_1",
      symbol: "AAPL",
      qty: 10,
      avgPrice: 12345,
      currency: "USD",
    };

    // Act
    const position = positionMapper.toDomain(dto);

    // Assert
    expect(position.id).toBe("pos_1");
    expect(position.symbol).toBe("AAPL");
    expect(position.quantity).toBe(10);
    expect(position.averagePrice.cents).toBe(12345);
    expect(position.averagePrice.currency).toBe("USD");
  });
});
```

---

## Factories & Mocks

To avoid copy-pasting fixtures, use reusable builders in `/tests/factories`.

### Directory Layout

```
/tests/factories
  /domain/
    /entities/
      Position.factory.ts
      Order.factory.ts
  /infrastructure/
    /dto/
      PositionDTO.factory.ts
      OrderDTO.factory.ts
  /scenarios/
    portfolioScenario.factory.ts   # bundles for typical integration flows
  factoryCore.ts                   # makeFactory, seq, deepMerge helpers
```

### Factory Core (Example)

```ts
// tests/factories/factoryCore.ts
export type DeepPartial<T> = { 
  [K in keyof T]?: T[K] extends object ? DeepPartial<T[K]> : T[K] 
};

export function makeFactory<T>(defaults: () => T) {
  const build = (overrides?: DeepPartial<T>): T => 
    Object.assign(defaults(), overrides ?? {});
  
  (build as any).list = (n = 1, map?: (i: number) => DeepPartial<T>) =>
    Array.from({ length: n }, (_, i) => build(map?.(i)));
  
  return build as typeof build & { 
    list: (n?: number, map?: (i: number) => DeepPartial<T>) => T[] 
  };
}
```

### Domain Factory (Example)

```ts
// tests/factories/domain/entities/Position.factory.ts
import { makeFactory } from "../../factoryCore";
import type { Position } from "@/domain/entities/Position";

export const positionFactory = makeFactory<Position>(() => ({
  id: "pos_1",
  symbol: "AAPL",
  quantity: 10,
  averagePrice: { cents: 12345, currency: "USD" },
}));

// Usage in tests:
const position = positionFactory.build({ symbol: "TSLA" });
const positions = positionFactory.list(3, (i) => ({ id: `pos_${i}` }));
```

### DTO Factory (Example)

```ts
// tests/factories/infrastructure/dto/PositionDTO.factory.ts
import { makeFactory } from "../../factoryCore";
import type { PositionDTO } from "@/infrastructure/dto/PositionDTO";

export const positionDTOFactory = makeFactory<PositionDTO>(() => ({
  id: "dto_1",
  symbol: "AAPL",
  qty: 10,
  avgPrice: 12345,
  currency: "USD",
}));
```

---

## Configuration Files

- **Root Jest config**: `/jest.config.js`
- **Global setup**: `/tests/setup.ts`

### Example Jest Config

```ts
// jest.config.js
export default {
  preset: "jest-expo",
  setupFilesAfterEnv: ["<rootDir>/tests/setup.ts"],
  testMatch: ["**/tests/**/*.spec.{ts,tsx}"],
  moduleNameMapper: {
    "^@/(.*)$": "<rootDir>/src/$1",
  },
  collectCoverageFrom: ["src/**/*.{ts,tsx}", "!src/**/*.d.ts"],
};
```

---

## Test Style Guidelines

1. **Descriptive titles**: Use clear, behavior-focused descriptions
   - ✅ `it("submits order and invalidates positions cache")`
   - ❌ `it("works")`

2. **Mock only external dependencies**: Don't mock internals of the unit under test
   - ✅ Mock HTTP clients, external services, ports
   - ❌ Mock internal helper functions of the module

3. **Use snapshots sparingly**: Only for stable presentational output

4. **Test behavior, not implementation**: Focus on what the code does, not how

5. **Keep tests focused**: One logical assertion per test when possible

---

## Example Unit Test

```ts
// tests/unit/infrastructure/mappers/positionMapper.spec.ts
import { positionMapper } from "@/infrastructure/mappers/positionMapper";
import { positionDTOFactory } from "tests/factories/infrastructure/dto/PositionDTO.factory";

describe("positionMapper", () => {
  describe("toDomain", () => {
    it("converts DTO to domain Position", () => {
      const dto = positionDTOFactory.build({
        id: "pos_123",
        symbol: "AAPL",
        qty: 100,
        avgPrice: 15000,
        currency: "USD",
      });

      const position = positionMapper.toDomain(dto);

      expect(position.id).toBe("pos_123");
      expect(position.symbol).toBe("AAPL");
      expect(position.quantity).toBe(100);
      expect(position.averagePrice.cents).toBe(15000);
      expect(position.averagePrice.currency).toBe("USD");
    });
  });

  describe("toDTO", () => {
    it("converts domain Position to DTO", () => {
      const position = {
        id: "pos_123",
        symbol: "AAPL",
        quantity: 100,
        averagePrice: { cents: 15000, currency: "USD" as const },
      };

      const dto = positionMapper.toDTO(position);

      expect(dto.id).toBe("pos_123");
      expect(dto.symbol).toBe("AAPL");
      expect(dto.qty).toBe(100);
      expect(dto.avgPrice).toBe(15000);
      expect(dto.currency).toBe("USD");
    });
  });
});
```

---

## Example Integration Test

```ts
// tests/integration/features/portfolio/hooks/usePortfolio.integration.spec.tsx
import { renderHook, waitFor } from "@testing-library/react-native";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { usePortfolio } from "@/features/portfolio/hooks/usePortfolio";
import { ApiProvider } from "@/composition/ApiProvider";
import type { IPortfolioService } from "@/domain/ports/IPortfolioService";
import { positionFactory } from "tests/factories/domain/entities/Position.factory";

const mockPortfolioService: IPortfolioService = {
  getPositions: jest.fn(),
  getPosition: jest.fn(),
};

jest.mock("@/composition/ApiProvider", () => ({
  useApi: () => ({ portfolioService: mockPortfolioService }),
  ApiProvider: ({ children }: any) => children,
}));

describe("usePortfolio", () => {
  it("fetches and transforms positions successfully", async () => {
    // Arrange
    const mockPositions = positionFactory.list(3);
    (mockPortfolioService.getPositions as jest.Mock).mockResolvedValue(mockPositions);

    const queryClient = new QueryClient({
      defaultOptions: { queries: { retry: false } },
    });

    const wrapper = ({ children }: any) => (
      <QueryClientProvider client={queryClient}>
        <ApiProvider>
          {children}
        </ApiProvider>
      </QueryClientProvider>
    );

    // Act
    const { result } = renderHook(() => usePortfolio(), { wrapper });

    // Assert
    await waitFor(() => expect(result.current.isSuccess).toBe(true));
    expect(result.current.data).toHaveLength(3);
    expect(result.current.data[0].symbol).toBe(mockPositions[0].symbol);
  });
});
```

---

## Running Tests

```bash
# Run all tests
npm test

# Run unit tests only
npm test -- tests/unit

# Run integration tests only
npm test -- tests/integration

# Run tests in watch mode
npm test -- --watch

# Run tests with coverage
npm test -- --coverage
```

---

## Best Practices Summary

1. ✅ Mirror `src/` structure in `tests/unit` and `tests/integration`
2. ✅ Use factories for test data creation
3. ✅ Test behavior, not implementation details
4. ✅ Write integration tests for critical user flows
5. ✅ Keep tests fast and focused
6. ✅ Use descriptive test names
7. ✅ Mock external dependencies, not internals
8. ❌ Don't test third-party libraries
9. ❌ Don't colocate tests with source code
10. ❌ Don't use snapshots for everything
