# Code Review - [Task Title]

**Date**: YYYY-MM-DD | **Reviewer**: AI Code Reviewer
**Task**: [path/to/task-directory] | **PR**: [PR URL] | **Status**: PENDING

---

<!-- SECTION:summary -->
## Reviewer Note

[Pending — orchestrator synthesizes after all agents complete.
Write as a senior code reviewer's overall impression: what was implemented, how well it was done, notable strengths or concerns, and the bottom-line verdict. 2-5 sentences — cohesive narrative, NOT a list of agent outputs.]

<!-- /SECTION:summary -->

---

## Pre-Review Validation

<!-- SECTION:quality-gate -->
### Quality Gate

**Agent**: `automated-quality-gate` | **Status**: PENDING

[Pending — LEAN default:
- reuse SI quality-gate result if still valid for current code state, or
- run fresh automated-quality-gate when reuse is not valid.

Commands: `npx tsc --noEmit`, `npm run lint`, `npm test -- --passWithNoTests --silent`]

<!-- /SECTION:quality-gate -->

---

<!-- SECTION:approach-review -->
### Approach Review

**Agent**: `senior-architecture-reviewer` | **Status**: PENDING

[Pending — agent writes: requirements table, TDD compliance, architecture compliance (layer boundaries, design tokens, localization), solution scores, issues]

<!-- /SECTION:approach-review -->

---

## Code Review Findings

<!-- SECTION:security -->
### Security

**Agent**: `security-code-reviewer`

[Pending — agent writes findings or "*No security issues found.*"]

<!-- /SECTION:security -->

---

<!-- SECTION:code-quality -->
### Code Quality

**Agent**: `code-quality-reviewer`

[Optional STRICT section — skip in LEAN mode unless explicitly requested.]

<!-- /SECTION:code-quality -->

---

<!-- SECTION:test-coverage -->
### Test Coverage

**Agent**: `test-coverage-reviewer`

[Optional STRICT section — skip in LEAN mode unless explicitly requested.]

<!-- /SECTION:test-coverage -->

---

<!-- SECTION:documentation -->
### Documentation

**Agent**: `documentation-accuracy-reviewer`

[Optional STRICT section — skip in LEAN mode unless explicitly requested.]

<!-- /SECTION:documentation -->

---

<!-- SECTION:performance -->
### Performance

**Agent**: `performance-reviewer`

[Conditional LEAN section — run only for performance-risk changes (lists, animations, heavy React Query usage). Otherwise write skipped reason.]

<!-- /SECTION:performance -->

---

<!-- SECTION:consolidated -->
## Consolidated Issues

[Pending — orchestrator writes after all agents complete]

<!-- /SECTION:consolidated -->

---

<!-- SECTION:decision -->
## Decision

[Pending — orchestrator writes after consolidation]

<!-- /SECTION:decision -->

---

<!-- SECTION:metadata -->
## Review Metadata

[Pending — orchestrator writes]

<!-- /SECTION:metadata -->
