---
name: nf
description: >-
  Conduct in-depth feature discovery interview to explore, challenge, and document a new feature.
  Use when asked to 'detail a feature', 'explore a new feature', 'feature discovery',
  'interview about feature', or 'spec out a feature'. NOT for quick brainstorming,
  NOT for implementation tasks (use /ct).
argument-hint: [feature-name]
allowed-tools: Read, Write, Edit, Grep, Glob, AskUserQuestion, Task, Skill
---

# New Feature Discovery

## Objective
Conduct a comprehensive interview to fully understand and document a new feature using collaborative brainstorming, then create a formal specification.

## Guidelines
- **Use `AskUserQuestion` tool for ALL clarifications** — provides interactive options for user to choose from
- **Never assume behavior**: if any behavior is unclear/ambiguous (UX flow, edge cases, error handling, states), you MUST ask the user to define expected behavior
- Ask non-obvious and thought-provoking questions
- Actively challenge assumptions; do not be a yes-boy
- Offer alternatives, shortcuts, and "go deeper" paths
- Continue until the feature is fully understood
- Document everything in the specification file

## Workflow

### Platform Skill Gate (MANDATORY when feature touches UI/screens)

**Trigger:** If the feature will create or modify screens, components, navigation, or styles.

**MANDATORY steps (do BEFORE writing recommendations in the discovery/spec):**
- Read `.claude/skills/react-native-expo/SKILL.md`
- Read `.claude/skills/design-tokens/SKILL.md`
- Explicitly state in the discovery/spec that the skills were read and will be applied
- Extract relevant rules and record them under a "Skill Compliance" section

### Step 1: Codebase Exploration

Launch 1-3 parallel Explore agents based on feature complexity. Use Task tool in **single message**.

**Agents:**
1. Feature code & patterns in `src/features/` + `app/`
2. Data models, domain entities, existing repos (if 2+ agents): `src/domain/`, `src/infrastructure/`
3. Docs, ADRs, existing tests (if 3 agents): `docs/`, `tests/`

Synthesize findings, then proceed to design exploration.

### Step 2: External Research (Optional)

Default: skip for token efficiency.

Run only when:
- User explicitly asks for deeper/strict discovery
- Internal codebase context is insufficient
- Decision depends on external constraints (ecosystem, standards, security)

### Step 3: Design Exploration Phase

With gathered context:
- Ask questions to refine the idea (batch related questions)
- Propose 2-3 different approaches with trade-offs
- Present design incrementally for validation
- Consider MobileLiteApp architecture constraints:
  - How does this fit the layer structure?
  - React Query or Zustand for state?
  - New repository or extend existing?
  - New feature folder or extend existing feature?

### Step 4: Challenge & Deep-Dive

After design exploration, run one structured challenge pass:
- Identify assumptions and question each one
- Suggest 2-3 alternative approaches (including a lean/shortcut path)
- Flag potential risks, hidden costs, or complexity traps

**Technical Implementation:**
- Edge cases and failure scenarios
- Performance implications (list rendering, re-renders, query caching)
- Integration points with existing features
- Security implications (token handling, data exposure)

**UI/UX (mobile-specific):**
- User mental models and expectations on mobile
- Error states and recovery flows
- Loading states and skeleton screens
- Offline / poor connectivity behavior
- Safe area handling, keyboard behavior

**Business & Product:**
- Success metrics and how to measure them
- MVP vs future scope boundaries
- White-label/multi-brand implications

### Step 5: Specification Writing

After design exploration and interview completion:

1. **Read template**: Read `docs/product-docs/templates/discovery-template.md`
2. **Create task directory**: `tasks/task-<date>-[feature-name]/`
3. **Write specification** following the template structure
   - Output file: `discovery-[feature-name].md`
4. **Present summary** to user for confirmation

**If design exploration reveals the feature is not viable**: Document the reasons in a brief `discovery-[feature-name]-rejected.md` with rationale, and stop here.

## Output
`tasks/task-<date>-[feature-name]/discovery-[feature-name].md`
