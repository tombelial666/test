# ADR-0004: MobileSettings as Value Object

**Status**: Accepted  
**Date**: 2025-12-10

## Context

MobileSettings was originally implemented as an interface with optional fields, requiring a separate mapper to transform DTOs into domain entities. This approach pushes validation and parsing logic to consumers and creates unnecessary abstractions. According to Domain-Driven Design principles, MobileSettings is a Value Object (no identity, immutable configuration) rather than an Entity.

## Use Cases

- UC1: Fetch mobile settings from API and ensure all fields have guaranteed values
- UC2: Parse string booleans ("0"/"1") and JSON strings to proper types
- UC3: Provide default values for missing optional API fields
- UC4: Ensure immutable configuration object throughout the application
- UC5: Eliminate need for null/undefined checks in consuming code

## Options Considered

### Option 1: Keep Interface with Mapper (Current)

**Pros**:
- Separation between DTO and domain layer
- Explicit transformation logic in dedicated mapper

**Cons**:
- Interface with optional fields requires consumers to handle undefined/null
- Separate mapper adds unnecessary abstraction layer
- Parsing logic scattered between mapper and consumers
- No guarantee of valid state after construction
- More files to maintain (interface + mapper + tests)

### Option 2: Value Object Class with Constructor Parsing

**Pros**:
- Single source of truth for field initialization and defaults
- All fields guaranteed to have values after construction
- Parsing and transformation encapsulated in constructor
- Follows DDD Value Object pattern (immutable, no identity)
- Consumers don't need null checks or undefined handling
- Eliminates redundant mapper abstraction
- Matches Angular implementation pattern

**Cons**:
- Constructor contains more logic (but this is appropriate for Value Objects)
- Slightly more verbose constructor (but improves maintainability)

### Option 3: Entity Class with ID

**Pros**:
- Follows DDD Entity pattern for objects with identity

**Cons**:
- MobileSettings has no identity/lifecycle
- Overkill for immutable configuration
- Would require artificial ID field

## Decision

We chose **Option 2: Value Object Class** because:
- MobileSettings is immutable configuration without identity
- Constructor-based initialization guarantees valid state
- Eliminates redundant mapper abstraction
- Follows DDD Value Object pattern
- Aligns with Angular implementation for consistency

## Consequences

**Becomes Easier**:
- Consuming code can rely on all fields having defined values
- Parsing logic centralized in one location
- Less boilerplate (no mapper files/tests needed)
- Better type safety (readonly fields, non-optional)

**Becomes Harder**:
- Constructor is longer (but encapsulates all complexity)
- Direct DTO-to-domain transformation (but simpler overall)

**Follow-up Actions**:
- Convert `MobileSettings` interface → Value Object class
- Move from `src/domain/entities/` → `src/domain/value-objects/`
- Delete `mobileSettingsMapper.ts` and tests
- Update `MobileSettingsDTO` to have all optional fields
- Update repository to use `new MobileSettings(data)`
- Update all imports across codebase

## References

- Angular implementation pattern: `new MobileSettings(data)` with constructor parsing
- DDD Value Object: Immutable objects defined by their attributes, no identity

