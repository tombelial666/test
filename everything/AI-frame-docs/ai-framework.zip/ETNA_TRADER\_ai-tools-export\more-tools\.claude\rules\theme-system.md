# Theme System Guidelines

## Core Rule

**Never hardcode colors. Always use `useThemeColors()` from `@/shared/theme/hooks`.**

```tsx
import { useThemeColors } from '@/shared/theme/hooks';

export function MyComponent() {
  const colors = useThemeColors();

  return (
    <View style={{ backgroundColor: colors.background.base }}>
      <Text style={{ color: colors.text.base }}>Hello</Text>
    </View>
  );
}
```

## Core Hooks

### `useThemeColors()` — Color Tokens

```tsx
import { useThemeColors } from '@/shared/theme/hooks';

const colors = useThemeColors();

// Core
colors.background.base          // Main background
colors.background.secondary     // Cards, surfaces
colors.text.base                // Primary text
colors.text.secondary           // Muted text
colors.text.disabled            // Disabled text
colors.border.base              // Borders/dividers
colors.icon.base                // Default icons
colors.icon.secondary           // Inactive icons

// Sentiment — always use ?. (optional chaining)
colors.background.brand?.base   // Primary button background
colors.text.onbrand?.base       // Text ON brand background
colors.icon.brand?.base         // Active tab icon
colors.background.danger?.base  // Delete/destructive button
colors.text.ondanger?.base      // Text ON danger background
colors.background.success?.base
colors.background.warning?.base

// Form fields
colors.field.border.base        // Default input border
colors.field.border.focus       // Focused input
colors.field.border.error       // Error state
colors.field.background.base    // Input background
colors.field.text.base          // Input text
colors.field.text.placeholder   // Placeholder

// Cards
colors.card.background.base
colors.card.border.base
```

### `useTheme()` — Theme Switching

```tsx
import { useTheme } from '@/shared/theme/hooks';

const { theme, isDark, toggleTheme, setTheme } = useTheme();

setTheme('light');
setTheme('dark');
setTheme(null);   // Restore system theme (Auto)
toggleTheme();    // Toggle light ↔ dark
```

## Styling Pattern

```tsx
import { StyleSheet } from 'react-native';
import { useThemeColors } from '@/shared/theme/hooks';

export function MyScreen() {
  const colors = useThemeColors();

  return (
    <View style={[styles.container, { backgroundColor: colors.background.base }]}>
      <Text style={[styles.title, { color: colors.text.base }]}>Title</Text>
      <TextInput
        style={[
          styles.input,
          {
            borderColor: colors.field.border.base,
            backgroundColor: colors.field.background.base,
            color: colors.field.text.base,
          }
        ]}
        placeholderTextColor={colors.field.text.placeholder}
      />
    </View>
  );
}

// Only non-color, layout styles in StyleSheet.create
const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  title: { fontSize: 24, fontWeight: 'bold' },
  input: { borderWidth: 1, borderRadius: 8, padding: 12 },
});
```

## Common UI Patterns

```tsx
// Primary button
<TouchableOpacity style={{ backgroundColor: colors.background.brand?.base }}>
  <Text style={{ color: colors.text.onbrand?.base }}>Submit</Text>
</TouchableOpacity>

// Danger button
<TouchableOpacity style={{ backgroundColor: colors.background.danger?.base }}>
  <Text style={{ color: colors.text.ondanger?.base }}>Delete</Text>
</TouchableOpacity>

// Tab bar
tabBarActiveTintColor: colors.icon.brand?.base,
tabBarInactiveTintColor: colors.icon.secondary,
tabBarStyle: {
  backgroundColor: colors.background.base,
  borderTopColor: colors.border.base,
}
```

## Theme Priority

1. Manual override (AsyncStorage `@theme_preference`)
2. System theme (`useColorScheme()`)
3. Light (default fallback)

## File Locations

| File | Purpose |
|------|---------|
| `src/shared/theme/hooks/useThemeColors.ts` | `useThemeColors()` |
| `src/shared/theme/hooks/useTheme.ts` | `useTheme()` |
| `src/shared/theme/ThemeProvider.tsx` | Theme provider (shared) |
| `src/composition/ThemeProvider.tsx` | Composition re-export (used by `app/_layout.tsx`) |
| `src/shared/theme/tokens/light.ts` | Light tokens (hex allowed here) |
| `src/shared/theme/tokens/dark.ts` | Dark tokens (hex allowed here) |
| `src/shared/brand/etna/colors.ts` | Brand token overrides (ETNA) |
| `src/shared/brand/sogo/colors.ts` | Brand token overrides (Sogo) |
| `src/shared/brand/index.ts` | Brand token selection/export |

## Prohibited Patterns

```tsx
// ❌ NEVER hardcode colors
<View style={{ backgroundColor: '#FFFFFF' }}>
<Text style={{ color: 'red' }}>
<View style={{ borderColor: 'rgba(0,0,0,0.1)' }}>

// ❌ NEVER define colors in StyleSheet.create (won't update on theme change)
const styles = StyleSheet.create({
  container: { backgroundColor: '#FFFFFF' }, // BAD
});

// ❌ NEVER use these non-existent imports
import { useThemeColor } from '@/components/Themed';     // File does not exist
import Colors from '@/constants/Colors';                 // File does not exist
```

## Testing with Theme

```tsx
import { ThemeProvider } from '@/shared/theme/ThemeProvider';

const wrapper = ({ children }: { children: React.ReactNode }) => (
  <ThemeProvider>{children}</ThemeProvider>
);

render(<MyComponent />, { wrapper });
```

## Adding a New Brand

See `docs/theme-system-guide.md` for full guide.

Quick steps:
1. Add brand assets/config: `npm run add-new-brand` (updates `brand-config.js`, assets, scripts, EAS profiles)
2. Add token overrides: create `src/shared/brand/<brand>/colors.ts` (optional overrides over base tokens)
3. Wire brand token selection/export in `src/shared/brand/index.ts` (currently build-time selection via import)
4. Run: `BRAND=<brand> APP_ENV=development npm start` (or use `npm run start:<brand>:dev`)
