# White-Label Configuration

This app supports multiple brands through environment variables and dynamic configuration.

## Brand Configuration

The app supports two brands:

- **ETNA**: Shows as "ETNA Lite" with ETNA-specific assets and configuration
- **Sogo**: Shows as "SogoTrade" with Sogo-specific assets and configuration

## Brand Assets

Brand-specific assets are located in `assets/brands/`:

```
assets/brands/
├── etna/
│   ├── icon.png
│   └── splash.png
└── sogo/
    ├── icon.png
    └── splash.png
```

## Adding a New Brand

### Quick Start (Automated)

Use the interactive script to add a new brand automatically:

```bash
npm run add-new-brand
```

The script will:
- Prompt for brand details (with default values)
- Create the brand assets directory
- Add the brand to `brand-config.js`
- Add scripts to `package.json`
- Add build profiles to `eas.json`

After running the script, you'll need to add the actual asset files (`icon.png` and `splash.png`) to the created directory.

### Manual Setup

To add a new brand manually:

1. **Add brand assets** to `assets/brands/<brand-name>/`:

   - `icon.png` - App icon (1024x1024px recommended)
   - `splash.png` - Splash screen image

2. **Register the brand in `brand-config.js` (root)**:

   Add a brand object and register it in the `brandRegistry` map.

   ```js
   // brand-config.js
   const newBrand = {
     appName: "Your Brand Name",
     slug: "yourbrand-mobile",
     scheme: "yourbrand-mobile",
     bundleIdentifier: "com.yourcompany.yourbrand",  // iOS bundle ID
     package: "com.yourcompany.yourbrand",            // Android package
   };

   const brandRegistry = {
     // existing brands
     etna: etnaBrand,
     sogo: sogoBrand,
     // add your brand key here
     "<brand-name>": newBrand,
   };
   ```

   The app reads this at build/runtime via `app.config.ts` and `BrandProvider`.

   **Important for Keycloak OAuth:**
   - The `scheme` field is used to construct the OAuth redirect URI (NOT `bundleIdentifier`/`package`)
   - Format: `{scheme}:/callback` (single slash — `/callback` is a path, not a host)
   - Example: `scheme: "my-app"` → `my-app:/callback`
   - You must register this redirect URI in your Keycloak client configuration
   - See [Keycloak Authentication Documentation](./keycloak-authentication.md#oauth-redirect-uri) for details

3. **Add npm scripts** in `package.json`:

   ```json
   {
     "scripts": {
       "start:<brand-name>:dev": "cross-env BRAND=<brand-name> APP_ENV=development expo start -c",
       "start:<brand-name>:prod": "cross-env BRAND=<brand-name> APP_ENV=production expo start -c"
     }
   }
   ```

4. **Add EAS build profiles** in `eas.json`:
   ```json
   {
     "build": {
       "<brand-name>-dev": {
         "extends": "development",
         "env": {
           "BRAND": "<brand-name>",
           "APP_ENV": "development"
         }
       },
       "<brand-name>-prod": {
         "extends": "production",
         "env": {
           "BRAND": "<brand-name>",
           "APP_ENV": "production"
         }
       }
     }
   }
   ```

Notes:

- No TypeScript brand module files are required. Brand configuration is centralized in the root `brand-config.js` for Expo compatibility.
- Types for brand shape live in `src/shared/types/brand.ts` and are used in-app; you typically do not need to update union types to add a brand because `app.config.ts` reads `BRAND` from env and looks it up dynamically.

## Building for Production

Build specific brand versions using EAS Build:

```bash
# Build ETNA brand
npx eas build --profile etna-prod --platform ios
npx eas build --profile etna-prod --platform android

# Build Sogo brand
npx eas build --profile sogo-prod --platform ios
npx eas build --profile sogo-prod --platform android
```

**Note**: For EAS builds, set the required environment variables as Expo Secrets in your Expo dashboard. See [Environment Variables](./environment-variables.md) for the complete list of required variables.

## Development Scripts

### Brand-Specific Development

- `npm run start:etna:dev` - Start development server with ETNA brand
- `npm run start:sogo:dev` - Start development server with Sogo brand
- `npm run start:etna:prod` - Start development server with ETNA brand (production mode)
- `npm run start:sogo:prod` - Start development server with Sogo brand (production mode)

### Platform-Specific with Brands

- `npm run ios:etna` - Run iOS with ETNA brand
- `npm run ios:sogo` - Run iOS with Sogo brand

## Environment Variables

The white-label system uses the following environment variables:

- `BRAND` - The current brand (etna, sogo)
- `APP_ENV` - The environment (development, production)
- `EXPO_PUBLIC_PRIMARY_API_URL` - Primary API URL
- `EXPO_PUBLIC_PRIMARY_API_KEY` - Primary API key
- `EXPO_PUBLIC_ORIGIN_URL` - Origin URL

## Architecture

The white-label system is built with:

- **Root brand registry (`brand-config.js`)**: Single JS file that lists all brands and their metadata; used by both the Expo config and the app at runtime.
- **Dynamic App Config (`app.config.ts`)**: Reads `BRAND`/`APP_ENV`, pulls the brand from `brand-config.js`, and wires brand-specific app name, scheme, bundle IDs, and dynamic asset paths from `assets/brands/<brand>/`.
- **Brand Provider (`src/composition/BrandProvider.tsx`)**: Reads the chosen brand from `Constants.expoConfig.extra.brand` and exposes it via React context.
- **TypeScript support (`src/shared/types/brand.ts`)**: Interface for brand shape used within the app UI.
- **EAS Build Integration**: Separate build profiles per brand/environment that set `BRAND` and `APP_ENV`.

### Runtime access in React

Use the hook exposed by `BrandProvider` to access the current brand:

```ts
import { useBrand } from "@/composition/BrandProvider";

const Component = () => {
  const brand = useBrand();
  return null;
};
```

## Troubleshooting

### Brand Not Switching

1. Clear Metro cache: `npm start -- -c`
2. Verify `BRAND` and `APP_ENV` environment variables are set in your script/EAS profile
3. Confirm the brand key exists in `brand-config.js` and assets are present at `assets/brands/<brand>/`

### Build Issues

1. Ensure EAS secrets are set for production builds
2. Verify brand assets exist in `assets/brands/<brand>/`
3. Check that EAS build profiles are configured correctly

### TypeScript Errors

1. Ensure brand types are updated in `src/brands/core/index.ts`
2. Verify brand module exports match the `BrandModule` interface
3. Check that environment variable types are defined in `expo-env.d.ts`

---

## Related Documentation

- **[Environment Variables](./environment-variables.md)** - Complete guide for `BRAND`, `APP_ENV`, and all API configuration
- **[Project Structure](./project-structure.md)** - Brand provider and configuration file locations
