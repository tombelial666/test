# SQL Server Migration Patterns — ETNA_TRADER

## SSDT Project Structure (`db/` folder)

```
db/
├── Etna.Trader.Database/                  ← Main SSDT project (.sqlproj)
│   ├── Etna.Trader.Database.sqlproj
│   ├── dbo/
│   │   ├── Tables/
│   │   │   ├── Orders.sql
│   │   │   ├── Accounts.sql
│   │   │   ├── Positions.sql
│   │   │   ├── TradeHistory.sql
│   │   │   └── MarketData.sql
│   │   ├── Views/
│   │   │   └── vw_OpenPositions.sql
│   │   ├── StoredProcedures/
│   │   │   └── usp_GetAccountSummary.sql
│   │   ├── Functions/
│   │   │   └── fn_CalculateUnrealizedPnl.sql
│   │   └── Indexes/
│   │       └── IX_Orders_AccountId_CreatedAt.sql
│   ├── Scripts/
│   │   ├── PreDeployment/
│   │   │   └── Script.PreDeployment.sql
│   │   └── PostDeployment/
│   │       ├── Script.PostDeployment.sql
│   │       ├── SeedData/
│   │       │   ├── AccountTypes.sql
│   │       │   └── OrderStatuses.sql
│   │       └── DataMigrations/
│   │           └── 2026-03-01_migrate_order_side_to_enum.sql
│   └── Properties/
│       └── Database.sqlsettings
├── Etna.Trader.Database.Test/             ← tSQLt unit tests for DB logic
└── README.md
```

## Migration Naming Conventions

### Table / Object Definition Files

Object definition files are named after the object they define (SSDT deploys them idempotently via schema compare):

```
Tables/Orders.sql
Tables/TradeHistory.sql
Views/vw_OpenPositions.sql
StoredProcedures/usp_GetAccountSummary.sql
Indexes/IX_Orders_AccountId_CreatedAt.sql
```

### Data Migration Scripts (PostDeployment)

Data migration scripts in `Scripts/PostDeployment/DataMigrations/` use date-prefixed names:

```
Format: YYYY-MM-DD_<short-description>.sql

Examples:
2026-01-15_backfill_order_client_id.sql
2026-02-20_migrate_account_type_codes.sql
2026-03-01_populate_position_cost_basis.sql
```

### Pre/Post Deployment Script Entry Points

```sql
-- Scripts/PreDeployment/Script.PreDeployment.sql
-- Runs BEFORE schema changes are applied
-- Disable CDC, drop constraints that would block column changes, etc.
:r .\DisableCDC.sql
:r .\DropLegacyConstraints.sql

-- Scripts/PostDeployment/Script.PostDeployment.sql
-- Runs AFTER schema changes are applied
:r .\SeedData\AccountTypes.sql
:r .\SeedData\OrderStatuses.sql
:r .\DataMigrations\2026-01-15_backfill_order_client_id.sql
```

## Pre/Post Deployment Script Patterns

### PreDeployment — Schema Guards

```sql
-- Scripts/PreDeployment/Script.PreDeployment.sql
-- Guard: ensure idempotent — data migrations already run should be skipped
-- Never DROP columns here; only disable/drop things that block the schema deploy

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = '_MigrationHistory')
BEGIN
    CREATE TABLE [dbo].[_MigrationHistory]
    (
        [MigrationId]    NVARCHAR(150) NOT NULL PRIMARY KEY,
        [AppliedAt]      DATETIME2     NOT NULL DEFAULT GETUTCDATE(),
        [AppliedBy]      NVARCHAR(100) NOT NULL DEFAULT SYSTEM_USER
    );
END
```

### PostDeployment — Idempotent Data Migration

```sql
-- Scripts/PostDeployment/DataMigrations/2026-03-01_populate_position_cost_basis.sql
DECLARE @MigrationId NVARCHAR(150) = '2026-03-01_populate_position_cost_basis';

IF NOT EXISTS (SELECT 1 FROM [dbo].[_MigrationHistory] WHERE [MigrationId] = @MigrationId)
BEGIN
    BEGIN TRANSACTION;
    BEGIN TRY
        -- Backfill CostBasis from historical fills
        UPDATE p
        SET    p.CostBasis = t.AvgFillPrice * p.Quantity
        FROM   [dbo].[Positions] p
        INNER JOIN (
            SELECT   AccountId, Symbol, AVG(FillPrice) AS AvgFillPrice
            FROM     [dbo].[TradeHistory]
            WHERE    Side = 'Buy'
            GROUP BY AccountId, Symbol
        ) t ON p.AccountId = t.AccountId AND p.Symbol = t.Symbol
        WHERE p.CostBasis IS NULL;

        INSERT INTO [dbo].[_MigrationHistory] ([MigrationId]) VALUES (@MigrationId);
        COMMIT;
    END TRY
    BEGIN CATCH
        ROLLBACK;
        THROW;
    END CATCH
END
```

## Backward Compatibility Rules

### NEVER drop a column immediately after it is no longer used in code

Follow the 3-phase approach:

**Phase 1** — Stop writing to the column (deploy code that ignores it):
```sql
-- No schema change in this release; column stays, code stops referencing it
```

**Phase 2** — Deprecate in schema (next release):
```sql
-- Mark column as deprecated via extended property
EXEC sp_addextendedproperty
    @name = N'Deprecated',
    @value = N'Replaced by ClientOrderId in v2.3 — remove after 2026-Q2',
    @level0type = N'Schema', @level0name = N'dbo',
    @level1type = N'Table',  @level1name = N'Orders',
    @level2type = N'Column', @level2name = N'LegacyClientRef';
```

**Phase 3** — Drop (after at least one full release cycle, confirmed no reads in logs):
```sql
ALTER TABLE [dbo].[Orders] DROP COLUMN [LegacyClientRef];
```

### Safe Column Changes

```sql
-- ✅ ADD nullable column — always safe
ALTER TABLE [dbo].[Orders]
ADD [ClientOrderId] NVARCHAR(50) NULL;

-- ✅ ADD NOT NULL column with default — safe if default covers existing rows
ALTER TABLE [dbo].[Orders]
ADD [Source] NVARCHAR(20) NOT NULL CONSTRAINT DF_Orders_Source DEFAULT 'Unknown';

-- ✅ Widen a VARCHAR — safe
ALTER TABLE [dbo].[Orders]
ALTER COLUMN [Symbol] NVARCHAR(30) NOT NULL;  -- was NVARCHAR(20)

-- ❌ Narrow a column — NEVER without data audit
-- ❌ Change a column type in-place — use rename+add pattern instead
-- ❌ Drop a column without the 3-phase process
```

### Rename Convention (Never direct rename)

```sql
-- Phase 1: Add new column
ALTER TABLE [dbo].[Orders] ADD [InstrumentSymbol] NVARCHAR(20) NOT NULL DEFAULT '';

-- Phase 2: Backfill + keep in sync via code/trigger
UPDATE [dbo].[Orders] SET InstrumentSymbol = Symbol WHERE InstrumentSymbol = '';

-- Phase 3: Drop old column (later release)
ALTER TABLE [dbo].[Orders] DROP COLUMN [Symbol];
```

## Index Conventions for Trading Tables

### Time-Series Data Patterns

Trading tables (Orders, TradeHistory, MarketData) are append-heavy and queried primarily by account + time range.

```sql
-- Orders table clustered index: narrow key on business ID
CREATE TABLE [dbo].[Orders]
(
    [OrderId]       BIGINT          IDENTITY(1,1) NOT NULL,
    [ExternalId]    NVARCHAR(50)    NOT NULL,
    [AccountId]     NVARCHAR(50)    NOT NULL,
    [Symbol]        NVARCHAR(20)    NOT NULL,
    [CreatedAt]     DATETIME2(3)    NOT NULL,
    -- ... other columns
    CONSTRAINT PK_Orders PRIMARY KEY CLUSTERED ([OrderId] ASC)
);

-- Most common query: account + status + time range
CREATE NONCLUSTERED INDEX [IX_Orders_AccountId_Status_CreatedAt]
ON [dbo].[Orders] ([AccountId] ASC, [Status] ASC, [CreatedAt] DESC)
INCLUDE ([Symbol], [Side], [Type], [Quantity], [LimitPrice], [FilledQuantity]);

-- Symbol-level queries (market scanner, position building)
CREATE NONCLUSTERED INDEX [IX_Orders_Symbol_CreatedAt]
ON [dbo].[Orders] ([Symbol] ASC, [CreatedAt] DESC)
INCLUDE ([AccountId], [Status], [Quantity], [FillPrice]);
```

### Trade History (high-volume append-only)

```sql
-- Partition by year for TradeHistory (tens of millions of rows)
CREATE PARTITION FUNCTION pf_TradeDate (DATETIME2)
    AS RANGE RIGHT FOR VALUES ('2024-01-01', '2025-01-01', '2026-01-01');

CREATE PARTITION SCHEME ps_TradeDate
    AS PARTITION pf_TradeDate ALL TO ([PRIMARY]);

CREATE TABLE [dbo].[TradeHistory]
(
    [TradeId]       BIGINT       IDENTITY(1,1) NOT NULL,
    [TradeDate]     DATETIME2(3) NOT NULL,
    [AccountId]     NVARCHAR(50) NOT NULL,
    [Symbol]        NVARCHAR(20) NOT NULL,
    [Quantity]      INT          NOT NULL,
    [FillPrice]     DECIMAL(18,6) NOT NULL,
    -- ...
    CONSTRAINT PK_TradeHistory PRIMARY KEY CLUSTERED ([TradeId], [TradeDate])
        ON ps_TradeDate([TradeDate])
);
```

### Index Naming Convention

```
IX_<TableName>_<Column1>[_<Column2>...]         ← non-clustered
UQ_<TableName>_<Column1>[_<Column2>...]         ← unique constraint/index
PK_<TableName>                                  ← primary key
FK_<TableName>_<ReferencedTable>               ← foreign key
DF_<TableName>_<ColumnName>                    ← default constraint
CK_<TableName>_<ColumnName>                    ← check constraint
```

## General Rules

1. All tables include `CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE()` and `UpdatedAt DATETIME2 NULL`
2. Use `DATETIME2(3)` for timestamps (millisecond precision), never `DATETIME`
3. Use `DECIMAL(18,6)` for prices, `DECIMAL(18,4)` for quantities
4. All foreign keys must have a matching index on the FK column
5. String IDs use `NVARCHAR(50)`, internal surrogate keys use `BIGINT IDENTITY`
6. Every schema change must be peer-reviewed; DDL changes require DBA sign-off in PR
7. Test SSDT deploy against a restored production backup before releasing to production
