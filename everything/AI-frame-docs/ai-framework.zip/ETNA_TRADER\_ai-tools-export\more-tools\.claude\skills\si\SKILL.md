---
name: si
description: Execute structured TDD implementation following task documents or bug fixing. Use when starting, continuing, or resuming implementation of a task or fixing a bug from tasks/ directory. Also handles addressing code review feedback.
argument-hint: [task-directory]
allowed-tools: ["Task", "AskUserQuestion", "Edit", "Read", "Bash", "Glob", "Grep", "Skill"]
---

# Start Implementation Command

## PRIMARY OBJECTIVE
Implement features systematically with TDD approach on feature branches.

Three modes of operation:
1. **Start** — Begin implementation from scratch
2. **Continue** — Resume in-progress implementation
3. **Address CR** — Apply code review feedback

Before any work, determine which mode applies by reviewing the task document status and git history.

## CONSTRAINTS
- Follow existing task document in `tasks/` directory
- Git writes require explicit user permission:
  - Do **NOT** create commits, push branches, open PRs, or merge unless the user explicitly approves it
- **STRICT DESCRIPTION ADHERENCE**: Only implement what is explicitly described in the task document
- Follow MobileLiteApp architecture layer rules
- No hardcoded colors — always use `useThemeColors()` from `@/shared/theme/hooks`
- No hardcoded UI strings — always use `t("key")` from react-i18next
- Named exports only — no default exports from components

## WORKFLOW STEPS

### **STEP 1: Task Validation**

1. **Ask user**: "Which task to implement? Provide task name or path." If not provided:
   - List tasks in `tasks/` if unclear

2. **Validate document**:
   - Confirm the task exists
   - Confirm scope is unambiguous: clear acceptance criteria, clear "done" definition
   - Confirm task status is appropriate ("Ready for Implementation" or "Draft")
   - Confirm there is an implementation plan: impacted files + test plan

3. **Pre-implementation check**:
   - Review relevant docs: `docs/project-structure.md`, `docs/testing-guide.md`
   - Explore affected codebase areas
   - Verify test runner works: `npm test -- --passWithNoTests 2>&1 | tail -5`

### **STEP 2: Setup**
Note: Skip this step when continuing implementation or addressing Code Review results

1. **Update task status** to "In Progress" with timestamp
2. **Create feature branch** (follow repo convention): `feat/<ticket-id>-[slug]` or `fix/<ticket-id>-[slug]`
3. **Update task document** with branch name
4. **Permission gate**: Ask for explicit approval before any git operation

### **STEP 3: Implementation**

#### **Parallelization (optional)**

If you believe part of the work can be done safely in parallel, use the `parallelization` skill:
- `.claude/skills/parallelization/SKILL.md`

---

#### **Sequential Mode**

#### **Before Each Step:**
1. **Announce**: "Starting Step [N]: [Description]"
2. **Review requirements**: Acceptance criteria, tests, artifacts

#### **During Implementation (TDD + Docs):**
1. **Follow agreed Test Plan**: Implement tests based on the Test Plan in the task document
2. **TDD Red-Green-Refactor Cycle**:
   - **RED**: Write failing tests first
     ```bash
     npm test -- --testPathPattern="<test-file>" --no-coverage 2>&1 | tail -20
     # Expected: FAIL
     ```
   - **GREEN**: Write minimal code to make tests pass
     ```bash
     npm test -- --testPathPattern="<test-file>" --no-coverage 2>&1 | tail -20
     # Expected: PASS
     ```
   - **REFACTOR**: Clean up code while keeping tests green
3. **Update relevant documentation DURING code writing** (not after):
   - **New feature/screen** → update `docs/project-structure.md` if new pattern established
   - **Architecture change** → create or update ADR in `docs/adr/`
   - **New design token** → update `docs/design-tokens.md`
   - **New test pattern** → update `docs/testing-guide.md`
   - **Provider/layer change** → update `CLAUDE.md` then run `node scripts/sync-docs.js --fix`
4. **Test file locations**:
   - Unit: `tests/unit/<mirrors-src-path>/<File>.spec.ts` or `.spec.tsx`
   - Integration: `tests/integration/<mirrors-src-path>/<File>.integration.spec.ts` or `.integration.spec.tsx`
5. **Test runner commands**:
   ```bash
   npm test -- --passWithNoTests --silent 2>&1 | tail -20
   npm test -- --testPathPattern="<pattern>" --no-coverage 2>&1 | tail -30
   ```
6. **Type check and lint**:
   ```bash
   npx tsc --noEmit 2>&1 | head -20
   npm run lint 2>&1 | head -20
   ```

#### **After Each Step:**
1. **Update the task document** (REQUIRED — not just chat output):
   - Mark step checkbox as complete: `- [ ]` → `- [x]`
   - Add **Changelog** entry describing what was done
   - Update **Tests** field with command run + result

   Example:
   ```markdown
   - [x] Sub-step 3.1: Add LoginScreen component
     - **Tests**: `npm test -- --testPathPattern="LoginScreen"` — 5 PASS
     - **Changelog**: Created `src/features/auth/screens/LoginScreen.tsx`, added `tests/integration/features/auth/screens/LoginScreen.integration.spec.tsx`
   ```

2. **Commit changes (permission gate)**:
   - If the user has **not explicitly approved** git writes: ask for permission before any `git` command
   - If approved: use conventional commits
     - Code + tests: `git commit -m "feat(auth): add login screen"`
     - Docs update: `git commit -m "docs(auth): update testing guide with auth pattern"`

#### **Error Recovery**
- **Tests fail**: Fix the failing code, re-run tests. Do NOT skip or delete failing tests.
- **Type errors**: Fix the type errors. Do NOT use `any` as a shortcut.
- **Lint errors**: Fix the lint errors. Do NOT use `// eslint-disable`.
- **Task document incomplete**: Ask user to clarify missing criteria before proceeding.

### **STEP 4: Completion**

#### **Final Verification**
Run quality gates via agent:
- Use Task tool with subagent_type: "automated-quality-gate"
- Provide `task_path` (absolute path to task directory)
- Agent runs typecheck/lint/tests and writes a Quality Gate Report in the task directory

#### **Finalize Task Document**
1. **Update status** to "Ready for Review" with timestamp
2. **Verify all checkboxes are accurate**
3. **Add implementation summary**:
   ```markdown
   ## Completion Summary

   **Implementation Complete**: [Brief technical description]
   **Files Changed**: [count] files modified, [count] files created
   **Tests**: [count] total (unit: [n], integration: [n])
   **Quality Gate**: PASSED — typecheck clean, lint clean, all tests pass
   **Technical Debt/Follow-ups**: [Any deferred work]
   ```

### **STEP 5: Prepare for Code Review**
1. **Permission gate (required)**:
   - Creating a PR and pushing requires **explicit user approval** for git writes

2. **Quick task-doc self-check**:
   - All implementation checkboxes are accurate
   - Test evidence and quality-gate result are documented
   - Branch name is consistent
   - Completion summary is present and readable for reviewers

3. **Prepare PR context in task document**:
   - Ensure branch name and test evidence are up to date
   - Add a short reviewer-oriented implementation summary
   - Create/open PR manually or via `gh pr create`
