---
name: design-tokens
description: "Design token color system for the Mobile Lite App (React Native + Expo). This skill should be used when adding colors or styles to any component, implementing dark/light mode support, reviewing code for hardcoded colors, naming or creating new design tokens, adding a new brand, or understanding theme resolution priority. CRITICAL: No hardcoded colors — use useThemeColors() from @/shared/theme/hooks exclusively."
---

# Design Tokens

## Overview

Provides guidance for using the design token color system in the Mobile Lite App.
All colors must come from `useThemeColors()` — never hardcode hex, rgb, or rgba values in component files.

Detailed references:
- Full token catalog → `references/token-catalog.md`
- Token naming grammar → `references/token-naming-grammar.md`

---

## Quick Start

```tsx
import { useThemeColors } from '@/shared/theme/hooks';

function MyComponent() {
  const colors = useThemeColors();

  return (
    <View style={{ backgroundColor: colors.background.base }}>
      <Text style={{ color: colors.text.base }}>Hello</Text>
    </View>
  );
}
```

**Styling pattern** — keep non-color layout styles in `StyleSheet.create`, inline only color styles:

```tsx
import { StyleSheet } from 'react-native';
import { useThemeColors } from '@/shared/theme/hooks';

export function MyScreen() {
  const colors = useThemeColors();

  return (
    <View style={[styles.container, { backgroundColor: colors.background.base }]}>
      <Text style={[styles.title, { color: colors.text.base }]}>Title</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  title: { fontSize: 18, fontWeight: '600' },
});
```

---

## Choosing the Right Token

Ask these questions in order:

1. **What element?** → `text` | `background` | `icon` | `border`
2. **What semantic meaning?** → neutral (omit sentiment) | `brand` | `success` | `danger` | `warning` | `info`
3. **What prominence?** → `base` (default) | `secondary` | `tertiary` | `strong`
4. **What state?** → default (omit) | `-hover` | `-active` | `-disabled` | `-selected`
5. **Is it inside a specific component?** → Add compound context: `card.` | `table.` | `leftnav.` | `field.` | etc.

**Quick lookup examples:**

| UI element | Token |
|------------|-------|
| Primary button background | `colors.background.brand?.base` |
| Primary button text | `colors.text.onbrand?.base` |
| Danger/delete button | `colors.background.danger?.base` |
| Text on danger button | `colors.text.ondanger?.base` |
| Input border (default) | `colors.field.border.base` |
| Input border (focused) | `colors.field.border.focus` |
| Input border (error) | `colors.field.border.error` |
| Placeholder text | `colors.field.text.placeholder` |
| Card background | `colors.card.background.base` |
| Disabled text | `colors.text.disabled` |
| Link | `colors.link.text.base` |
| Link hover | `colors.link.text.hover` |
| Active nav icon | `colors.leftnav.icon.active` |

> **Sentiment tokens are optional** — always use `?.` optional chaining: `colors.background.brand?.base`

For the complete list of available tokens, read `references/token-catalog.md`.

---

## Common UI Patterns

### Primary Action Button

```tsx
const colors = useThemeColors();

<TouchableOpacity
  style={[styles.button, { backgroundColor: colors.background.brand?.base }]}
  onPress={onPress}
>
  <Text style={{ color: colors.text.onbrand?.base }}>Sign In</Text>
</TouchableOpacity>
```

### Danger / Destructive Button

```tsx
<TouchableOpacity style={{ backgroundColor: colors.background.danger?.base }}>
  <Text style={{ color: colors.text.ondanger?.base }}>Delete</Text>
</TouchableOpacity>
```

### Text Input with States

```tsx
const [focused, setFocused] = useState(false);
const [hasError, setHasError] = useState(false);

<TextInput
  style={{
    backgroundColor: colors.field.background.base,
    borderWidth: 1,
    borderColor: hasError
      ? colors.field.border.error
      : focused
      ? colors.field.border.focus
      : colors.field.border.base,
    color: colors.field.text.base,
  }}
  placeholderTextColor={colors.field.text.placeholder}
  onFocus={() => setFocused(true)}
  onBlur={() => setFocused(false)}
/>
```

### Card Component

```tsx
<View
  style={{
    backgroundColor: colors.card.background.base,
    borderWidth: 1,
    borderColor: colors.card.border.base,
    borderRadius: 8,
    padding: 16,
  }}
>
  <Text style={{ color: colors.text.base }}>Card Content</Text>
</View>
```

### Checkbox / Toggle Control

```tsx
const [checked, setChecked] = useState(false);

<TouchableOpacity
  style={{
    backgroundColor: checked
      ? colors.control.background.checked
      : colors.control.background.base,
    borderWidth: 1,
    borderColor: checked
      ? colors.control.border.checked
      : colors.control.border.base,
    width: 24,
    height: 24,
  }}
  onPress={() => setChecked(!checked)}
>
  {checked && <Icon name="check" color={colors.control.icon.checked} />}
</TouchableOpacity>
```

### Tab Bar / Navigation

```tsx
tabBarActiveTintColor: colors.icon.brand?.base,
tabBarInactiveTintColor: colors.icon.secondary,
tabBarStyle: {
  backgroundColor: colors.background.base,
  borderTopColor: colors.border.base,
}
```

---

## Theme Switching

```tsx
import { useTheme } from '@/shared/theme/hooks';

const { theme, isDark, toggleTheme, setTheme, resetToSystem } = useTheme();

setTheme('light');   // Force light
setTheme('dark');    // Force dark
resetToSystem();     // Restore system theme
toggleTheme();       // Toggle light ↔ dark
```

Theme priority: manual override (AsyncStorage) → system theme → light (fallback).

---

## Adding New Tokens

To add a token:

1. Edit `src/shared/theme/tokens/types.ts` — add the TypeScript type
2. Edit `src/shared/theme/tokens/light.ts` — add light theme hex value
3. Edit `src/shared/theme/tokens/dark.ts` — add dark theme hex value
4. Use in component: `colors.<new.token.path>`

Before creating a new token, verify it doesn't already exist (TypeScript autocomplete helps here).
Token naming must follow the grammar in `references/token-naming-grammar.md`.

---

## Prohibited Patterns

```tsx
// ❌ NEVER — hardcoded hex/rgb in component files
<View style={{ backgroundColor: '#FFFFFF' }}>
<Text style={{ color: 'rgb(0,0,0)' }}>
<View style={{ borderColor: 'rgba(0,0,0,0.1)' }}>

// ❌ NEVER — these imports don't exist in this project
import { useThemeColor } from '@/components/Themed';
import Colors from '@/constants/Colors';

// ❌ NEVER — colors in StyleSheet.create (won't update on theme change)
const styles = StyleSheet.create({
  container: { backgroundColor: '#FFFFFF' },
});
```

Hex values are only allowed in:
- `src/shared/theme/tokens/light.ts`
- `src/shared/theme/tokens/dark.ts`
- `src/shared/brand/*/colors.ts`
- Test files (`tests/**/*.spec.{ts,tsx}`)

---

## Troubleshooting

**Token returns `undefined`** — sentiment tokens are optional, use `?.`:
```tsx
colors.text.brand?.base ?? colors.text.base  // with fallback
```

**Pre-commit blocked** — replace hardcoded colors with tokens, then re-commit.

**TypeScript error** — import from `@/shared/theme/hooks`, check `types.ts`, restart TS server.

---

## ADR Reference

- [ADR-0008: Design Tokens System](../../../docs/adr/0008-design-tokens-system.md) — decision context, options considered, and rationale for the token architecture.
