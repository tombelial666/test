---
name: sr
description: >-
  Conduct comprehensive code review before PR merge. Use when asked to
  'review code', 'start code review', 'review PR', 'check before merge',
  or 'pre-merge review'. NOT for addressing review comments (use /si to fix them).
argument-hint: [task-path or PR-url]
allowed-tools: Task, Skill, Read, Glob, Grep, Write, Edit, Bash, AskUserQuestion
---

# Start Review Command

## PRIMARY OBJECTIVE

Token-efficient professional code review using specialized agents. Agents write findings directly to designated sections in a shared Code Review document and return only short summaries to the orchestrator.

## REVIEW PROFILES

- **Default: LEAN review**
  - Keep a strong gate with minimal token usage.
  - Required: `senior-architecture-reviewer` + `security-code-reviewer`.
  - Conditional: `performance-reviewer` only for performance-risk changes (screens with lists, animations, heavy React Query usage).
- **Optional: STRICT review** (only when user explicitly asks)
  - Adds: `code-quality-reviewer`, `test-coverage-reviewer`, `documentation-accuracy-reviewer`.

## SHARED MEMORY PROTOCOL

- **CR File**: `Code Review - [Task].md` in the task directory
- **Template**: `docs/product-docs/templates/code-review-template.md`
- **Section markers**: `<!-- SECTION:name -->` ... `<!-- /SECTION:name -->`
- **Known sections (LEAN)**: summary, quality-gate, approach-review, security, performance, consolidated, decision, metadata
- **Optional STRICT sections**: code-quality, test-coverage, documentation
- **All agents**: Write directly to the CR file between their designated section markers using the Edit tool
- **All agents return**: A short text summary (~1 sentence with severity counts)

## WORKFLOW

### GATE 1: Task Identification

1. **AskUserQuestion**: "Which task to review? Provide task path or PR URL."
   - Or if argument was provided, use it directly.

2. **Validate**:
   - Task document exists with "Ready for Review" or "Implementation Complete" status
   - **STOP if**: "In Progress" or missing implementation evidence
   - Steps marked complete, test evidence present

### STEP 2: Scaffold Code Review File

1. **Read** template from `docs/product-docs/templates/code-review-template.md`
2. **Replace** header placeholders:
   - `[Task Title]` → task name from task document
   - `YYYY-MM-DD` → today's date (2026-02-27)
   - `[path/to/task-directory]` → actual task path
   - `[PR URL]` → PR URL from task document (or "N/A")
3. **Write** to `[task-directory]/Code Review - [Task].md`
4. Store the **absolute file path** as `CR_FILE_PATH` for all agent prompts

### GATE 3: Quality Gate Reuse / Validation

**DEFAULT (LEAN):**

1. Check whether SI already produced a passing quality-gate result for the same code state:
   - A recent quality gate report exists in the task directory
   - No new code changes after that report
2. If both are true:
   - Reuse the SI quality-gate outcome
   - Fill `<!-- SECTION:quality-gate -->` with a short "Reused from SI" summary
3. If not true:
   - Invoke `automated-quality-gate` and write fresh results to `<!-- SECTION:quality-gate -->`

**Quality gate commands for MobileLiteApp:**
```bash
npx tsc --noEmit
npm run lint
npm test -- --passWithNoTests --silent 2>&1 | tail -20
```

- If final status is `GATE_FAILED`:
  - Edit CR file header Status → `GATE_FAILED`
  - **STOP** — notify developer with fixes list

### GATE 4: Approach Review

**ACTION**: Invoke `senior-architecture-reviewer` agent

```
Task directory: [path]
cr_file_path: [CR_FILE_PATH]
Review approach, requirements fulfillment, MobileLiteApp architecture fit, TDD compliance.
Write results to your section in the CR file between <!-- SECTION:approach-review --> markers.
Return short summary only.
```

- **Read agent summary** → If status is `NEEDS_REWORK`:
  - Edit CR file header Status → `NEEDS_REWORK`
  - **STOP** — notify developer with issues

### GATE 5: Parallel Code Review

**DEFAULT (LEAN):** run the following in parallel (single message, multiple Task calls):

1. **`security-code-reviewer`** (required):
   ```
   Review security: OWASP, token handling, SecureStore usage, auth interceptors. Task: [path]
   cr_file_path: [CR_FILE_PATH]
   Write findings to your section in the CR file between <!-- SECTION:security --> markers.
   Return short summary only.
   ```

2. **`performance-reviewer`** (conditional):
   Run only when changes include performance-risk signals:
   - Screen/component with lists (FlatList/FlashList/ScrollView)
   - Animations (Reanimated)
   - Heavy React Query usage (multiple queries, complex invalidation)
   - New navigation flows

   If triggered:
   ```
   Review performance: React Native rendering, React Query caching, list optimization. Task: [path]
   cr_file_path: [CR_FILE_PATH]
   Write findings to your section in the CR file between <!-- SECTION:performance --> markers.
   Return short summary only.
   ```
   If not triggered:
   - Write in performance section: "Skipped in LEAN mode (no performance-risk changes detected)."

**STRICT mode (explicit user request):**
- Add in parallel: `code-quality-reviewer`, `test-coverage-reviewer`, `documentation-accuracy-reviewer`.

### GATE 6: Consolidation & Decision

All invoked parallel agents have written findings directly to the CR file. Read the CR file to verify required sections are populated.

#### 6.1 Write Consolidated Issues

Edit `<!-- SECTION:consolidated -->` markers:

```markdown
## Consolidated Issues

### Critical (Must Fix Before Merge)

- [ ] **[Source Agent]** Issue: Description → Solution → Files

### Major (Should Fix)

- [ ] **[Source Agent]** Issue: Description → Solution

### Minor (Nice to Fix)

- [ ] **[Source Agent]** Issue: Description → Suggestion

### Informational (Observations)

- **[Source Agent]** Observation: Description
```

De-duplicate issues flagged by multiple agents (note all sources).

#### 6.2 Write Decision

Edit `<!-- SECTION:decision -->` markers. Apply decision matrix:

| Critical | Major | Decision |
|----------|-------|----------|
| 0 | 0-2 | APPROVED |
| 0 | 3+ | NEEDS FIXES |
| 1+ | any | NEEDS FIXES |

#### 6.3 Write Reviewer Note & Metadata

- Edit `<!-- SECTION:summary -->` → Write a synthesized "Reviewer Note" (2-5 sentences) as a senior code reviewer's overall impression. Cover: what was implemented, quality, notable strengths/concerns, and the bottom-line verdict. NOT a list of agent outputs.
- Edit `<!-- SECTION:metadata -->` → List all agents actually invoked with one-line summary + timestamp
- Update header **Status** from PENDING to final decision

### GATE 7: Completion

1. Notify user of outcome and next steps
2. If APPROVED: ready for PR merge
3. If NEEDS FIXES: return to `/si` to address issues, then run `/sr` again

## SEVERITY LEVELS

- `[CRITICAL]` — Must fix before merge (blocks approval)
- `[MAJOR]` — Should fix (3+ blocks approval)
- `[MINOR]` — Nice to fix (does not block)
- `[INFO]` — Observations (does not block)

## STATUS MAPPING

- APPROVED → "Ready to Merge"
- NEEDS FIXES → "Needs Fixes — return to /si"
- GATE_FAILED → "Quality Gate Failed — fix build/lint/tests first"

## OUTPUT

Single `Code Review - [Task].md` in task directory. Invoked agents write to designated sections. Orchestrator writes Reviewer Note, Consolidated Issues, Decision, and Metadata.
