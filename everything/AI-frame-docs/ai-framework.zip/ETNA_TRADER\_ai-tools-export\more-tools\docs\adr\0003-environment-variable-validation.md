# ADR-0003: Environment Variable Runtime Validation

**Status**: Accepted  
**Date**: 2025-12-08

## Context

HTTP clients require environment variables (`EXPO_PUBLIC_PRIMARY_API_URL`, `EXPO_PUBLIC_PRIMARY_API_KEY`, etc.) to be set at runtime. Previously, we used TypeScript's non-null assertion operator (`!`) to tell the compiler these values exist, but this doesn't validate at runtime. If an environment variable is missing, the app fails silently with `undefined` values, leading to cryptic errors like "Cannot read property of undefined" or empty URLs in HTTP requests.

Additionally, the `.env` file was missing from the repository, causing immediate failures when the validation was added.

## Use Cases

- **UC1**: Developer starts app without `.env` file → should get clear error message
- **UC2**: Developer forgets to set required env var → should fail fast with helpful message
- **UC3**: CI/CD pipeline missing env vars → should fail build/deploy with clear error
- **UC4**: Production deployment with missing config → should fail immediately, not at runtime during API calls

## Options Considered

### Option 1: Keep Non-Null Assertion (`!`)

Continue using `process.env.EXPO_PUBLIC_PRIMARY_API_URL!` with no runtime validation.

**Pros**:
- Simple, no extra code
- TypeScript type checking

**Cons**:
- No runtime validation — fails silently with `undefined`
- Cryptic errors when values are missing
- Hard to debug — errors appear later in HTTP calls, not at startup
- Production failures happen during user interactions, not at app start

### Option 2: Runtime Validation with `requireEnv()` Helper

Add `requireEnv()` helper function that throws descriptive errors if env vars are missing.

**Pros**:
- Fails fast at startup with clear error messages
- Easy to debug — error points to exact missing variable
- Prevents silent failures
- Better developer experience
- Catches issues in CI/CD before deployment

**Cons**:
- Requires `.env` file to exist (but this is already expected)
- Slightly more code (but minimal)

### Option 3: Default Values with Warnings

Provide fallback values and log warnings when env vars are missing.

**Pros**:
- App doesn't crash
- Can use development defaults

**Cons**:
- Hides configuration errors
- Production could use wrong defaults silently
- Security risk if API keys default to test values
- Warnings can be missed in logs

## Decision

We chose **Option 2 (Runtime Validation with `requireEnv()` Helper)** because:

1. **Fail-fast principle**: Better to fail at startup than during user interactions
2. **Clear error messages**: Developers immediately know what's missing
3. **Security**: Prevents accidental use of wrong/default API endpoints
4. **CI/CD safety**: Builds fail early if configuration is incomplete
5. **Minimal overhead**: Simple helper function, no performance impact

## Implementation

### `requireEnv()` Helper

```typescript
// infrastructure/http/core/httpClients.ts
function requireEnv(key: string): string {
  const value = process.env[key];
  if (!value) {
    throw new Error(
      `Missing required environment variable: ${key}. ` +
      `Please set it in your .env file or environment configuration.`
    );
  }
  return value;
}
```

### Usage

```typescript
export const httpClientPrimary = createHttpClient({
  baseURL: requireEnv("EXPO_PUBLIC_PRIMARY_API_URL"),
  apiKey: requireEnv("EXPO_PUBLIC_PRIMARY_API_KEY"),
  // ...
});
```

### `.env` File

Created `.env` file (not committed to git) with required variables:
- `EXPO_PUBLIC_PRIMARY_API_URL`
- `EXPO_PUBLIC_PRIMARY_API_KEY`
- `EXPO_PUBLIC_SECONDARY_API_URL`
- `EXPO_PUBLIC_SECONDARY_API_KEY`

Template available in `.env.example` for new developers.

## Consequences

### What Becomes Easier

- **Onboarding**: New developers get immediate, clear error if `.env` is missing
- **Debugging**: Errors point to exact missing variable, not cryptic HTTP failures
- **CI/CD**: Builds fail early if environment configuration is incomplete
- **Production safety**: Deployment fails if required config is missing
- **Developer experience**: Clear error messages guide developers to solution

### What Becomes Harder

- **Initial setup**: Developers must create `.env` file (but `.env.example` provides template)
- **Optional variables**: Can't use `requireEnv()` for optional vars (use `process.env.VAR || defaultValue` instead)

### Follow-up Actions

- ✅ Created `.env` file with required variables
- ✅ Added `requireEnv()` helper to `httpClients.ts`
- ✅ Updated `httpClientFactory.ts` to validate `baseURL` and `apiKey` in `createHttpClient()`
- ✅ Improved logging to handle undefined values gracefully
- 📝 Documented in `docs/environment-variables.md`

### Related Documentation

- [Environment Variables Guide](../environment-variables.md)
- [HTTP Infrastructure Guide](../http-infrastructure.md)
