# Languages & Architecture Reference

## Supported Languages

| Locale | Language | File | Notes |
|--------|----------|------|-------|
| `en` | English | `src/shared/localization/locales/en/common.json` | **Source of truth** |
| `es` | Spanish | `src/shared/localization/locales/es/common.json` | |
| `zh-TW` | Chinese (Traditional) | `src/shared/localization/locales/zh-TW/common.json` | |
| `zh-CN` | Chinese (Simplified) | `src/shared/localization/locales/zh-CN/common.json` | |
| `ru` | Russian | `src/shared/localization/locales/ru/common.json` | |
| `fr` | French | `src/shared/localization/locales/fr/common.json` | |

All locales must have identical keys. English is always the reference — other locales must not have keys that are missing from English.

---

## File Structure

```
src/shared/localization/
├── locales/
│   ├── en/common.json      ← SOURCE OF TRUTH
│   ├── es/common.json
│   ├── zh-TW/common.json
│   ├── zh-CN/common.json
│   ├── ru/common.json
│   └── fr/common.json
├── i18n.ts                 ← i18next configuration + resource bundles
└── utils.ts                ← Locale mapping utilities (mapToSupportedLocale, SUPPORTED_LOCALES)
```

---

## Architecture

| Layer | File | Responsibility |
|-------|------|----------------|
| Store | `src/store/slices/localization.slice.ts` | Global locale state, AsyncStorage persistence |
| Shared | `src/shared/localization/i18n.ts` | i18next configuration |
| Shared | `src/shared/localization/utils.ts` | `SUPPORTED_LOCALES`, `mapToSupportedLocale()` |
| Composition | `src/composition/LocalizationProvider.tsx` | Initialization on app start |
| Features | `src/features/profile/components/LanguageSelector.tsx` | Language selection UI |

### Provider placement in `app/_layout.tsx`

```tsx
<AppInitializationProvider>
  <LocalizationProvider>   ← initializes locale after app startup
    <AuthProvider>
      ...
```

---

## Adding a New Language

1. Create `src/shared/localization/locales/<locale>/common.json` with all keys translated from `en/common.json`
2. Add `<locale>` to `SUPPORTED_LOCALES` in `src/shared/localization/utils.ts`:
   ```ts
   export const SUPPORTED_LOCALES: SupportedLocale[] = [
     "en", "es", "zh-TW", "zh-CN", "ru", "fr",
     "de", // ← new
   ];
   ```
3. Update `SupportedLocale` type in `src/store/slices/localization.slice.ts`:
   ```ts
   export type SupportedLocale = "en" | "es" | "zh-TW" | "zh-CN" | "ru" | "fr" | "de";
   ```
4. Add locale mapping in `mapToSupportedLocale()` in `utils.ts` if needed
5. Register resource bundle in `src/shared/localization/i18n.ts`
6. Add language option in `LanguageSelector.tsx`

---

## Locale Selection Priority

On app start, `LocalizationProvider` selects locale in this order:

1. Persisted preference from AsyncStorage
2. Device language (mapped via `mapToSupportedLocale()`)
3. Fallback: `"en"`
