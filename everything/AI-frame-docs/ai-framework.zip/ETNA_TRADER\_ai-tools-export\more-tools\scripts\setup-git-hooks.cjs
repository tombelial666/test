#!/usr/bin/env node

/**
 * Setup Git Hooks
 *
 * Installs git hooks for the project.
 * Run this script after cloning the repository.
 */

const fs = require('fs');
const path = require('path');

const HOOK_CONTENT = `#!/bin/sh

# Pre-commit hook to check for hardcoded colors
# Prevents commits containing hardcoded color values

echo "🔍 Checking staged files for hardcoded colors..."

# Run the hardcoded color check on staged files only
node scripts/check-hardcoded-colors.cjs --staged

# Capture exit code
EXIT_CODE=$?

if [ $EXIT_CODE -ne 0 ]; then
  echo ""
  echo "❌ Commit blocked: Hardcoded colors detected!"
  echo ""
  echo "Please replace hardcoded colors with design tokens."
  echo "See: docs/design-tokens.md"
  echo ""
  exit 1
fi

echo "✅ Pre-commit check passed!"
exit 0
`;

function setupGitHooks() {
  const hookPath = path.join(process.cwd(), '.git', 'hooks', 'pre-commit');

  // No .git directory — CI/EAS environment or non-git context, skip silently
  if (!fs.existsSync(path.join(process.cwd(), '.git'))) {
    console.log('ℹ️  No .git directory found, skipping git hooks setup.');
    return;
  }

  try {
    // Create hooks directory if it doesn't exist
    const hooksDir = path.join(process.cwd(), '.git', 'hooks');
    if (!fs.existsSync(hooksDir)) {
      fs.mkdirSync(hooksDir, { recursive: true });
    }

    // Write the pre-commit hook
    fs.writeFileSync(hookPath, HOOK_CONTENT, { mode: 0o755 });

    console.log('✅ Git hooks installed successfully!');
    console.log('');
    console.log('Installed hooks:');
    console.log('  - pre-commit: Checks for hardcoded colors');
    console.log('');
    console.log('The pre-commit hook will run automatically when you commit changes.');
  } catch (error) {
    console.warn('⚠️  Could not install git hooks:', error.message);
  }
}

// Run if executed directly
if (require.main === module) {
  setupGitHooks();
}

module.exports = { setupGitHooks };
