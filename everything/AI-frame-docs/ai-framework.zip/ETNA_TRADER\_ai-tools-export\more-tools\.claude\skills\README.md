# MobileLiteApp Skills

AI workflow skills for MobileLiteApp (Expo + TypeScript + React Query + Zustand).

## Core Workflow Skills

| Skill | Purpose |
|---|---|
| `/nf` | New feature discovery and scope shaping |
| `/ct` | Technical decomposition with TDD-first plan |
| `/si` | Structured implementation and execution |
| `/sr` or `/cr` | Multi-agent pre-merge review |

### Typical Flow

- **Full flow**: `/nf` → `/ct` → `/si` → `/sr`
- **Fast flow** (clear requirements): `/ct` → `/si` → `/sr`
- **Review loop**: `/si` → `/sr` → `/si` (fixes) → `/sr`

## Supporting Skills

| Skill | Purpose |
|---|---|
| `/parallelization` | Split implementation into isolated workers |
| `/udoc` | Update docs and changelog from completed task |

## Project-Specific Skills

| Skill | Purpose |
|---|---|
| `/design-tokens` | Design token color system guidance |
| `/localization` | i18n/localization guidance |
| `/react-native-expo` | React Native + Expo best practices |
| `/theme` | Theme system (light/dark/brand) |

## Workflow Diagram

```
/nf → /ct → /si → /sr
         ↑         ↓
         └─── (fixes if NEEDS FIXES)
```

## MobileLiteApp Rules (enforced across all skills)

- **No hardcoded colors** → `useThemeColors()` from `@/shared/theme/hooks`
- **No hardcoded strings** → `t("key")` from react-i18next
- **Layer boundaries** → features don't import infrastructure
- **Tests** → `tests/unit/` or `tests/integration/` mirroring `src/`

## Full Reference

See `docs/dev-workflow/commands-reference.md` for complete workflow documentation.
