# AI Coding Commands — MobileLiteApp Reference

This reference describes the complete AI workflow for MobileLiteApp development.

## Core Commands

| Command | Purpose | Output |
|---|---|---|
| `/nf` | Discover and challenge feature scope | `tasks/task-<date>-<feature>/discovery-<feature>.md` |
| `/ct` | Build implementation-ready tech decomposition (TDD-first) | `tech-decomposition-<feature>.md` (+ optional split docs) |
| `/si` | Execute implementation in structured TDD steps | Updated code/tests + updated task doc + quality report |
| `/sr` or `/cr` | Run multi-agent code review before merge | `Code Review - <Task>.md` |

## Supporting Commands

| Command | Purpose | Output |
|---|---|---|
| `/udoc` | Update docs and changelog from completed task | Updated `docs/` + `docs/changelogs/YYYY-MM-DD/changelog.md` |
| `/parallelization` | Split implementation into isolated workers | Parallel work items + merged results |
| `/design-tokens` | Design token guidance | Token selection guidance |
| `/localization` | i18n guidance | Translation key guidance |
| `/react-native-expo` | RN/Expo best practices | Pattern guidance |

## Flow Diagram

```
Feature Request
      │
      ▼
  Need Discovery?
  /    \
Yes    No
 │      │
/nf    /ct ◄────────────────┐
 │      │                    │
 └──────┘                    │ (revisions)
        │                    │
       /ct ──► plan-reviewer + senior-architecture-reviewer
        │                    │
        ▼              ──────┘
   task-splitter
   /          \
Split?        No
  │            │
task-decomposer│
  │            │
  └────────────┘
        │
       /si ◄──────────────────────┐
        │                         │ (fixes)
       /sr ──────────────────────►┘
        │
     Approved?
      │    │
     Yes   No ──► back to /si
      │
  Ready to Merge
        │
      /udoc (update docs + changelog)
```

## `/ct` Sub-Flow

1. Check for discovery doc (`tasks/task-*/discovery-*.md`)
2. Explore codebase with Explore sub-agent
3. If UI-heavy task: invoke `mobile-ui-planning-agent` (GATE 0.7)
4. Create tech-decomposition with **Test Plan first** (TDD)
5. Run `plan-reviewer` + `senior-architecture-reviewer` (automatic)
6. Iterate until both approve
7. Run `task-splitter` for splitting evaluation
8. If split approved: run `task-decomposer`
9. Final task package ready for `/si`

## `/si` Sub-Flow

1. Validate task scope and acceptance criteria
2. Implement by TDD cycles (Red → Green → Refactor)
3. Update task doc after every completed step
4. Run `automated-quality-gate` for final verification
5. Update status to "Ready for Review"
6. Prepare PR context (branch, test evidence, summary)

## `/sr` or `/cr` Sub-Flow

1. Scaffold `Code Review - [Task].md` from template
2. Quality gate (reuse from `/si` if valid, or run fresh)
3. `senior-architecture-reviewer` (sequential — gates the review)
4. Parallel lean review: `security-code-reviewer` + conditional `performance-reviewer`
5. Optional strict mode: add `code-quality-reviewer`, `test-coverage-reviewer`, `documentation-accuracy-reviewer`
6. Consolidate issues and write decision (APPROVED / NEEDS FIXES)
7. If not approved, return to `/si`

## Edge Cases

- **No discovery needed**: start directly with `/ct`
- **Task too large**: handled by `task-splitter` → `task-decomposer` in `/ct`
- **Review failed**: loop `/si` ↔ `/sr` until approval
- **Paused work / handoff**: keep task doc updated so implementation can be resumed
- **Bug fix**: use `/si` directly with a bug description (no `/ct` needed for simple fixes)

## MobileLiteApp-Specific Rules (enforced in all flows)

| Rule | Tool |
|------|------|
| No hardcoded colors | `useThemeColors()` from `@/shared/theme/hooks` |
| No hardcoded strings | `t("key")` from react-i18next |
| Features don't import infrastructure | Layer boundary check in `/sr` |
| React Query hooks in `features/<f>/hooks/queries.ts` | Architecture check in `/sr` |
| Test files in `tests/unit/` or `tests/integration/` | Verified in `/si` and `/sr` |
| Named exports only | Code quality check in `/sr` |

## Test Commands

```bash
# Run all tests
npm test -- --passWithNoTests --silent 2>&1 | tail -20

# Run targeted tests
npm test -- --testPathPattern="<feature>" --no-coverage 2>&1 | tail -30

# TypeScript check
npx tsc --noEmit

# Lint
npm run lint
```

## File Locations

| File Type | Path |
|-----------|------|
| Task directory | `tasks/task-YYYY-MM-DD-[feature]/` |
| Tech decomposition | `tasks/.../tech-decomposition-[feature].md` |
| Discovery | `tasks/.../discovery-[feature].md` |
| UI planning | `tasks/.../ui-planning-analysis-[feature].md` |
| Code review | `tasks/.../Code Review - [Task].md` |
| Plan review | `tasks/.../Plan Review - [Task].md` |
| Splitting decision | `tasks/.../splitting-decision.md` |
| Tech decomp template | `docs/product-docs/templates/technical-decomposition-template.md` |
| Code review template | `docs/product-docs/templates/code-review-template.md` |
| Changelogs | `docs/changelogs/YYYY-MM-DD/changelog.md` |

## Agents Overview

| Agent | Location | When Used |
|-------|----------|-----------|
| `automated-quality-gate` | `automation-agents/` | End of `/si`, start of `/sr` |
| `developer-agent` | `automation-agents/` | Parallel work in `/parallelization` |
| `senior-architecture-reviewer` | `automation-agents/` | `/ct` plan review + `/sr` approach review |
| `security-code-reviewer` | `code-review-agents/` | `/sr` LEAN (always) |
| `performance-reviewer` | `code-review-agents/` | `/sr` LEAN (conditional) |
| `code-quality-reviewer` | `code-review-agents/` | `/sr` STRICT only |
| `test-coverage-reviewer` | `code-review-agents/` | `/sr` STRICT only |
| `documentation-accuracy-reviewer` | `code-review-agents/` | `/sr` STRICT only |
| `plan-reviewer` | `tasks-validators-agents/` | `/ct` plan review |
| `task-splitter` | `tasks-validators-agents/` | `/ct` splitting evaluation |
| `task-decomposer` | `tasks-validators-agents/` | `/ct` splitting execution |
| `task-pm-validator` | `tasks-validators-agents/` | Optional strict doc validation |
| `mobile-ui-planning-agent` | `mobile-app-agents/` | `/ct` GATE 0.7 for UI-heavy tasks |
| `docs-updater` | `wf-agents/` | `/udoc` step 2 |
| `changelog-generator` | `wf-agents/` | `/udoc` step 3 |
