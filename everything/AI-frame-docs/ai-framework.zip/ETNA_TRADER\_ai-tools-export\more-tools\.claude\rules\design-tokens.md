# Design Tokens - Color Usage Rules for Claude

**CRITICAL RULE**: Never generate code with hardcoded color values in TSX/TypeScript files.

## Prohibited Patterns

### ❌ NEVER Write Hardcoded Colors

```tsx
// ❌ PROHIBITED - Do not generate this
<View style={{ backgroundColor: '#007AFF' }}>
<Text style={{ color: 'rgb(0, 122, 255)' }}>
<View style={{ borderColor: 'rgba(0, 0, 0, 0.1)' }}>

const styles = StyleSheet.create({
  container: { backgroundColor: '#FFFFFF' },
  text: { color: '#000000' }
});
```

## Required Pattern

### ✅ ALWAYS Use Design Tokens via `useThemeColors()` Hook

```tsx
import { useThemeColors } from '@/shared/theme/hooks';

function MyComponent() {
  const colors = useThemeColors();

  return (
    <View style={{ backgroundColor: colors.background.base }}>
      <Text style={{ color: colors.text.base }}>
        Hello World
      </Text>
    </View>
  );
}
```

## Token Access Reference

### Core Tokens
- `colors.text.base` - Primary text
- `colors.text.secondary` - Secondary text
- `colors.background.base` - Primary background
- `colors.background.secondary` - Secondary background
- `colors.icon.base` - Primary icon
- `colors.border.base` - Primary border

### Sentiment Tokens
- `colors.text.brand?.base` - Brand color
- `colors.text.danger?.base` - Error/destructive
- `colors.text.success?.base` - Success
- `colors.text.warning?.base` - Warning
- `colors.background.brand?.base` - Brand background

### Component Tokens
- `colors.link.text.base` - Link
- `colors.link.text.hover` - Link hover
- `colors.field.border.focus` - Input focus
- `colors.field.border.error` - Input error
- `colors.control.background.checked` - Checkbox checked

### Compound Component Tokens
- `colors.card.background.base` - Card
- `colors.table.background.header` - Table header
- `colors.leftnav.icon.active` - Nav active

### Interaction States
- `colors.link.text.hover` - Hover
- `colors.link.text.active` - Active/pressed
- `colors.text.disabled` - Disabled
- `colors.field.border.focus` - Focus

## Code Generation Rules

1. **When writing new components**: Always import `useThemeColors` hook
2. **When refactoring existing code**: Replace hardcoded colors with tokens
3. **When user requests specific colors**: Use semantic tokens, not hex values
4. **When uncertain which token**: Use `/design-tokens` skill for guidance

## Complete Example

```tsx
import { useThemeColors } from '@/shared/theme/hooks';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';

export function PrimaryButton({ title, onPress }: Props) {
  const colors = useThemeColors();

  return (
    <TouchableOpacity
      style={[
        styles.button,
        { backgroundColor: colors.background.brand?.base }
      ]}
      onPress={onPress}
    >
      <Text style={{ color: colors.text.onbrand?.base }}>
        {title}
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    padding: 16,
    borderRadius: 8,
    // Only non-color styles here
  }
});
```

## Allowed Exceptions

**ONLY** these files may contain hex/rgb values:
- `src/shared/theme/tokens/light.ts`
- `src/shared/theme/tokens/dark.ts`
- `src/shared/brand/*/colors.ts`
- Test files (`tests/**/*.spec.{ts,tsx}`)

## Pre-commit Enforcement

The project has a pre-commit hook that detects hardcoded colors. Code with hardcoded colors will be blocked from committing.

## Token Naming Convention

Format: `location.compoundcomponent.component.usage.sentiment.prominence-interaction`

**Parts** (defaults omitted from path):
- **Location**: default | login | marketing | sidepanel
- **Compound Component**: default | card | table | filter | leftnav | topnav
- **Component**: default | link | field | control | tooltip
- **Usage**: background | text | icon | border | shell
- **Sentiment**: default | brand | success | warning | danger | info | onbrand
- **Prominence**: base | secondary | tertiary | strong
- **Interaction**: -hover | -active | -disabled | -selected

## Quick Reference for Common UI Elements

| UI Element | Token Path |
|------------|-----------|
| Primary button background | `colors.background.brand?.base` |
| Primary button text | `colors.text.onbrand?.base` |
| Danger button | `colors.background.danger?.base` |
| Link | `colors.link.text.base` |
| Input border | `colors.field.border.base` |
| Input focus | `colors.field.border.focus` |
| Input error | `colors.field.border.error` |
| Card background | `colors.card.background.base` |
| Disabled text | `colors.text.disabled` |

## Additional Resources

- **Full Documentation**: `docs/design-tokens.md`
- **ADR**: `docs/adr/0008-design-tokens-system.md`
- **Skill Command**: `/design-tokens` - Use for detailed guidance

## TypeScript Support

All tokens are fully typed. TypeScript autocomplete will guide you to available token paths. Trust the type system!

---

**Remember**: When in doubt, use `/design-tokens` skill for guidance on which token to use for specific UI elements.
