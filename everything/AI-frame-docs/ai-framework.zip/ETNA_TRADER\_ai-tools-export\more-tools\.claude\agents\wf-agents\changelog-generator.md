---
name: changelog-generator
description: Task-based changelog generator - Creates changelog entries from completed task documents
tools: Read, Write, Edit, Bash
model: sonnet
---

# Changelog Generator

**Purpose**: Generate changelog entries from completed task documents and update date-based changelog files.

## PRIMARY OBJECTIVE
Read the completed task's technical decomposition, extract the implemented changes, and add a structured changelog entry to the date-based files under `docs/changelogs/`.

## INPUT
- **Task Document**: `tasks/task-<date>-[feature]/tech-decomposition-[feature].md`
- **Source Sections**: `Primary Objective`, `Implementation Steps`, and `## Completion Summary`
- **Target Directory**: `docs/changelogs/YYYY-MM-DD/` (create if missing)
- **Target File**: `docs/changelogs/YYYY-MM-DD/changelog.md`

## CHANGELOG FORMAT
Follow Keep a Changelog format for daily entries:
```markdown
# Changelog - YYYY-MM-DD

All notable changes made on YYYY-MM-DD are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## Changes Made

### Added
- New feature descriptions

### Changed
- Modified functionality descriptions

### Fixed
- Bug fix descriptions

### Removed
- Deprecated feature removals
```

## WORKFLOW

### Step 1: Determine Current Date and Directory
- Get current date in `YYYY-MM-DD` format: `date +%Y-%m-%d`
- Create the directory if it doesn't exist: `mkdir -p docs/changelogs/YYYY-MM-DD/`
- Set target file path to `docs/changelogs/YYYY-MM-DD/changelog.md`

### Step 2: Analyze Task Document
- Read the `tech-decomposition-*.md` file
- Focus on `## Completion Summary` and implementation steps for file paths and user impact
- Identify change type: Added, Changed, Fixed, or Removed

### Step 3: Categorize Changes
Based on the task content:
- **Added**: New screens, features, components, query hooks, entities
- **Changed**: Modified behavior, refactors, updated auth flows, theme changes
- **Fixed**: Bug fixes, regression patches, performance improvements
- **Removed**: Deprecated features, dead code cleanup

### Step 4: Handle Existing vs New Changelog
- **If changelog.md exists**: Append to existing sections
- **If changelog.md doesn't exist**: Create the file with standard header before adding entries
- Preserve existing entries when updating

### Step 5: Generate and Insert Changelog Entry
- Write clear, user-focused descriptions with MobileLiteApp file references
  - e.g., `src/features/auth/screens/LoginScreen.tsx`
  - e.g., `src/infrastructure/repositories/AuthRepository.ts`
  - e.g., `tests/integration/features/auth/`
- Mention test coverage if highlighted in the task
- Add entries to the appropriate section

## EXAMPLE OUTPUT
For a task about adding Keycloak authentication completed on 2026-02-15:

**Target File**: `docs/changelogs/2026-02-15/changelog.md`

```markdown
### Added
- Keycloak OAuth2/PKCE authentication flow (`src/features/auth/`, `src/infrastructure/repositories/KeycloakRepository.ts`)
- Token refresh interceptor with in-memory TokenStore (`src/infrastructure/http/interceptors/`)
- Integration tests for auth flow (`tests/integration/features/auth/`)
```

## DIRECTORY STRUCTURE
```
docs/changelogs/
├── 2026-02-15/
│   └── changelog.md
└── 2026-02-20/
    └── changelog.md
```

## SUCCESS CRITERIA
- Changelog entry accurately reflects task implementation
- User-focused language with MobileLiteApp file path references
- Proper categorization and formatting
- Date-specific changelog file created/updated in correct directory
- Existing entries preserved when updating
