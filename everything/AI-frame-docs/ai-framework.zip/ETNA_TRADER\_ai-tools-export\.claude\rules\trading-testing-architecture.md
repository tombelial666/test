# Testing Architecture — ETNA_TRADER

## File Naming Conventions

| Type | Pattern | Example |
|------|---------|---------|
| Unit test (NUnit/xUnit) | `*Tests.cs` or `*.Tests.cs` | `OrderValidatorTests.cs` |
| Integration test | `*IntegrationTests.cs` | `OrderApiIntegrationTests.cs` |
| Fixture / helper | `*Fixture.cs`, `*Helper.cs` | `OrderFixture.cs` |
| Builder / factory | `*Builder.cs`, `*Factory.cs` | `OrderBuilder.cs` |

## Project Layout (`qa/` folder)

```
qa/
├── Etna.BackEnd.Tests/                    ← Core backend unit tests
├── Etna.Trader.FrontOffice.Tests/         ← FrontOffice service tests
├── Etna.Trader.Api.IntegrationTests/      ← REST API integration tests
├── Etna.Dao.EntityFramework.Tests/        ← EF repository tests
├── Etna.Dao.NHibernate.Tests/             ← NHibernate repository tests
├── Etna.Common.Tests/                     ← Shared utilities/helpers tests
├── fixtures/                              ← Shared test fixtures and factories
│   ├── Builders/
│   │   ├── OrderBuilder.cs
│   │   ├── AccountBuilder.cs
│   │   └── PositionBuilder.cs
│   └── Scenarios/
│       ├── OrderPlacementScenario.cs
│       └── AccountFundingScenario.cs
└── Etna.Tests.sln
```

## When to Write Tests

### Unit Tests — isolated, deterministic logic

- **Domain**: order validators, position calculators, risk rules, price formatters
- **Mappers**: DTO ↔ domain model mapping (EF entities, NHibernate entities, API DTOs)
- **Calculators**: P&L, margin, commission, lot-size calculations
- **Validators**: `IOrderValidator`, `IAccountValidator` implementations
- **Service logic**: pure business rules with all dependencies mocked
- **Stores/Reducers**: Zustand slices, pure state transitions (frontend)

### Integration Tests — real flow across layers

- **Repository tests**: SQL queries against a local/testcontainer SQL Server (EF + NHibernate)
- **API endpoint tests**: full HTTP round-trip via `WebApplicationFactory` or TestServer
- **Service-to-DAL tests**: service calls with real EF/NHibernate context, in-memory or test DB
- **Cross-layer flows**: order placement → position update → account balance change
- **Azure Pipelines**: all integration tests tagged `[Category("Integration")]` run on CI with a dedicated DB

### Optional / Not Required

- Thin controller glue already covered by integration tests
- Auto-generated mapping code (e.g., AutoMapper profiles with no conditional logic)

## Test Factories and Builders (Trading Domain)

Use the **Builder pattern** for domain objects. Keep builders in `qa/fixtures/Builders/`.

### OrderBuilder

```csharp
// qa/fixtures/Builders/OrderBuilder.cs
namespace Etna.Tests.Fixtures.Builders;

public class OrderBuilder
{
    private string _id = Guid.NewGuid().ToString();
    private string _accountId = "ACC-001";
    private string _symbol = "AAPL";
    private OrderSide _side = OrderSide.Buy;
    private OrderType _type = OrderType.Market;
    private int _quantity = 100;
    private decimal? _limitPrice = null;
    private OrderStatus _status = OrderStatus.New;

    public OrderBuilder WithId(string id) { _id = id; return this; }
    public OrderBuilder WithAccount(string accountId) { _accountId = accountId; return this; }
    public OrderBuilder WithSymbol(string symbol) { _symbol = symbol; return this; }
    public OrderBuilder AsBuy() { _side = OrderSide.Buy; return this; }
    public OrderBuilder AsSell() { _side = OrderSide.Sell; return this; }
    public OrderBuilder AsLimit(decimal price) { _type = OrderType.Limit; _limitPrice = price; return this; }
    public OrderBuilder WithQuantity(int qty) { _quantity = qty; return this; }
    public OrderBuilder WithStatus(OrderStatus status) { _status = status; return this; }

    public Order Build() => new Order
    {
        Id = _id,
        AccountId = _accountId,
        Symbol = _symbol,
        Side = _side,
        Type = _type,
        Quantity = _quantity,
        LimitPrice = _limitPrice,
        Status = _status,
        CreatedAt = DateTime.UtcNow,
    };

    public static OrderBuilder Default() => new OrderBuilder();
    public static IEnumerable<Order> BuildList(int count, Action<OrderBuilder, int>? configure = null)
    {
        for (int i = 0; i < count; i++)
        {
            var builder = new OrderBuilder().WithId($"ORD-{i:D4}");
            configure?.Invoke(builder, i);
            yield return builder.Build();
        }
    }
}
```

### AccountBuilder

```csharp
// qa/fixtures/Builders/AccountBuilder.cs
public class AccountBuilder
{
    private string _id = "ACC-001";
    private string _name = "Test Account";
    private decimal _cashBalance = 100_000m;
    private AccountType _type = AccountType.Cash;

    public AccountBuilder WithId(string id) { _id = id; return this; }
    public AccountBuilder WithBalance(decimal balance) { _cashBalance = balance; return this; }
    public AccountBuilder AsMargin() { _type = AccountType.Margin; return this; }

    public Account Build() => new Account
    {
        Id = _id,
        Name = _name,
        CashBalance = _cashBalance,
        Type = _type,
    };

    public static AccountBuilder Default() => new AccountBuilder();
}
```

### PositionBuilder

```csharp
// qa/fixtures/Builders/PositionBuilder.cs
public class PositionBuilder
{
    private string _symbol = "AAPL";
    private string _accountId = "ACC-001";
    private int _quantity = 100;
    private decimal _averagePrice = 150m;

    public PositionBuilder WithSymbol(string symbol) { _symbol = symbol; return this; }
    public PositionBuilder WithQuantity(int qty) { _quantity = qty; return this; }
    public PositionBuilder WithAveragePrice(decimal price) { _averagePrice = price; return this; }

    public Position Build() => new Position
    {
        Symbol = _symbol,
        AccountId = _accountId,
        Quantity = _quantity,
        AveragePrice = _averagePrice,
    };

    public static PositionBuilder Default() => new PositionBuilder();
}
```

## Mocking — Moq / NSubstitute

Prefer **NSubstitute** for interface mocking. Use **Moq** only in projects already using it.

```csharp
// NSubstitute (preferred)
var orderRepository = Substitute.For<IOrderRepository>();
orderRepository.GetByIdAsync("ORD-001", Arg.Any<CancellationToken>())
    .Returns(Task.FromResult<Order?>(OrderBuilder.Default().Build()));

// Moq (legacy / existing projects)
var mock = new Mock<IOrderRepository>();
mock.Setup(r => r.GetByIdAsync("ORD-001", It.IsAny<CancellationToken>()))
    .ReturnsAsync(OrderBuilder.Default().Build());
```

## Test Style — Arrange / Act / Assert

```csharp
[TestFixture]
public class OrderValidatorTests
{
    private OrderValidator _sut = null!;

    [SetUp]
    public void SetUp()
    {
        _sut = new OrderValidator();
    }

    [Test]
    public async Task ValidateAsync_WhenQuantityIsZero_ReturnsValidationError()
    {
        // Arrange
        var order = OrderBuilder.Default().WithQuantity(0).Build();

        // Act
        var result = await _sut.ValidateAsync(order, CancellationToken.None);

        // Assert
        Assert.That(result.IsValid, Is.False);
        Assert.That(result.Errors, Has.Exactly(1).Items);
        Assert.That(result.Errors[0].PropertyName, Is.EqualTo(nameof(Order.Quantity)));
    }
}
```

## NUnit Attributes Cheat Sheet

```csharp
[TestFixture]              // class
[SetUp]                    // runs before each test
[TearDown]                 // runs after each test
[OneTimeSetUp]             // runs once before all tests in class
[OneTimeTearDown]          // runs once after all tests in class
[Test]                     // test method
[TestCase(arg1, arg2)]     // parameterized test
[Theory]                   // data-driven (with [DataPoints])
[Category("Integration")]  // CI filter tag
[Ignore("reason")]         // skip
```

## Integration Tests — API Layer

```csharp
// qa/Etna.Trader.Api.IntegrationTests/OrdersControllerTests.cs
[TestFixture]
[Category("Integration")]
public class OrdersControllerTests : IDisposable
{
    private readonly WebApplicationFactory<Program> _factory;
    private readonly HttpClient _client;

    public OrdersControllerTests()
    {
        _factory = new WebApplicationFactory<Program>()
            .WithWebHostBuilder(builder =>
            {
                builder.ConfigureServices(services =>
                {
                    // Replace DB context with test DB
                    services.RemoveAll<DbContextOptions<EtnaDbContext>>();
                    services.AddDbContext<EtnaDbContext>(opts =>
                        opts.UseSqlServer(TestConnectionString));
                });
            });
        _client = _factory.CreateClient();
    }

    [Test]
    public async Task PostOrder_WithValidPayload_Returns201Created()
    {
        // Arrange
        var payload = new PlaceOrderRequest
        {
            AccountId = "ACC-001",
            Symbol = "AAPL",
            Side = "Buy",
            Quantity = 100,
            Type = "Market",
        };

        // Act
        var response = await _client.PostAsJsonAsync("/api/v1/orders", payload);

        // Assert
        Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Created));
        var body = await response.Content.ReadFromJsonAsync<OrderResponse>();
        Assert.That(body!.Status, Is.EqualTo("New"));
    }

    public void Dispose() => _factory.Dispose();
}
```

## Path Mirroring Convention

```
src/Etna.Trader.FrontOffice/Services/OrderService.cs
qa/Etna.Trader.FrontOffice.Tests/Services/OrderServiceTests.cs

src/Etna.Trading.Contracts/Validators/OrderValidator.cs
qa/Etna.BackEnd.Tests/Validators/OrderValidatorTests.cs

src/Etna.Dao.EntityFramework/Repositories/OrderRepository.cs
qa/Etna.Dao.EntityFramework.Tests/Repositories/OrderRepositoryTests.cs
```

## Running Tests

```bash
# All unit tests
dotnet test qa/Etna.BackEnd.Tests/

# All tests in solution
dotnet test qa/Etna.Tests.sln

# Filter by category (CI integration gate)
dotnet test qa/Etna.Tests.sln --filter "Category=Integration"

# Specific test
dotnet test qa/Etna.Trader.FrontOffice.Tests/ --filter "FullyQualifiedName~OrderServiceTests"

# With coverage
dotnet test qa/Etna.Tests.sln --collect:"XPlat Code Coverage"
```
