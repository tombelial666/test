# Splitting Decision: [Task Name]

**Date**: YYYY-MM-DD | **Agent**: `task-splitter`
**Task**: `[path/to/task-directory]`
**Decision**: SPLIT RECOMMENDED / NO SPLIT

---

## Metrics Analysis

| Metric | Actual | Ideal | Maximum | Status |
|--------|--------|-------|---------|--------|
| Test cases | [N] | 10-15 | 20 | ✅/❌ |
| New files | [N] | 3-5 | 7 | ✅/❌ |
| Screens / use cases | [N] | 1-2 | 3 | ✅/❌ |
| Test suites | [N] | 1-2 | 2 | ✅/❌ |
| Feature domains | [N] | 1 | 2 | ✅/❌ |

---

## Decision

**Recommendation**: [SPLIT RECOMMENDED / NO SPLIT]

**Rationale**: [Why split or why not split. Reference specific metrics that triggered the decision.]

---

## Proposed Phase Structure (if SPLIT RECOMMENDED)

### Phase 1: [Name]

**Objective**: [What this phase delivers — specific screens/use cases]
**Scope**:
- Screens: [list]
- Use cases: [list]
- Test suites: [list]
**Estimated tests**: [N]
**Estimated new files**: [N]
**Depends on**: [none or phase X]

### Phase 2: [Name]

**Objective**: [What this phase delivers]
**Scope**:
- Screens: [list]
- Use cases: [list]
- Test suites: [list]
**Estimated tests**: [N]
**Estimated new files**: [N]
**Depends on**: Phase 1

---

## Vertical Slice Verification

For each proposed phase:

| Phase | Delivers Complete User Flow? | Independently Testable? | No Dead Code? |
|-------|------------------------------|------------------------|---------------|
| Phase 1 | ✅/❌ | ✅/❌ | ✅/❌ |
| Phase 2 | ✅/❌ | ✅/❌ | ✅/❌ |

---

## Next Steps

1. Review this splitting decision
2. If approved: run `task-decomposer` agent to execute the split
   - Creates phase folders
   - Generates phase tech-decomposition docs
   - Archives parent tech-decomposition
3. If rejected: proceed with single task implementation via `/si`

---

## Execution Summary (filled by task-decomposer after split)

_This section is filled by `task-decomposer` after the split is executed._

**Phases Created**: [N]
**Phase Folders**:
- `phase-1-[name]/tech-decomposition-phase-1-[name].md`
- `phase-2-[name]/tech-decomposition-phase-2-[name].md`

**Archived**: `initial-tech-decomposition-[feature]-ARCHIVED.md`

**Recommended Implementation Order**: Phase 1 → Phase 2
