## Agent Documentation Sync Rule

**Version**: 1.0.0 | **Scope**: MobileLiteApp

## Goal

Maintain automatic synchronization between AGENTS.md ↔ CLAUDE.md and .cursor ↔ .claude directories during agent sessions.

## When to Apply

- **IMMEDIATELY** after modifying AGENTS.md, CLAUDE.md, or any files in `.cursor/` or `.claude/`
- Before any commit operation

## Sync Requirements

### 1) AGENTS.md ↔ CLAUDE.md

- These files must always have identical content
- When either file is modified: `node scripts/sync-docs.js --fix`

### 2) .cursor ↔ .claude

- All config files in `.cursor/` must be mirrored to `.claude/` (and vice versa)
- When any file in `.cursor/` or `.claude/` is modified: `node scripts/sync-configs.js --fix`

## MANDATORY: Auto-sync Triggers

| File/Directory Modified | Command to Run |
|------------------------|----------------|
| `AGENTS.md` | `node scripts/sync-docs.js --fix` |
| `CLAUDE.md` | `node scripts/sync-docs.js --fix` |
| `.cursor/agents/*` | `node scripts/sync-configs.js --fix` |
| `.cursor/rules/*` | `node scripts/sync-configs.js --fix` |
| `.cursor/skills/*` | `node scripts/sync-configs.js --fix` |
| `.cursor/hooks.json` | `node scripts/sync-configs.js --fix` |
| `.cursor/settings.local.json` | `node scripts/sync-configs.js --fix` |

## NPM Scripts

```bash
# Sync documentation files
npm run sync:docs

# Sync Cursor/Claude directories
node scripts/sync-configs.js --fix
```

## Notes

- Pre-commit hooks enforce sync in `--check` mode (blocking commits on drift)
- Agent should proactively sync during sessions (using `--fix` flag)
- Both Cursor and Claude agents share the same scripts via `/scripts/` directory
