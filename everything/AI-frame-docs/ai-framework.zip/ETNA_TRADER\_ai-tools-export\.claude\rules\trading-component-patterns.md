# Trading Component Patterns (SolidJS + TypeScript — ACAT Frontend)

> **Stack**: `solid-js ^1.9.4`, `vite-plugin-solid`, TypeScript, SCSS (no CSS Modules)

## File Organization

- **Location**: `frontend/ACAT/src/modules/<module>/components/` for feature components, `frontend/ACAT/src/ui-kit/` for shared primitives
- **Naming**: PascalCase file + named export (`TransferStatus.tsx`, `Filters.tsx`)
- **Exports**: Named exports from component file; `index.ts` re-exports

```ts
// ✅ Correct
export const OrderForm: Component<OrderFormProps> = (props) => { ... }

// ❌ Avoid
export default function OrderForm() { ... }
```

## Props Typing

Always define a co-located type named `<ComponentName>Props`. Use `Component<Props>` from solid-js.

```tsx
import { Component } from 'solid-js';

type OrderFormProps = {
  accountId: string;
  symbol: string;
  side: 'Buy' | 'Sell';
  onSubmit: (order: PlaceOrderRequest) => void;
  onCancel: () => void;
  isSubmitting?: boolean;
};

export const OrderForm: Component<OrderFormProps> = (props) => {
  // ...
};
```

## SolidJS Critical Rules

### ⚠️ Never destructure props in SolidJS components

Destructuring breaks SolidJS reactivity. Always access via `props.xxx`.

```tsx
// ✅ Correct — reactive
export const TransferStatus: Component<{ status: string; class?: string }> = (props) => {
  return <div class={props.class}>{props.status}</div>;
};

// ❌ WRONG — breaks reactivity, prop changes won't update UI
export const TransferStatus = ({ status, class: cls }) => {
  return <div class={cls}>{status}</div>;
};
```

### ⚠️ `class` not `className`

```tsx
// ✅ SolidJS
<div class="order-form">...</div>

// ❌ React style
<div className="order-form">...</div>
```

### ⚠️ `classList` for conditional classes

```tsx
<div classList={{
  "transfer-item": true,
  "transfer-item--selected": props.isSelected,
  [`${props.class}`]: props.class !== undefined,
}}>
```

---

## State Management

SolidJS has no `useState`/`useReducer`. Use `createSignal` and `createStore`.

| State type | Tool | Import |
|------------|------|--------|
| Simple scalar (string, bool, number) | `createSignal` | `solid-js` |
| Object / form state | `createStore` | `solid-js/store` |
| Shared app state | Context + `createStore` | `solid-js`, `solid-js/store` |

### createSignal — scalar values

```tsx
import { createSignal, Component } from 'solid-js';

export const QuantityInput: Component<{ onChange: (qty: number) => void }> = (props) => {
  const [value, setValue] = createSignal('');

  const handleInput = (e: InputEvent) => {
    const v = (e.currentTarget as HTMLInputElement).value;
    setValue(v);
    props.onChange(Number(v));
  };

  return <input type="number" value={value()} onInput={handleInput} />;
};
```

### createStore — form/object state

```tsx
import { createStore } from 'solid-js/store';
import { Component } from 'solid-js';

type OrderFormState = {
  quantity: string;
  orderType: 'Market' | 'Limit';
  limitPrice: string;
};

export const OrderForm: Component<OrderFormProps> = (props) => {
  const [form, setForm] = createStore<OrderFormState>({
    quantity: '',
    orderType: 'Market',
    limitPrice: '',
  });

  const submit = () => {
    props.onSubmit({
      accountId: props.accountId,
      symbol: props.symbol,
      side: props.side,
      quantity: Number(form.quantity),
      type: form.orderType,
      limitPrice: form.orderType === 'Limit' ? Number(form.limitPrice) : undefined,
    });
  };

  return (
    <form>
      <input
        type="number"
        value={form.quantity}
        onInput={(e) => setForm('quantity', e.currentTarget.value)}
      />
      <select
        value={form.orderType}
        onChange={(e) => setForm('orderType', e.currentTarget.value as 'Market' | 'Limit')}
      >
        <option value="Market">Market</option>
        <option value="Limit">Limit</option>
      </select>
      <button type="button" onClick={submit}>
        {props.isSubmitting ? 'Submitting…' : `${props.side} ${props.symbol}`}
      </button>
      <button type="button" onClick={props.onCancel}>Cancel</button>
    </form>
  );
};
```

---

## Control Flow — Use Solid Built-ins

Never use `&&` or ternaries for conditional rendering that depends on reactive state. Use `Show` and `For`.

```tsx
import { Show, For, Component } from 'solid-js';

// ✅ Conditional rendering
<Show when={props.isLoading} fallback={<div class="grid">{/* content */}</div>}>
  <div class="spinner" />
</Show>

// ✅ List rendering
<For each={props.rows} fallback={<div class="empty">No data available</div>}>
  {(row) => (
    <div class="row" onClick={() => props.onRowClick?.(row)}>
      {row.symbol}
    </div>
  )}
</For>
```

---

## Trading-Specific Component Examples

### TransferStatus (from actual codebase)

```tsx
import { Component } from 'solid-js';

export const TransferStatus: Component<{ status: string; class?: string }> = (props) => {
  return (
    <span classList={{
      'transfer-status': true,
      [`${props.class}`]: props.class !== undefined,
    }}>
      {props.status}
    </span>
  );
};
```

### Filters (from actual codebase pattern)

```tsx
import { createStore } from 'solid-js/store';
import { Component } from 'solid-js';

type FilterState = {
  accountId: string;
  symbol: string;
  status: string;
};

export const Filters: Component<{ onFilterChange: (f: FilterState) => void }> = (props) => {
  const [filter, setFilter] = createStore<FilterState>({
    accountId: '',
    symbol: '',
    status: '',
  });

  const apply = () => props.onFilterChange(filter);

  const reset = () => {
    setFilter(() => ({ accountId: '', symbol: '', status: '' }));
    props.onFilterChange(filter);
  };

  return (
    <div class="filters">
      <input
        value={filter.accountId}
        onInput={(e) => setFilter('accountId', e.currentTarget.value)}
        placeholder="Account ID"
      />
      <button onClick={apply}>Apply</button>
      <button onClick={reset}>Reset</button>
    </div>
  );
};
```

---

## Context / Shared State

Shared state is provided via SolidJS Context. Class-based stores (like `PaginationState`) are a valid pattern in this codebase.

```tsx
// store/pagination-state.ts
import { createStore, Store, SetStoreFunction } from 'solid-js/store';

export class PaginationState {
  public readonly store: Store<{ pageNumber: number; pageSize: number }>;
  private readonly setStore: SetStoreFunction<{ pageNumber: number; pageSize: number }>;

  constructor() {
    [this.store, this.setStore] = createStore({ pageNumber: 1, pageSize: 10 });
  }

  public changePage = (page: number) => this.setStore('pageNumber', page);
}

// context/orders-context.tsx
import { createContext, useContext } from 'solid-js';
import { PaginationState } from '../store/pagination-state';

const OrdersContext = createContext<PaginationState>();
export const useOrdersContext = () => useContext(OrdersContext)!;
```

---

## Styling

- **SCSS**, not CSS Modules — import as `import styles from './Component.scss'` (string, used as style tag)
- Or import as plain SCSS and use BEM class names directly
- No hardcoded hex colors in component files — use SCSS variables or CSS custom properties
- Class names follow BEM: `order-form`, `order-form__field`, `order-form--sell`

```tsx
import styles from './OrderForm.scss';

export const OrderForm: Component<OrderFormProps> = (props) => (
  <div class="order-form">
    <style>{styles}</style>
    {/* ... */}
  </div>
);
```

---

## Event Handler Conventions for Trading Actions

```tsx
// Props naming convention for trading events
type TradingActionProps = {
  onBuy?: (request: PlaceOrderRequest) => void;
  onSell?: (request: PlaceOrderRequest) => void;
  onCancelOrder?: (orderId: string) => void;
  onAmendOrder?: (orderId: string, amendments: OrderAmendment) => void;
  onClosePosition?: (positionId: string, quantity?: number) => void;
  onSymbolSelect?: (symbol: string) => void;
};
```

---

## Module Structure (matches actual codebase layout)

```
frontend/ACAT/src/
├── modules/
│   └── <feature>/
│       ├── index.ts           → re-export entry
│       ├── components/        → feature-specific components
│       ├── actions/           → async data fetching functions
│       └── store/             → createStore-based state classes
├── components/                → shared structural components (Router, AppData)
├── contexts/                  → SolidJS contexts (api-context, store-root-context)
├── ui-kit/                    → reusable primitive components (Button, TextField, Select)
├── api/                       → axios API calls + type definitions
├── services/                  → business-logic helpers
└── utils/                     → pure utility functions
```

## Best Practices

- No default exports from components
- One component per file
- Access props via `props.xxx` — never destructure
- Use `Show`/`For` for reactive control flow, not `&&`/`map()`
- Trading-domain enums (OrderSide, OrderType, Status) imported from `api/types`, not redefined per component
- `class` not `className`; `classList` for conditionals
