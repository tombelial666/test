# Project Structure

This document describes the directory structure and organization of the mobile app codebase.

---

## High-Level Layout

```
/app.config.ts
/brand-config.js           # Brand configuration (JavaScript for Expo compatibility)
/babel.config.js
/jest.config.js
/tsconfig.json
/eslint.config.js
/tests/                    # all tests live here (see Testing Guide)

/app/                      # Expo Router: routes/layouts only
/assets/                   # Assets of the app. (e.g. brandA, brandB, default)

/src
  /features/               # Feature UI (no IO)
  /application/            # Use-cases (only when scenarios/coordination are needed)
  /domain/                 # Entities, Value Objects, Ports (interfaces)
  /infrastructure/         # HTTP (Axios), DTO, mappers, repositories (port impls)
  /composition/            # DI providers: Api, Query, Store, Theme/Toast/Overlay, Http, Brand
  /store/                  # Zustand store factory + slices/selectors
  /shared/                 # Design system, utils, theme, config, constants, types
```

---

## Import Boundaries

Strict import rules enforce clean architecture:

- **features**: may import `application` | `domain` | `shared` | `store` | other features' **query hooks**.
- **features** must not import `infrastructure`.
- **application**: imports only `domain`.
- **infrastructure**: implements `domain/ports/*`.
- **composition**: composes everything (the only place that wires infra/ports/store).
- **store**: is created via a factory and receives deps from composition.

---

## Path Aliases

Configured in `tsconfig.json`:

```json
{ "compilerOptions": { "baseUrl": ".", "paths": { "@/*": ["src/*"] } } }
```

---

## State Management

Two tools for different concerns:

| Data Type | Tool | Examples |
|-----------|------|----------|
| Server state | React Query | Positions, orders, accounts |
| App state | Zustand | Mobile settings, selected account, UI flags |

**React Query**: data from backend, cached, auto-refetched, invalidated.  
**Zustand**: global state needed across app, survives navigation, sync access.

See **[State Management](./state-management.md)** for patterns, slice structure, and usage.

---

## Detailed Tree (Full Examples)

```
assets/
  default/
  brandA/
  brandB/

app/
  _layout.tsx
  index.tsx
  (auth)/
    _layout.tsx
    sign-in.tsx
  (tabs)/
    _layout.tsx
    portfolio.tsx
    trades.tsx
    settings/
      index.tsx
      account.tsx

src/
  features/
    account/
      components/Avatar.tsx
      screens/AccountScreen.tsx
      hooks/
        queries.ts              # React Query hooks for account API
        useAccountForm.ts       # UI logic
      index.ts
    portfolio/
      components/PositionRow.tsx
      screens/PortfolioScreen.tsx
      hooks/
        queries.ts              # React Query hooks for portfolio API
        usePortfolio.ts
      index.ts
    trading/
      components/OrderForm.tsx
      screens/PlaceOrderScreen.tsx
      hooks/
        queries.ts              # React Query hooks for orders API
        usePlaceOrder.ts
      index.ts
    widgets/
      components/WidgetCard.tsx
      screens/WidgetsScreen.tsx
      hooks/
        queries.ts

  application/
    auth/
      restoreSession.ts        # session restoration use-case (bootstrap + restore logic)
      index.ts
    trading/
      placeOrder.ts            # orchestrates validation + port calls + cache invalidation
      cancelOrder.ts
    widgets/
      linkWidget.ts
    index.ts

  domain/
    entities/
      Position.ts
      Order.ts
      Account.ts
      common/Money.ts
    value-objects/
      MobileSettings.ts         # App configuration (Value Object with constructor parsing)
    ports/
      IPortfolioService.ts
      ITradingService.ts
      IAccountService.ts
      IOrderService.ts
      IMobileSettingsService.ts # App configuration service
    errors/DomainError.ts       # or use Result consistently (but pick one model)
    result/Result.ts
    index.ts

  infrastructure/
    http/
      core/
        TokenStore.ts          # in-memory token + SecureStore bootstrap
        httpClientFactory.ts   # createHttpClient (Axios + interceptors)
        httpClients.ts         # exports httpClientPrimary/Secondary singletons
    dto/
      PositionDTO.ts
      OrderDTO.ts
      AccountDTO.ts
      MobileSettingsDTO.ts     # App configuration DTO
    mappers/
      positionMapper.ts        # DTO → Domain transformer
      orderMapper.ts
      accountMapper.ts
      # Note: Value Objects (like MobileSettings) don't need mappers - they parse in constructor
    repositories/
      PortfolioRepository.ts    # implements IPortfolioService, uses HttpClient via DI
      TradingRepository.ts
      AccountRepository.ts
      OrderRepository.ts
      MobileSettingsRepository.ts # implements IMobileSettingsService
    cache/memoryCache.ts
    fakes/FakePortfolioService.ts
    index.ts

  composition/
    ApiProvider.tsx            # creates repositories with HttpClient DI, exposes via useApi()
    AppInitializationProvider.tsx # orchestrates startup tasks (session restore, settings)
    AuthProvider.tsx           # selects auth strategy, exposes via useAuthService()
    BrandProvider.tsx          # white-label brand configuration
    HttpProvider.tsx           # bootstraps TokenStore once
    LocalizationProvider.tsx   # initializes locale from AsyncStorage / device language
    QueryProvider.tsx          # React Query client
    ThemeProvider.tsx          # theme configuration
    ToastProvider.tsx          # toast notifications (ready for future use)
    ErrorBoundary.tsx
    index.ts

  store/
    createStore.ts             # Zustand store factory with slice composition
    slices/
      localization.slice.ts    # Current locale, setLocale, initializeLocale (persisted via AsyncStorage)
      settings.slice.ts        # Mobile settings (fetched once at startup)
      session.slice.ts         # Selected account, user preferences (persisted)
      ui.slice.ts              # Toasts/overlays/feature flags
    selectors/
      settings.selectors.ts    # useSettings, useSettingsLoading
      portfolio.selectors.ts
    index.ts

  shared/
    localization/
      i18n.ts                  # i18next configuration and initialization
      utils.ts                 # mapToSupportedLocale, isSupportedLocale, SUPPORTED_LOCALES
      index.ts
      locales/
        en/common.json         # English — source of truth
        es/common.json         # Spanish
        fr/common.json         # French
        ru/common.json         # Russian
        zh-CN/common.json      # Chinese (Simplified)
        zh-TW/common.json      # Chinese (Traditional)
    ui/
      buttons/Button.tsx
      forms/TextField.tsx
      feedback/Toast.tsx
      feedback/Overlay.tsx
      layout/Screen.tsx
      common/loaders/LoadingView.tsx # Reusable loading indicator
      icons/index.ts
    theme/
      colors.ts
      spacing.ts
      typography.ts
      index.ts
    utils/
      currency.ts
      date.ts
      number.ts
      zod.ts
    constants/
      app.ts
      trading.ts
    types/index.ts
    config/
      env.ts
      featureFlags.ts
    navigation/linking.ts
    index.ts
```

---

## Naming Conventions

- **Components/types**: PascalCase (e.g., `UserProfile`, `OrderType`)
- **Functions/variables**: camelCase (e.g., `placeOrder`, `userId`)
- **Files**: kebab-case or entity name (e.g., `place-order.ts`, `Order.ts`) - be consistent
- **Barrels**: `index.ts` at feature/layer roots for ergonomic imports
- **Query hooks**: `use<Entity>Query`, `use<Entity>sQuery`, `use<Action><Entity>Mutation`

---

## Adding a New Feature (Quick Checklist)

1. Create `features/<feature>/` with `components/`, `screens/`, `hooks/`, `index.ts`
2. Add `hooks/queries.ts` with React Query hooks and query keys
3. Add ports/entities/value-objects in `domain/*` (if needed)
4. Implement repository in `infrastructure/repositories/*` with HttpClient DI
5. Add DTO in `infrastructure/dto/*` and mapper in `infrastructure/mappers/*` (Entities only; Value Objects parse in constructor)
6. Register repository in `composition/ApiProvider.tsx`
7. If there's a scenario → add use-case in `application/<feature>/*`
8. Add route in `app/(tabs|stack)/*` that renders the feature screen
