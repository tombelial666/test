# HTTP Infrastructure

This document describes the HTTP client setup, authentication, interceptors, and repository integration patterns.

---

## Overview

HTTP infrastructure uses Axios with two singleton clients (`httpClientPrimary` and `httpClientSecondary`) created once with `baseURL` + immutable API key. A request interceptor injects Bearer tokens from an in-memory `TokenStore` (bootstrapped from SecureStore), and a response interceptor handles 401 → logout + redirect.

Repositories receive HTTP clients via **dependency injection** (constructor) and make HTTP calls directly — no intermediate API layer.

---

## Core Principles

- **Singletons**: `httpClientPrimary` and `httpClientSecondary` (no "Axios" in names)
- **Created once** with `baseURL` + immutable `apiKey`; key is stored inside the instance
- **Request interceptor** injects `Authorization: Bearer <token>` from in-memory `TokenStore`
- **Response interceptor** centralizes errors and handles 401 → clear token + redirect to sign-in (optionally 403)
- **Repositories use DI**: HTTP client is passed via constructor, no intermediate API layer
- **API versioning**: Handled at repository level via `BaseRepository`, not in HTTP clients

---

## HTTP Client Factory

```ts
// infrastructure/http/core/httpClientFactory.ts
import axios, { AxiosError, AxiosInstance, AxiosRequestConfig, AxiosRequestHeaders, InternalAxiosRequestConfig } from "axios";

export type HttpClient = AxiosInstance;

export type HttpClientOptions = {
  baseURL: string;
  apiKey: string;
  timeoutMs?: number;
  getToken?: () => string | null;
  onUnauthorized?: () => void;
  onForbidden?: () => void;
  refreshToken?: () => Promise<string | null>; // Optional function to refresh access token (Keycloak only)
};

export type RequestConfig = AxiosRequestConfig & { withAuth?: boolean };

export function createHttpClient(opts: HttpClientOptions): HttpClient {
  const headers: AxiosRequestHeaders = {
    "Content-Type": "application/json",
  } as AxiosRequestHeaders;
  
  // Only add Et-App-Key header if API key is provided
  if (opts.apiKey) {
    headers["Et-App-Key"] = opts.apiKey;
  }

  const client = axios.create({
    baseURL: opts.baseURL,
    timeout: opts.timeoutMs ?? 20000,
    headers,
  });

  // Request interceptor: inject Bearer token
  client.interceptors.request.use((config: InternalAxiosRequestConfig & RequestConfig) => {
    if (!config.headers) {
      config.headers = {} as AxiosRequestHeaders;
    }

    // Inject Bearer token by default (unless withAuth: false)
    // Use withAuth: false for public endpoints (login, register, etc.)
    if (config.withAuth !== false && opts.getToken) {
      const t = opts.getToken();
      if (t) {
        config.headers.Authorization = `Bearer ${t}`;
      }
    }

    return config;
  });

  // Response interceptor: handle auth errors and token refresh
  client.interceptors.response.use(
    (res) => res,
    async (err: AxiosError) => {
      const s = err.response?.status ?? 0;
      const requestConfig = err.config as InternalAxiosRequestConfig & RequestConfig;
      const requiresAuth = requestConfig?.withAuth !== false;

      // Handle 401 Unauthorized with automatic token refresh (Keycloak only)
      if (s === 401 && requiresAuth && !requestConfig._retry && opts.refreshToken) {
        requestConfig._retry = true;
        try {
          const newToken = await opts.refreshToken();
          if (newToken && requestConfig.headers) {
            requestConfig.headers.Authorization = `Bearer ${newToken}`;
            return client(requestConfig); // Retry with new token
          } else {
            opts.onUnauthorized?.();
          }
        } catch {
          opts.onUnauthorized?.();
          return Promise.reject(err);
        }
      }

      // Trigger auth handlers for authenticated requests
      // By default all requests are authenticated unless withAuth: false
      if (s === 401 && requiresAuth) {
        opts.onUnauthorized?.();
      }
      if (s === 403 && requiresAuth) {
        opts.onForbidden?.();
      }
      return Promise.reject(err);
    }
  );

  return client;
}
```

---

## Token Management

### TokenStore (In-Memory)

The `TokenStore` keeps the authentication token in memory and synchronizes with SecureStore only during bootstrap, login, and logout.

```ts
// infrastructure/http/core/TokenStore.ts
import * as SecureStore from "expo-secure-store";

class TokenStore {
  private token: string | null = null;

  async bootstrap() {
    this.token = await SecureStore.getItemAsync("authToken");
  }

  setToken(token: string) {
    this.token = token;
    SecureStore.setItemAsync("authToken", token);
  }

  clearToken() {
    this.token = null;
    SecureStore.deleteItemAsync("authToken");
  }

  getToken(): string | null {
    return this.token;
  }
}

export const tokenStore = new TokenStore();
```

### Bootstrap in HttpProvider

```tsx
// composition/HttpProvider.tsx
import { useEffect, useState } from "react";
import { tokenStore } from "@/infrastructure/http/core/TokenStore";

export function HttpProvider({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    tokenStore.bootstrap().then(() => setReady(true));
  }, []);

  if (!ready) return null; // or loading spinner

  return <>{children}</>;
}
```

---

## Creating HTTP Clients

```ts
// infrastructure/http/core/httpClients.ts
import { createHttpClient } from "./httpClientFactory";
import { tokenStore } from "./TokenStore";
import { refreshAccessToken } from "./tokenRefresh";
import { router } from "expo-router";

// Helper to get required environment variable with validation
function requireEnv(key: string): string {
  const value = process.env[key];
  if (!value) {
    throw new Error(
      `Missing required environment variable: ${key}. ` +
      `Please set it in your .env file or environment configuration.`
    );
  }
  return value;
}

// Primary API client
export const httpClientPrimary = createHttpClient({
  baseURL: requireEnv("EXPO_PUBLIC_PRIMARY_API_URL"),
  apiKey: requireEnv("EXPO_PUBLIC_PRIMARY_API_KEY"),
  getToken: () => tokenStore.getToken(),
  onUnauthorized: () => {
    tokenStore.clearToken();
    router.replace("/sign-in");
  },
  refreshToken: refreshAccessToken, // Automatic token refresh for Keycloak
});

// Secondary API client
export const httpClientSecondary = createHttpClient({
  baseURL: requireEnv("EXPO_PUBLIC_SECONDARY_API_URL"),
  apiKey: requireEnv("EXPO_PUBLIC_SECONDARY_API_KEY"),
  getToken: () => tokenStore.getToken(),
  onUnauthorized: () => {
    tokenStore.clearToken();
    router.replace("/sign-in");
  },
  refreshToken: refreshAccessToken, // Automatic token refresh for Keycloak
});
```

---

## Repositories with Dependency Injection

Repositories implement domain ports and receive HTTP clients via constructor. HTTP calls are made directly in repository methods — no intermediate API layer.

### Domain Port (Interface)

```ts
// domain/ports/IPortfolioService.ts
import type { Position } from "@/domain/entities/Position";

export interface IPortfolioService {
  getPositions(): Promise<Position[]>;
  getPosition(id: string): Promise<Position>;
}
```

### Repository Implementation

```ts
// infrastructure/repositories/PortfolioRepository.ts
import type { HttpClient } from "@/infrastructure/http/core/httpClientFactory";
import type { IPortfolioService } from "@/domain/ports/IPortfolioService";
import type { Position } from "@/domain/entities/Position";
import type { PositionDTO, PositionListDTO } from "@/infrastructure/dto/PositionDTO";
import { positionMapper } from "@/infrastructure/mappers/positionMapper";

export class PortfolioRepository implements IPortfolioService {
  constructor(private readonly client: HttpClient) {}

  async getPositions(): Promise<Position[]> {
    const { data } = await this.client.get<PositionListDTO>("/portfolio/positions");
    return data.positions.map(positionMapper.toDomain);
  }

  async getPosition(id: string): Promise<Position> {
    const { data } = await this.client.get<PositionDTO>(`/portfolio/positions/${id}`);
    return positionMapper.toDomain(data);
  }
}
```

### Repository with CRUD Operations

```ts
// infrastructure/repositories/AccountRepository.ts
import type { HttpClient } from "@/infrastructure/http/core/httpClientFactory";
import type { IAccountService, CreateAccountInput, UpdateAccountInput } from "@/domain/ports/IAccountService";
import type { Account } from "@/domain/entities/Account";
import type { AccountDTO, AccountListDTO } from "@/infrastructure/dto/AccountDTO";
import { accountMapper } from "@/infrastructure/mappers/accountMapper";

export class AccountRepository implements IAccountService {
  constructor(private readonly client: HttpClient) {}

  async getAccounts(filters?: Record<string, unknown>): Promise<Account[]> {
    const { data } = await this.client.get<AccountListDTO>("/accounts", { params: filters });
    return data.accounts.map(accountMapper.toDomain);
  }

  async getAccount(id: string): Promise<Account> {
    const { data } = await this.client.get<AccountDTO>(`/accounts/${id}`);
    return accountMapper.toDomain(data);
  }

  async createAccount(input: CreateAccountInput): Promise<Account> {
    const payload = accountMapper.toCreateDTO(input);
    const { data } = await this.client.post<AccountDTO>("/accounts", payload);
    return accountMapper.toDomain(data);
  }

  async updateAccount(id: string, input: UpdateAccountInput): Promise<Account> {
    const payload = accountMapper.toUpdateDTO(input);
    const { data } = await this.client.put<AccountDTO>(`/accounts/${id}`, payload);
    return accountMapper.toDomain(data);
  }

  async deleteAccount(id: string): Promise<void> {
    await this.client.delete(`/accounts/${id}`);
  }
}
```

---

## Wiring in ApiProvider

Repositories are instantiated in `ApiProvider` with HTTP clients passed via constructor.

**Note**: Authentication services are managed separately in `AuthProvider`.

```tsx
// composition/ApiProvider.tsx (example pattern)
import { createContext, useContext, useMemo } from "react";
import type { IPortfolioService } from "@/domain/ports/IPortfolioService";
import type { IAccountService } from "@/domain/ports/IAccountService";
import type { IOrderService } from "@/domain/ports/IOrderService";
import { PortfolioRepository } from "@/infrastructure/repositories/PortfolioRepository";
import { AccountRepository } from "@/infrastructure/repositories/AccountRepository";
import { OrderRepository } from "@/infrastructure/repositories/OrderRepository";
import { httpClientPrimary, httpClientSecondary } from "@/infrastructure/http/core/httpClients";

interface ApiContextValue {
  portfolioService: IPortfolioService;
  accountService: IAccountService;
  orderService: IOrderService;
}

const ApiContext = createContext<ApiContextValue | null>(null);

export function ApiProvider({ children }: { children: React.ReactNode }) {
  const services = useMemo<ApiContextValue>(() => ({
    portfolioService: new PortfolioRepository(httpClientPrimary),
    accountService: new AccountRepository(httpClientPrimary),
    orderService: new OrderRepository(httpClientPrimary),
    // For secondary API:
    // widgetService: new WidgetRepository(httpClientSecondary),
  }), []);

  return <ApiContext.Provider value={services}>{children}</ApiContext.Provider>;
}

export function useApi(): ApiContextValue {
  const ctx = useContext(ApiContext);
  if (!ctx) throw new Error("useApi must be used within ApiProvider");
  return ctx;
}
```

---

## API Versioning

API versioning is handled at the **repository level**, not by the HTTP client. This is because:

- Primary API uses versioned endpoints (`/v1/...`, `/v2/...`)
- Secondary API does NOT use versioning
- Version is a domain/repository concern, not HTTP transport

Repositories extend `BaseRepository` which provides `apiVersion` property and `versionedPath()` helper.

**See**: [ADR-0001: API Versioning Strategy](./adr/0001-api-versioning-strategy.md) for full implementation details and rationale.

---

## Best Practices

1. **Never expose Axios types** outside infrastructure layer
2. **Use DTO → Domain mapping** for all API responses
3. **No intermediate API layer** — HTTP calls directly in repositories
4. **DI via constructor** — repositories receive HTTP client, enabling testability
5. **Handle errors centrally** in interceptors
6. **Token management** only at bootstrap/login/logout (SecureStore), otherwise in-memory
7. **API keys immutable** — set once during client creation
8. **API versioning** — handled at repository level via `BaseRepository`

---

## Consumption

Repositories are consumed in two ways:

1. **React Query hooks** (default) — for server state with caching/refetching:
   ```ts
   // features/portfolio/hooks/queries.ts
   const { portfolioService } = useApi();
   return useQuery({ queryFn: () => portfolioService.getPositions() });
   ```

2. **Composition layer** — for bootstrap data loaded into Zustand:
   ```ts
   // composition/AppInitializationProvider.tsx
   const { mobileSettingsService } = useApi();
   fetchSettings(mobileSettingsService); // one-time init
   ```

See **[State Management](./state-management.md)** for when to use each approach.

---

## Environment Configuration

HTTP clients require specific environment variables to function. See [Environment Variables](./environment-variables.md) for:
- API URLs and keys configuration
- Environment-specific settings
- Validation and troubleshooting
