# ADR-0009: Localization Strategy

**Status**: Accepted
**Date**: 2026-02-12

## Context

The mobile app needs internationalization (i18n) support for 6 languages: English (en - default), Spanish (es), Chinese Traditional (zh-TW), Chinese Simplified (zh-CN), Russian (ru), and French (fr). The system must auto-detect device language on first launch, allow manual language selection, persist the choice between sessions, and apply changes immediately without app restart.

**Key constraints**:
- Must be officially supported by Expo (no eject or custom native modules)
- Must not impact build time or require complex workarounds
- Should support future RTL languages (Arabic, Hebrew) without major refactoring
- OTA translation updates are nice-to-have, but not at the cost of stability/complexity

## Use Cases

- **UC1**: First-time user opens app with device language set to Spanish → app displays in Spanish
- **UC2**: User with device language set to Japanese opens app → app falls back to English
- **UC3**: User manually switches language from English to Russian in Profile → UI updates immediately
- **UC4**: User closes and reopens app → previously selected language is restored
- **UC5**: User switches between zh-TW and zh-CN → correct translations are displayed
- **UC6**: Developer adds new feature with hardcoded text `<Text>Submit</Text>` → pre-commit validation **blocks commit** (critical error)
- **UC7**: Developer adds translation key in English but forgets Spanish → validation script **warns** but allows commit (fallback to English works)
- **UC8**: App requests missing translation key at runtime → fallback to English value seamlessly (no crash)
- **UC9**: CI/CD pipeline runs in strict mode → deployment **blocked** if translations incomplete (ensures production quality)

## Options Considered

### Option 1: react-i18next + expo-localization

The industry-standard i18n solution for React/React Native with official Expo integration.

**Pros**:
- Most popular solution with extensive documentation and community support
- Hooks-based API (`useTranslation`) aligns with React patterns
- expo-localization provides native device language detection (no custom code needed)
- Supports namespace-based translation organization (feature-based structure)
- Lazy loading support (if needed for future scaling)
- Pluralization, interpolation, context, and formatting built-in
- Language switching without app restart (re-render on locale change)
- Bundle size: ~22 kB (i18next 15.1 kB + react-i18next 7.1 kB) — acceptable for 6 languages
- Compatible with Expo SDK 54 without eject
- TypeScript support with typed translation keys

**Cons**:
- Slightly larger bundle than LinguiJS
- Requires runtime JSON translation files (no compile-time optimization)
- Manual synchronization of translation keys across language files

### Option 2: react-intl (FormatJS)

Standards-compliant i18n library following ECMA-402 specifications.

**Pros**:
- Adheres to official ECMA-402 standards (future-proof)
- Strong support for number, date, and currency formatting
- ICU message format (industry standard)
- Maintained by FormatJS team (stable long-term)

**Cons**:
- Steeper learning curve (ICU message syntax)
- Heavier bundle size than react-i18next
- Less flexible than i18next for custom workflows
- Fewer React Native-specific examples in documentation
- Component-based API (`<FormattedMessage>`) less ergonomic than hooks

### Option 3: LinguiJS

Modern i18n library with compile-time optimization and macro-based syntax.

**Pros**:
- Smallest bundle size (compile-time optimization strips unused translations)
- Macro-based syntax (`t` macro) feels native to JavaScript
- Automatic message extraction from code
- ICU message format support
- Good TypeScript support

**Cons**:
- Requires Intl polyfill for some React Native/OS versions (added complexity)
- Smaller community than react-i18next (fewer Stack Overflow answers)
- Macro-based approach requires Babel configuration
- Less documentation for Expo-specific integration
- Compile-time approach adds build step complexity
- Auto-extraction may conflict with existing project structure

### Option 4: Custom Solution with expo-localization only

Build custom translation system using expo-localization for language detection and manual JSON loading.

**Pros**:
- Full control over implementation
- Minimal dependencies
- No external library bundle size

**Cons**:
- Reinventing the wheel (pluralization, interpolation, context, formatting)
- No TypeScript type safety for translation keys
- Maintenance burden for features like nested translations, fallbacks, namespaces
- Not a good use of development time
- Risk of bugs in custom logic

## Translation Delivery Strategy

Before choosing the i18n library, we need to decide how translations are delivered to the app:

### Bundled Translations (Chosen)

Translations are included in the app bundle at build time.

**Pros**:
- Zero runtime latency (translations available immediately)
- Works offline (no network dependency)
- Simple implementation (no CDN/API infrastructure)
- Reliable (no download failures, no cache invalidation issues)
- Expo OTA updates support updating translations without new store release

**Cons**:
- Slightly larger initial bundle size (~5-10 kB per language)
- Must deploy new OTA update to change translations

### CDN-based Remote Translations (Rejected)

Fetch translations from CDN at runtime.

**Pros**:
- Can update translations without app update/OTA
- Smaller initial bundle size

**Cons**:
- **Infrastructure complexity**: Requires CDN setup, download logic, cache invalidation, versioning
- **Offline risk**: App may not work without network on first launch
- **Latency**: Download time on first launch or after clearing cache
- **Fallback complexity**: Need bundled fallback anyway for offline scenarios
- **Not officially supported by Expo**: Custom workarounds needed
- **Overkill for 6 languages**: ~30-60 kB total for all translations is acceptable in bundle

**Decision**: Use **bundled translations** for simplicity and reliability. Expo OTA updates already allow updating translations without App Store review, which is sufficient for our needs.

---

## i18n Library Choice

We chose **Option 1: react-i18next + expo-localization** because:

1. **Production-ready with Expo**: Official Expo support, no eject needed, works seamlessly with Expo SDK 54
2. **Developer experience**: Hooks-based API (`useTranslation`) aligns with React Query/Zustand patterns already used in the project
3. **Mature ecosystem**: Extensive documentation, large community, proven in production at scale
4. **Bundle size acceptable**: 22 kB for full i18n framework is reasonable for 6 languages (vs manual implementation risk)
5. **Future-proof**: Supports RTL, lazy loading, namespaces, and advanced features when needed
6. **expo-localization integration**: Handles device language detection out-of-the-box with `getLocales()`

LinguiJS was a close second for bundle size, but the added complexity (Babel macros, Intl polyfills, compile-time extraction) doesn't justify the ~10 kB savings for a 6-language app. react-intl has a steeper learning curve without clear advantages for our use case.

See [docs/localization.md](../localization.md) for file structure, usage guide, validation scripts, and CI/CD integration.

## Consequences

### What Becomes Easier

- Adding new languages (create new JSON folder, add to config)
- Type-safe translations (can add TypeScript types for translation keys)
- Feature-based translation organization (namespaces per feature)
- Testing (mock `useTranslation` hook in tests)
- Hot reloading translations in development
- Language switching without app restart
- Device language auto-detection (expo-localization handles it)
- **Automated validation** — pre-commit hooks catch hardcoded text and missing translation keys before code review
- **Quality assurance** — validation scripts ensure all 6 languages have consistent keys

### What Becomes Harder

- ~~Translation key synchronization across files~~ — **SOLVED**: Validation scripts detect missing keys (warns in dev, blocks in CI strict mode)
- ~~Hardcoded text~~ — **PREVENTED**: Pre-commit hook blocks commits with hardcoded text
- Bundle includes all translations upfront (no lazy loading initially, but can be added later)
- ~~Developers must remember to add translations~~ — **MITIGATED**: Warnings remind to add missing keys; fallback to English works at runtime
- **Translation updates require OTA deploy** — Can't update translations instantly without deploy (but Expo OTA is fast enough for our needs)

## References

- [Expo Localization Docs](https://docs.expo.dev/versions/latest/sdk/localization/)
- [react-i18next Documentation](https://react.i18next.com/)
- [i18next Comparison to Others](https://www.i18next.com/overview/comparison-to-others)
- [React Native i18n Comparison](https://simplelocalize.io/blog/posts/the-most-popular-react-localization-libraries/)
- [Expo Multi-Language Guide](https://launchtoday.dev/blog/expo-multi-language-support)

## Future Considerations

1. **RTL Support**: When adding Arabic/Hebrew, use `I18nManager.forceRTL()` from React Native
2. **Lazy Loading**: If bundle size becomes concern, implement `i18next-http-backend` for on-demand loading
3. **Translation Management**: Consider Crowdin/Lokalise/Phrase integration for non-technical translators
4. **TypeScript Types**: Generate types from translation JSON for compile-time key validation using `i18next-typescript`
5. **Pluralization**: Use ICU format in JSON for complex plural rules (e.g., Russian has 3 plural forms)
6. **IDE Integration**: VSCode extension for i18next shows translations on hover
