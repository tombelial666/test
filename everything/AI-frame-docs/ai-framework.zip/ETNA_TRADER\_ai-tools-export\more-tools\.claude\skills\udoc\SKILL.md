---
name: udoc
description: Update documentation and generate changelog from task implementation
argument-hint: [task-path]
disable-model-invocation: true
---

# Update Documentation (UDOC)

## PRIMARY OBJECTIVE
Generate documentation updates and changelog entries from a completed task implementation.

## CONTEXT
Use when:
- Task implementation is complete (before or after PR/merge)
- Documentation needs updating to reflect code changes
- Changelog entry needed for the task

## WORKFLOW

### STEP 1: Resolve Task Path

1. Parse `$ARGUMENTS` for a task directory path
2. If not provided — **Ask**: "Which task to update docs for? Provide task directory path (e.g., `tasks/task-2026-02-27-feature-name/`)."
3. Validate: find `tech-decomposition-*.md` inside the task directory
4. If not found — error with available task directories

### STEP 2: Update Documentation (docs-updater agent)

Call **docs-updater** agent:
```
Task: "Update documentation based on task implementation"
Prompt: "Review the task document at [TASK_DOCUMENT_PATH] and update all relevant MobileLiteApp documentation files based on the implemented changes. Check docs/project-structure.md, docs/adr/, docs/testing-guide.md, docs/design-tokens.md, and CLAUDE.md for needed updates. Return a summary of what documentation was updated."
```

Capture the summary of documentation changes.

### STEP 3: Generate Changelog (changelog-generator agent)

Call **changelog-generator** agent:
```
Task: "Generate changelog entry for completed task"
Prompt: "Generate a changelog entry based on the task document at [TASK_DOCUMENT_PATH] and documentation updates: [DOCS_UPDATES_SUMMARY]. Include the main feature implementation and any documentation changes. Use MobileLiteApp file path conventions (src/features/, tests/unit/, tests/integration/)."
```

Capture the changelog entry.

### STEP 4: Commit (Optional)

1. Show user what changed:
   - `git diff --stat` for modified files
   - Brief summary from both agents
2. **Ask**: "Commit these documentation and changelog updates?"
3. If approved:
   ```bash
   git add docs/ CLAUDE.md AGENTS.md
   git commit -m "docs: update documentation and changelog for [feature]"
   ```
4. If on a feature branch, ask whether to push

### STEP 5: Summary

Report to user:
```
Documentation updated!

**Docs**: [list of updated files]
**Changelog**: docs/changelogs/YYYY-MM-DD/changelog.md
**Committed**: Yes/No
```

## ERROR HANDLING

- **Task not found**: List available task directories under `tasks/`
- **No changes detected**: Inform user, suggest checking if docs are already up to date
- **Agent fails**: Report which agent failed, suggest running manually

## SUCCESS CRITERIA

- [ ] Task document found and analyzed
- [ ] Documentation updated for affected files
- [ ] Changelog entry created in `docs/changelogs/YYYY-MM-DD/`
- [ ] User informed of all changes
- [ ] Changes committed only with user approval
