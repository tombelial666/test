/**
 * Validate Translation Keys Script
 *
 * Compares all locale files against English (source of truth).
 * Ensures all languages have the same translation keys.
 *
 * Usage:
 *   npx ts-node scripts/validate-translation-keys.ts
 *   I18N_STRICT_MODE=true npx ts-node scripts/validate-translation-keys.ts
 *
 * Exit codes:
 *   0 - All keys match (or warnings only in non-strict mode)
 *   1 - Missing/extra keys found in strict mode
 *
 * STRICT_MODE (I18N_STRICT_MODE=true):
 *   - Missing keys = ERROR → exit 1 (blocks CI/CD deployment)
 *
 * Non-strict mode (default):
 *   - Missing keys = WARNING → exit 0 (allows commit with warning)
 */

import * as fs from "fs";
import * as path from "path";

const STRICT_MODE = process.env.I18N_STRICT_MODE === "true";
const LOCALES_DIR = path.join(
  process.cwd(),
  "src",
  "shared",
  "localization",
  "locales"
);
const SOURCE_LOCALE = "en"; // English is the source of truth

/**
 * Recursively flattens a nested object to dot-notation keys
 * Example: { a: { b: "value" } } → { "a.b": "value" }
 */
function flattenKeys(
  obj: Record<string, unknown>,
  prefix = ""
): Record<string, string> {
  const result: Record<string, string> = {};

  for (const [key, value] of Object.entries(obj)) {
    const fullKey = prefix ? `${prefix}.${key}` : key;

    if (typeof value === "object" && value !== null && !Array.isArray(value)) {
      Object.assign(
        result,
        flattenKeys(value as Record<string, unknown>, fullKey)
      );
    } else {
      result[fullKey] = String(value);
    }
  }

  return result;
}

/**
 * Loads all JSON files from a locale directory and flattens keys
 */
function loadLocaleKeys(localePath: string): Set<string> {
  const keys = new Set<string>();

  if (!fs.existsSync(localePath)) return keys;

  const files = fs.readdirSync(localePath).filter((f) => f.endsWith(".json"));

  for (const file of files) {
    const filePath = path.join(localePath, file);
    const content = JSON.parse(fs.readFileSync(filePath, "utf8"));
    const namespace = path.basename(file, ".json");
    const flattened = flattenKeys(content);

    for (const key of Object.keys(flattened)) {
      keys.add(`${namespace}.${key}`);
    }
  }

  return keys;
}

interface ValidationResult {
  locale: string;
  missingKeys: string[];
  extraKeys: string[];
}

function validateLocale(
  locale: string,
  englishKeys: Set<string>
): ValidationResult {
  const localePath = path.join(LOCALES_DIR, locale);
  const localeKeys = loadLocaleKeys(localePath);

  const missingKeys = [...englishKeys].filter((k) => !localeKeys.has(k));
  const extraKeys = [...localeKeys].filter((k) => !englishKeys.has(k));

  return {
    locale,
    missingKeys,
    extraKeys 
  };
}

function main() {
  const mode = STRICT_MODE ? "STRICT" : "WARNING";
  console.log(`\n🔍 Validating translation keys [${mode} mode]\n`);

  if (!fs.existsSync(LOCALES_DIR)) {
    console.error(`❌ Locales directory not found: ${LOCALES_DIR}`);
    process.exit(1);
  }

  // Load English keys (source of truth)
  const englishPath = path.join(LOCALES_DIR, SOURCE_LOCALE);
  const englishKeys = loadLocaleKeys(englishPath);

  console.log(
    `📖 Source of truth: ${SOURCE_LOCALE} (${englishKeys.size} keys)\n`
  );

  // Get all locales except English
  const locales = fs
    .readdirSync(LOCALES_DIR, { withFileTypes: true })
    .filter((d) => d.isDirectory() && d.name !== SOURCE_LOCALE)
    .map((d) => d.name);

  let hasErrors = false;

  for (const locale of locales) {
    const result = validateLocale(locale, englishKeys);

    if (result.missingKeys.length === 0 && result.extraKeys.length === 0) {
      console.log(`  ✅ ${locale}: All ${englishKeys.size} keys present`);
      continue;
    }

    const severity = STRICT_MODE ? "❌ ERROR" : "⚠️  WARNING";

    if (result.missingKeys.length > 0) {
      console.log(`  ${severity} ${locale}: Missing ${result.missingKeys.length} key(s):`);
      result.missingKeys.forEach((key) => console.log(`     - ${key}`));

      if (STRICT_MODE) {
        hasErrors = true;
      }
    }

    if (result.extraKeys.length > 0) {
      console.log(`  ⚠️  WARNING ${locale}: Extra ${result.extraKeys.length} key(s) not in English:`);
      result.extraKeys.forEach((key) => console.log(`     + ${key}`));
    }
  }

  console.log();

  if (hasErrors) {
    console.error(
      "❌ Translation key validation FAILED (strict mode)\n"
    );
    console.error(
      "   Add missing keys to all locale files to proceed.\n"
    );
    process.exit(1);
  }

  if (STRICT_MODE) {
    console.log("✅ All translation keys validated successfully!\n");
  } else {
    console.log(
      "✅ Translation key validation complete (warnings above are non-blocking)\n"
    );
    console.log(
      "   Run with I18N_STRICT_MODE=true to block on missing keys.\n"
    );
  }

  process.exit(0);
}

main();
