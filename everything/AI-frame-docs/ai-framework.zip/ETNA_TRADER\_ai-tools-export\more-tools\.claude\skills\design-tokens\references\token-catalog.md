# Token Catalog

Complete list of available design tokens for the Mobile Lite App.

Access via `const colors = useThemeColors()` then use the path below.

---

## 1. Core Tokens (Most Used)

### Text

| Token | Description |
|-------|-------------|
| `colors.text.base` | Primary text |
| `colors.text.secondary` | Secondary/muted text |
| `colors.text.tertiary` | Tertiary text |
| `colors.text.disabled` | Disabled text |

### Background

| Token | Description |
|-------|-------------|
| `colors.background.base` | Primary background |
| `colors.background.secondary` | Secondary background (cards, surfaces) |
| `colors.background.tertiary` | Tertiary background |

### Icon

| Token | Description |
|-------|-------------|
| `colors.icon.base` | Primary icon |
| `colors.icon.secondary` | Inactive/secondary icon |
| `colors.icon.disabled` | Disabled icon |

### Border

| Token | Description |
|-------|-------------|
| `colors.border.base` | Primary border/divider |
| `colors.border.secondary` | Secondary border |
| `colors.border.focus` | Focus state border |

---

## 2. Sentiment Tokens (use `?.` optional chaining)

### Brand

| Token | Description |
|-------|-------------|
| `colors.text.brand?.base` | Brand text color |
| `colors.background.brand?.base` | Brand background (primary buttons) |
| `colors.icon.brand?.base` | Brand icon (active tab) |
| `colors.text.onbrand?.base` | Text placed ON brand background |

### Success

| Token | Description |
|-------|-------------|
| `colors.text.success?.base` | Success text |
| `colors.background.success?.base` | Success background |
| `colors.text.onsuccess?.base` | Text on success background |

### Danger

| Token | Description |
|-------|-------------|
| `colors.text.danger?.base` | Danger/error text |
| `colors.background.danger?.base` | Danger background (destructive buttons) |
| `colors.text.ondanger?.base` | Text on danger background |

### Warning

| Token | Description |
|-------|-------------|
| `colors.text.warning?.base` | Warning text |
| `colors.background.warning?.base` | Warning background |

### Info

| Token | Description |
|-------|-------------|
| `colors.text.info?.base` | Info text |
| `colors.background.info?.base` | Info background |

---

## 3. Component Tokens

### Links

| Token | Description |
|-------|-------------|
| `colors.link.text.base` | Default link color |
| `colors.link.text.hover` | Hover state |
| `colors.link.text.active` | Active/pressed state |
| `colors.link.text.visited` | Visited link |

### Form Fields

| Token | Description |
|-------|-------------|
| `colors.field.background.base` | Field background |
| `colors.field.background.disabled` | Disabled field background |
| `colors.field.border.base` | Default border |
| `colors.field.border.focus` | Focus border |
| `colors.field.border.error` | Error border |
| `colors.field.text.base` | Field text |
| `colors.field.text.placeholder` | Placeholder text |

### Controls (Checkbox / Radio / Toggle)

| Token | Description |
|-------|-------------|
| `colors.control.background.base` | Unchecked background |
| `colors.control.background.checked` | Checked background |
| `colors.control.border.base` | Unchecked border |
| `colors.control.border.checked` | Checked border |
| `colors.control.icon.checked` | Check mark icon |

### Tooltips

| Token | Description |
|-------|-------------|
| `colors.tooltip.background.base` | Tooltip background |
| `colors.tooltip.text.base` | Tooltip text |

---

## 4. Compound Component Tokens

### Cards

| Token | Description |
|-------|-------------|
| `colors.card.background.base` | Card background |
| `colors.card.background.hover` | Card hover state |
| `colors.card.background.selected` | Card selected state |
| `colors.card.border.base` | Card border |

### Tables

| Token | Description |
|-------|-------------|
| `colors.table.background.base` | Table background |
| `colors.table.background.header` | Header row background |
| `colors.table.background.row` | Table row background |
| `colors.table.background.rowHover` | Hovered row background |
| `colors.table.text.header` | Header text |
| `colors.table.text.cell` | Cell text |

### Left Navigation

| Token | Description |
|-------|-------------|
| `colors.leftnav.background.base` | Left nav background |
| `colors.leftnav.text.base` | Nav item text |
| `colors.leftnav.text.active` | Active nav item text |
| `colors.leftnav.icon.base` | Nav icon |
| `colors.leftnav.icon.active` | Active nav icon |

### Top Navigation

| Token | Description |
|-------|-------------|
| `colors.topnav.background.base` | Top nav background |
| `colors.topnav.text.base` | Top nav text |
| `colors.topnav.icon.base` | Top nav icons |

---

## 5. Location-Specific Tokens

### Login Screen

| Token | Description |
|-------|-------------|
| `colors.login.background.base` | Login screen background |
| `colors.login.text.base` | Login screen text |

---

## TypeScript Autocomplete

All tokens are fully typed. Use `Ctrl+Space` after `colors.` to discover available paths.
Trust the type system — if TypeScript accepts the path without `?.`, the token is always present.
If TypeScript requires `?.`, use optional chaining (sentiment tokens are optional by design).
