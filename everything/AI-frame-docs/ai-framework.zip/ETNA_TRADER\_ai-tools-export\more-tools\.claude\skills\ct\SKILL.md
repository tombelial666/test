---
name: ct
description: Create technical task documentation for developer implementation. Use when asked to 'create task', 'technical decomposition', 'plan implementation', 'task documentation', or 'decompose feature'. NOT for feature discovery (use /nf), NOT for implementation (use /si), NOT for brainstorming.
argument-hint: [feature-name]
allowed-tools: Task, Skill, AskUserQuestion, Read, Glob, Edit, Write, Grep, Bash
---

# Create Task Command

## PRIMARY OBJECTIVE
Create implementation-ready technical documentation for developer implementation of a MobileLiteApp feature. Thoroughly understand the user's idea, review the codebase with Explore sub-agent and all necessary related documents. Adopt a TDD-first workflow where the test plan is authored first and guides the technical decomposition. Exclude any time estimates. Ask clarifying questions when requirements are ambiguous.

## Control Gates

### GATE 0: Context Gathering & Requirements Understanding
**Complete BEFORE technical decomposition:**

**STEP 1: Check for pre-work documentation**

Look for existing documentation:
- `tasks/task-<date>-[feature-name]/discovery-[feature-name].md` (Feature discovery from /nf)
- `docs/adr/` for relevant Architecture Decision Records

**STEP 2: Gather context**

**IF pre-work documentation exists:**
- Read all available documents
- Use Explore sub-agent to understand affected codebase areas
- Confirm readiness with user

**IF NO pre-work documentation:**
- Ask user to describe the task/feature
- Ask clarifying questions about objective, acceptance criteria, affected features
- Use Explore sub-agent to understand affected codebase
- Summarize understanding and confirm with user

**Explore sub-agent focus areas:**
- Feature folder: `src/features/<feature>/`
- Domain: `src/domain/`
- Infrastructure: `src/infrastructure/repositories/`
- Existing tests: `tests/unit/<feature>/`, `tests/integration/<feature>/`
- Related docs: `docs/` (project-structure, testing-guide, design-tokens)

---

### GATE 0.7: UI Planning Agent (CONDITIONAL)
**Complete AFTER context gathering, BEFORE technical decomposition:**

**Trigger:** IF task is UI-heavy (screens, components, styling, animations, design tokens mapping)

| Signal | Use agent? |
|--------|-----------|
| Implement screen from design | ✅ YES |
| Create UI components with styling | ✅ YES |
| Design tokens mapping tasks | ✅ YES |
| HTTP provider / interceptor setup | ❌ NO |
| Zustand store implementation | ❌ NO |
| Navigation structure setup | ❌ NO |
| Backend / API changes only | ❌ NO |

**IF UI-heavy task:** Invoke `mobile-ui-planning-agent`:

```
Analyze UI requirements for [feature-name].

Feature name: [feature-name]
Task directory: [absolute path to task folder]

Available pre-work (check and use if exists):
- discovery-[feature-name].md (feature discovery)

Read skills: .claude/skills/design-tokens/SKILL.md and .claude/skills/react-native-expo/SKILL.md
Check existing components in src/shared/ui/ and src/features/

Output: ui-planning-analysis-[feature-name].md in task directory (consultative reference)
```

---

### GATE 1: Technical Decomposition & Test Plan Creation
**Complete AFTER context gathering:**

**FILE**: Create `tasks/task-<date>-[kebab-case]/tech-decomposition-[feature-name].md`

**TEMPLATE**: Use `docs/product-docs/templates/technical-decomposition-template.md`

Create technical implementation plan with **TEST PLAN FIRST** (TDD approach):

**MobileLiteApp-specific requirements in every plan:**
- [ ] Test file locations specified: `tests/unit/` or `tests/integration/` mirroring `src/` structure
- [ ] Test commands specified: `npm test -- --testPathPattern="<pattern>"`
- [ ] No hardcoded colors (use `useThemeColors()`)
- [ ] No hardcoded strings (use `t("key")`)
- [ ] Layer boundaries respected (features don't import infrastructure)
- [ ] React Query hooks location: `src/features/<feature>/hooks/queries.ts`
- [ ] File paths use `@/` alias
- [ ] Named exports only for components

**If the plan touches UI/screens:**
- Add a "**Skill Compliance**" section listing which design-tokens and react-native-expo rules apply

**AUTOMATIC PLAN REVIEW:** After creating technical decomposition, automatically invoke agents:

- `plan-reviewer`
- `senior-architecture-reviewer`

**ITERATIVE FEEDBACK LOOP:** When plan-reviewer or senior-architecture-reviewer requires revisions:
1. Address feedback by updating technical decomposition OR ask user for clarification
2. Re-submit with updated document + previous review for context + summary of changes
3. Repeat until both approve

After approvals, proceed directly to task splitting evaluation.

---

### GATE 2: Task Splitting Evaluation
**Complete AFTER plan review and BEFORE final task packaging:**

**STEP 2.1:** Invoke `task-splitter` agent:

```
Evaluate if this task should be split into smaller sub-tasks.

Task directory: [absolute path to task folder]

Please analyze tech-decomposition-[feature-name].md and provide your decision and reasoning.
```

**STEP 2.2:** Check splitting decision:

- **IF `splitting-decision.md` created with SPLIT RECOMMENDED:**
  1. Present the splitting decision summary to user
  2. Ask user: "Task splitter recommends splitting into N phases. Confirm: Proceed with decomposition?"
  3. **IF user approves:** Invoke `task-decomposer` agent
  4. **IF user rejects:** Proceed to GATE 3 (single task package)

- **IF NO SPLIT RECOMMENDED:**
  - Proceed to GATE 3

---

### GATE 3: Final Task Packaging
**Complete AFTER task splitting evaluation:**

**ACTION:** Confirm the task package is implementation-ready:
- tech decomposition is approved by both reviewers
- splitting decision is saved (if applicable)
- all required docs/paths are present
- ADR reference added if architectural decision was made

---

## FINAL TASK DOCUMENT STRUCTURE

### Single Task (no split)
```
tasks/task-<date>-[feature-name]/
├── discovery-[feature-name].md              (optional, from /nf)
├── ui-planning-analysis-[feature-name].md   (optional, from GATE 0.7)
├── Plan Review - [feature-name].md          (from plan-reviewer)
└── tech-decomposition-[feature-name].md     (required)
```

### Split Task (after task-decomposer)
```
tasks/task-<date>-[feature-name]/
├── discovery-[feature-name].md                    (optional)
├── initial-tech-decomposition-[feature]-ARCHIVED.md
├── splitting-decision.md
├── phase-1-[name]/
│   └── tech-decomposition-phase-1-[name].md
├── phase-2-[name]/
│   └── tech-decomposition-phase-2-[name].md
└── phase-N-[name]/
    └── tech-decomposition-phase-N-[name].md
```

**Document Structure**: See `docs/product-docs/templates/technical-decomposition-template.md`

**Key Sections**:
- **Primary Objective**: Clear statement of what we're building
- **Test Plan**: TDD approach with Given/When/Then test cases + test runner commands
- **Implementation Steps**: Detailed steps with MobileLiteApp file paths, layer notes
- **Tracking & Progress**: branch, PR
- **Dependencies**: (for split tasks) Phase dependencies

---

## FLEXIBILITY NOTES

**For Simple Tasks** (quick workflow):
- Gather requirements directly from user
- Create technical decomposition based on conversation
- Still follow TDD approach with test plan first
- Still get plan-reviewer and senior-architecture-reviewer approval

**For Complex Features** (full workflow):
- Run `/nf` first for discovery
- Use `mobile-ui-planning-agent` for UI-heavy work
- More detailed planning and review
