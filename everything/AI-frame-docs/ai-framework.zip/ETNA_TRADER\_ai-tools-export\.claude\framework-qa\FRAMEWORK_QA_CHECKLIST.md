# Framework QA Checklist

Run after any structural change to `.claude/`, `.cursor/`, or `scripts/`.
Check only the sections relevant to what was changed.

---

## Skills integrity

- [ ] Each new/changed skill has a `skill.md` file in its named subdirectory under `skills/`
- [ ] Skill has a clear frontmatter `name` and `description` (used by agent routing)
- [ ] Skill has an explicit trigger condition (when to use it)
- [ ] Skill has a defined output contract (what it produces and where)
- [ ] Skill does not duplicate another skill's purpose without a clear distinction
- [ ] If skill references an agent: agent name matches exactly what exists in `agents/`
- [ ] If skill writes to `tasks/`: path follows `tasks/task-YYYY-MM-DD-<name>/` convention
- [ ] Skill README is updated if the new skill should appear in the index

---

## Agents integrity

- [ ] Agent file has `name`, `model`, and a clear purpose section
- [ ] Agent routing matches the skill(s) that invoke it
- [ ] Agent does not reference a skill or tool that doesn't exist
- [ ] `senior-qa-engineer` agent still covers: automation, documentation, test-architecture
- [ ] No agent embeds static knowledge that belongs in a rule or skill
- [ ] Agent uses the correct model (check against team conventions)

---

## Rules integrity

- [ ] Each new rule exists as both `.md` and `.mdc` files with identical content
- [ ] Rule has a clear "When to Apply" section
- [ ] No rule creates a conflict or override loop with another existing rule
- [ ] `sync.mdc` rule is present and its trigger table is accurate
- [ ] `framework-qa.mdc` rule is present
- [ ] `tasks-artifact-layout.mdc` rule is present

---

## Sync integrity

- [ ] `.claude/skills/` and `.cursor/skills/` are identical (run `node scripts/sync-configs.js --check`)
- [ ] `.claude/agents/` and `.cursor/agents/` are identical
- [ ] `.claude/rules/` and `.cursor/rules/` are identical
- [ ] `.claude/framework-qa/` and `.cursor/framework-qa/` are identical
- [ ] `CLAUDE.md` and `AGENTS.md` are identical (run `node scripts/sync-docs.js --check`)
- [ ] Root `d:\DevReps\.claude\skills\` contains same skills as `_ai-tools-export/.claude/skills/`
- [ ] Any new skill added to `_ai-tools-export` must also be present in `ETNA_TRADER/.claude/skills/`

---

## Artifact discipline

- [ ] Every skill that generates task output writes to `tasks/task-YYYY-MM-DD-<name>/`
- [ ] No skill writes output directly to the repo root or `.claude/`
- [ ] Evidence files are separate from plan/test files
- [ ] Skills that generate test plans produce: `test-plan-<name>.md`
- [ ] Skills that generate test cases produce: `test-cases-<name>.md`
- [ ] Skills that perform code reviews produce: `code-review-<name>.md`
- [ ] No skill output contains unverified claims (all claims must be grounded in provided context)

---

## Anti-hallucination

- [ ] No skill instructs the agent to generate content without first reading provided context
- [ ] QA skills require at least one AC reference per test case
- [ ] Release notes skill (`ai-settings` RELEASE_NOTES mode) requires `git diff` before generation
- [ ] Coverage review skill requires actual test file inspection before coverage claims
- [ ] No skill contains the phrase "based on your knowledge" or "you may assume" without a grounding gate
- [ ] If AC/requirements are not provided, skill outputs a visible warning before proceeding

---

## Docs accuracy

- [ ] `CLAUDE.md` / `AGENTS.md` skill table reflects the current full skill list
- [ ] `FRAMEWORK_INDEX.md` is updated if a skill, agent, rule, or command was added/removed
- [ ] `docs/testing-guide.md` accurately reflects the test infrastructure (NUnit/xUnit, Builder pattern)
- [ ] No doc references a file, path, or command that no longer exists
- [ ] `skills/README.md` is up to date

---

## Sign-off

After all applicable checks pass:
- Run `node scripts/sync-configs.js --fix` to propagate to `.cursor/`
- Run `node scripts/sync-docs.js --fix` if `CLAUDE.md` was changed
- Confirm `ETNA_TRADER/.claude/` is also updated (or will be on next sync)
