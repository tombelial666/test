# State Management

This document describes when and how to use React Query vs Zustand for state management.

---

## Quick Decision Guide

| Data Type | Where to Store | Why |
|-----------|---------------|-----|
| Server data (positions, orders, accounts) | React Query | Caching, refetching, invalidation |
| App configuration (mobile settings) | Zustand | Static, needed everywhere, one-time fetch |
| Selected entities (current account) | Zustand | UI state, survives navigation |
| UI state (modals, toasts, flags) | Zustand | Client-only, ephemeral |

---

## React Query — Server State

Use React Query for data that:
- Lives on the backend and can change
- Benefits from caching and automatic refetching
- Should be invalidated when related data changes
- Is scoped to specific screens/features

**Pattern**: `features/<feature>/hooks/queries.ts`

```ts
// features/portfolio/hooks/queries.ts
export function usePositionsQuery() {
  const { portfolioService } = useApi();
  return useQuery({
    queryKey: ["positions"],
    queryFn: () => portfolioService.getPositions(),
  });
}
```

**Behavior**:
- Data cached according to `staleTime` / `cacheTime`
- Background refetch on window focus / reconnect
- Automatic invalidation via `queryClient.invalidateQueries()`

---

## Zustand — App State

Use Zustand for data that:
- Is needed across the entire app (not scoped to one screen)
- Should survive navigation between screens
- Is static or rarely changes during session
- Requires synchronous access from anywhere

**Examples**:
- `MobileSettings` — app configuration from server, fetched once at startup
- `selectedAccountId` — user's current account selection
- UI flags — feature toggles, overlay states

---

## Store Structure

```
src/store/
  createStore.ts           # Store factory with slice composition
  slices/
    settings.slice.ts      # MobileSettings state + actions
    session.slice.ts       # Selected account, user preferences
    ui.slice.ts            # Toasts, overlays, feature flags
  selectors/
    settings.selectors.ts  # Derived state helpers
  index.ts                 # Exports: useStore, selectors
```

---

## Slice Pattern

Slices define state + actions. They do NOT import infrastructure directly — services are passed via DI.

```ts
// store/slices/settings.slice.ts
import type { StateCreator } from "zustand";
import type { MobileSettings } from "@/domain/value-objects/MobileSettings";
import type { IMobileSettingsService } from "@/domain/ports/IMobileSettingsService";

export interface SettingsSlice {
  settings: MobileSettings | null;
  isLoading: boolean;
  fetchSettings: (service: IMobileSettingsService) => Promise<void>;
  setSettings: (settings: MobileSettings) => void;
}

export const createSettingsSlice: StateCreator<SettingsSlice> = (set) => ({
  settings: null,
  isLoading: false,

  fetchSettings: async (service) => {
    set({ isLoading: true });
    try {
      const settings = await service.getSettings();
      set({ settings, isLoading: false });
    } catch (error) {
      // Graceful degradation: store null on failure, app continues
      set({ settings: null, isLoading: false });
      console.error("Failed to fetch mobile settings:", error);
    }
  },

  setSettings: (settings) => set({ settings }),
});
```

**Key Design Decision**: Settings fetch failures set `settings: null` rather than storing an error message. This enables graceful degradation where components can use fallback defaults if settings are unavailable. The app remains functional even if settings fail to load.

---

## Store Factory

```ts
// store/createStore.ts
import { create } from "zustand";
import { createSettingsSlice, SettingsSlice } from "./slices/settings.slice";
import { createSessionSlice, SessionSlice } from "./slices/session.slice";

export type AppStore = SettingsSlice & SessionSlice;

export const useStore = create<AppStore>()((...args) => ({
  ...createSettingsSlice(...args),
  ...createSessionSlice(...args),
}));
```

---

## Initialization Pattern

Store actions that need API calls receive services via parameter (DI). Initialization happens in `AppInitializationProvider`, which orchestrates all startup tasks.

```tsx
// composition/AppInitializationProvider.tsx
import { useEffect, useState } from "react";
import { useStore } from "@/store";
import { useApi } from "./ApiProvider";
import { LoadingView } from "@/shared/ui";

export function AppInitializationProvider({ children }: { children: React.ReactNode }) {
  const { mobileSettingsService } = useApi();
  const fetchSettings = useStore((state) => state.fetchSettings);
  const isLoading = useStore((state) => state.isLoading);
  const [initialized, setInitialized] = useState(false);

  useEffect(() => {
    // Fetch settings once on mount
    fetchSettings(mobileSettingsService).finally(() => {
      setInitialized(true);
    });
  }, [fetchSettings, mobileSettingsService]);

  // Show loading view until initialization completes
  if (!initialized || isLoading) {
    return <LoadingView />;
  }

  return <>{children}</>;
}
```

**Key points**:
- `AppInitializationProvider` orchestrates all startup tasks (settings, push, sockets, etc.)
- Must be inside `ApiProvider` → has access to `useApi()`
- Service is passed to action, not imported in slice
- Store does not depend on infrastructure layer
- Zustand store is created at module level and accessed directly via `useStore()`
- See [ADR-0002](./adr/0002-app-initialization-provider.md) for centralized startup orchestration pattern

---

## Using Store in Components

```tsx
// features/trading/screens/PlaceOrderScreen.tsx
import { useStore } from "@/store";

export function PlaceOrderScreen() {
  const settings = useStore((s) => s.settings);
  const selectedAccountId = useStore((s) => s.selectedAccountId);

  if (!settings?.enableAccountProfile) {
    return <Text>Account profile is disabled</Text>;
  }

  // ...
}
```

---

## Selectors (Optional)

For complex derived state, create selectors:

```ts
// store/selectors/settings.selectors.ts
import { useStore } from "../createStore";
import type { MobileSettings } from "@/domain/value-objects/MobileSettings";

export const useSettings = (): MobileSettings | null =>
  useStore((state) => state.settings);

export const useSettingsLoading = (): boolean =>
  useStore((state) => state.isLoading);

// Example derived selector
export const useIsTradingEnabled = (): boolean =>
  useStore((state) => state.settings?.enableAccountProfile ?? false);
```

---

## Import Boundaries

- **store** does NOT import `infrastructure`
- **store** may import `domain` (entities, ports for types)
- **composition** wires store with services (DI)
- **features** may import `store` (selectors, actions)

---

## Common Use Cases

Examples of what to store in Zustand:

### Mobile Settings
**What**: App configuration fetched once at startup (feature flags, URLs, display settings).  
**Why Store**: Static during session, needed everywhere, one-time fetch.  
**Slice**: `settings.slice.ts`

### Selected Account
**What**: Currently active account ID selected by user.  
**Why Store**: UI state that survives navigation, needed across features.  
**Slice**: `session.slice.ts`

### Accounts List
**What**: List of accounts belonging to the user.  
**Why Store**: Needed globally for account switching, changes infrequently.  
**Note**: Can also use React Query if list updates often or needs invalidation.

### UI State
**What**: Toast notifications queue, theme (light/dark), selected language.  
**Why Store**: Client-only state, ephemeral, needed across app.  
**Slice**: `ui.slice.ts`

### User Preferences (Future)
**What**: Display currency, default sort order, saved filters, view preferences.  
**Why Store**: Local user choices, not server data.  
**Note**: Only if not coming from API/streamer in runtime.

### Draft Orders (Future)
**What**: Partially filled order forms saved between navigation.  
**Why Store**: Temporary UI state that should persist navigation.  
**Slice**: `trading.slice.ts`

### Recent Symbols
**What**: Last 10-20 viewed symbols/instruments for quick access.  
**Why Store**: Navigation history, client-side only.  
**Slice**: `navigation.slice.ts`

### Search History
**What**: Recent search queries for quick access.  
**Why Store**: User interaction history, local state.  
**Slice**: `navigation.slice.ts`

---

## Summary

| Concern | React Query | Zustand |
|---------|-------------|---------|
| **What** | Server state | App state |
| **Lifecycle** | Cache-based, auto-refetch | Persistent during session |
| **Scope** | Per-feature queries | Global store |
| **API calls** | In `queryFn` | Via DI in `AppInitializationProvider` |
| **Examples** | Positions, orders, streaming data, social activity | Mobile settings, selected account, UI state, recent symbols, search history |
