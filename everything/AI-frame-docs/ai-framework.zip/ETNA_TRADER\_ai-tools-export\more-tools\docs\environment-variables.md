# Environment Variables

This document describes all environment variables used in the project and how to configure them.

---

## Overview

The project uses Expo's environment variable system with the `EXPO_PUBLIC_` prefix for client-accessible variables. Variables are loaded from `.env` files and can be overridden per environment.

---

## Configuration Files

- **`.env`** - Main environment configuration (not committed to git)
- **`.env.example`** - Template with all available variables (committed to git)

**Setup:**
```bash
cp .env.example .env
# Edit .env with your values
```

---

## API Configuration

### Primary API

Variables for the main backend API:

- **`EXPO_PUBLIC_PRIMARY_API_URL`** (required)
  - Base URL for primary API
  - Example: `https://api.example.com/v1`
  
- **`EXPO_PUBLIC_PRIMARY_API_KEY`** (required)
  - API key for primary API authentication
  - Sent as header: `Et-App-Key: <value>`

### Secondary API

Variables for secondary/alternative backend API:

- **`EXPO_PUBLIC_SECONDARY_API_URL`** (required)
  - Base URL for secondary API
  - Example: `https://api-secondary.example.com/v1`
  
- **`EXPO_PUBLIC_SECONDARY_API_KEY`** (required)
  - API key for secondary API authentication
  - Sent as header: `Et-App-Key: <value>`

### API Switching

- **`EXPO_PUBLIC_USE_SECONDARY_API`** (optional)
  - Toggle between primary and secondary APIs
  - Values: `true` | `false`
  - Default: `false` (uses primary API)

---

## Keycloak Authentication Configuration

Variables for Keycloak OAuth2/OIDC authentication:

- **`EXPO_PUBLIC_KEYCLOAK_REALM_NAME`** (optional)
  - Keycloak realm name (tenant/organization identifier)
  - Example: `my-company-realm`, `demo-realm`
  - Default: `your-realm-name`

- **`EXPO_PUBLIC_KEYCLOAK_AUTH_SERVER_URL`** (optional)
  - Base URL of Keycloak identity server
  - Example: `https://keycloak.example.com`, `https://auth.mycompany.com`
  - Default: `https://keycloak.example.com`

- **`EXPO_PUBLIC_KEYCLOAK_CLIENT_ID`** (optional)
  - Keycloak client ID (identifies this mobile app)
  - Example: `mobile-app-client`, `my-mobile-app`
  - Default: `your-mobile-app-client-id`

- **`EXPO_PUBLIC_KEYCLOAK_SCOPES`** (optional)
  - Comma-separated list of OAuth scopes
  - Example: `openid,profile,email`
  - Default: `openid,profile,email`

- **`EXPO_PUBLIC_KEYCLOAK_TIMEOUT`** (optional)
  - Connection timeout for Keycloak API calls (milliseconds)
  - Example: `5000`
  - Default: `5000`

**Example:**
```bash
EXPO_PUBLIC_KEYCLOAK_REALM_NAME=my-company-realm
EXPO_PUBLIC_KEYCLOAK_AUTH_SERVER_URL=https://keycloak.example.com
EXPO_PUBLIC_KEYCLOAK_CLIENT_ID=mobile-app-client
EXPO_PUBLIC_KEYCLOAK_SCOPES=openid,profile,email
EXPO_PUBLIC_KEYCLOAK_TIMEOUT=5000
```

**Note:** OAuth redirect URI is automatically constructed from the `scheme` field in brand configuration with `:/callback` suffix (single slash — `/callback` is a path, not a host).

**To configure redirect URI:**
1. Edit `/brand-config.js` → update the `scheme` field (e.g., `"my-app"`)
2. Register the redirect URI in Keycloak client configuration
3. Example: `scheme: "my-app"` → `my-app:/callback`

See [Keycloak Authentication - OAuth Redirect URI](./keycloak-authentication.md#oauth-redirect-uri) for detailed instructions.

---

## White-Label Configuration

Variables for multi-brand configuration:

- **`BRAND`** (optional)
  - Brand identifier
  - Values: `etna` | `sogo` | custom brand name
  - Default: `default`
  - Used by: `brand-config.js`, `app.config.ts`

- **`APP_ENV`** (optional)
  - Application environment
  - Values: `development` | `staging` | `production`
  - Default: `development`
  - Used for environment-specific brand configurations

**Example:**
```bash
BRAND=etna
APP_ENV=production
```

See [White-Label Configuration](./white-label-configuration.md) for details.

---

## Example .env File

```bash
# API Configuration
EXPO_PUBLIC_PRIMARY_API_URL=https://api.example.com/v1
EXPO_PUBLIC_PRIMARY_API_KEY=your-primary-api-key-here

EXPO_PUBLIC_SECONDARY_API_URL=https://api-secondary.example.com/v1
EXPO_PUBLIC_SECONDARY_API_KEY=your-secondary-api-key-here

# Optional: Use secondary API instead of primary
# EXPO_PUBLIC_USE_SECONDARY_API=true

# Keycloak Authentication (Optional - only needed if using Keycloak auth)
EXPO_PUBLIC_KEYCLOAK_REALM_NAME=my-company-realm
EXPO_PUBLIC_KEYCLOAK_AUTH_SERVER_URL=https://keycloak.example.com
EXPO_PUBLIC_KEYCLOAK_CLIENT_ID=mobile-app-client
EXPO_PUBLIC_KEYCLOAK_SCOPES=openid,profile,email
EXPO_PUBLIC_KEYCLOAK_TIMEOUT=5000
# Note: Redirect URI is auto-constructed from brand config (bundleIdentifier/package)

# White-Label Configuration
BRAND=etna
APP_ENV=production
```

---

## Accessing Environment Variables

### In TypeScript/React Code

```ts
// Access environment variables
const apiUrl = process.env.EXPO_PUBLIC_PRIMARY_API_URL;
const apiKey = process.env.EXPO_PUBLIC_PRIMARY_API_KEY;
```

### In Expo Config

```ts
// app.config.ts
export default {
  // Access via process.env
  extra: {
    apiUrl: process.env.EXPO_PUBLIC_PRIMARY_API_URL,
  },
};
```

### In Brand Config

```js
// brand-config.js
const brand = process.env.BRAND || 'default';
const env = process.env.APP_ENV || 'development';
```

---

## Type Safety

Define types for environment variables to ensure type safety:

```ts
// src/shared/types/env.d.ts
declare global {
  namespace NodeJS {
    interface ProcessEnv {
      // API Configuration
      EXPO_PUBLIC_PRIMARY_API_URL: string;
      EXPO_PUBLIC_PRIMARY_API_KEY: string;
      EXPO_PUBLIC_SECONDARY_API_URL: string;
      EXPO_PUBLIC_SECONDARY_API_KEY: string;
      EXPO_PUBLIC_USE_SECONDARY_API?: 'true' | 'false';
      
      // Keycloak Authentication
      EXPO_PUBLIC_KEYCLOAK_REALM_NAME?: string;
      EXPO_PUBLIC_KEYCLOAK_AUTH_SERVER_URL?: string;
      EXPO_PUBLIC_KEYCLOAK_CLIENT_ID?: string;
      EXPO_PUBLIC_KEYCLOAK_SCOPES?: string;
      EXPO_PUBLIC_KEYCLOAK_TIMEOUT?: string;
      
      // White-Label
      BRAND?: string;
      APP_ENV?: 'development' | 'staging' | 'production';
    }
  }
}

export {};
```

---

## Environment-Specific Configuration

### Development

```bash
EXPO_PUBLIC_PRIMARY_API_URL=http://localhost:3000/api
EXPO_PUBLIC_PRIMARY_API_KEY=dev-key
BRAND=default
APP_ENV=development
```

### Staging

```bash
EXPO_PUBLIC_PRIMARY_API_URL=https://api-staging.example.com/v1
EXPO_PUBLIC_PRIMARY_API_KEY=staging-key
BRAND=etna
APP_ENV=staging
```

### Production

```bash
EXPO_PUBLIC_PRIMARY_API_URL=https://api.example.com/v1
EXPO_PUBLIC_PRIMARY_API_KEY=prod-key
BRAND=etna
APP_ENV=production
```

---

## Best Practices

1. **Never commit `.env` files** - Add to `.gitignore`
2. **Keep `.env.example` updated** - Document all variables
3. **Use `EXPO_PUBLIC_` prefix** - For client-accessible variables
4. **Validate on startup** - Check required variables exist
5. **Use strong API keys** - Especially in production
6. **Rotate keys regularly** - Update API keys periodically
7. **Environment-specific values** - Different keys per environment

---

## Validation

Create a validation utility to ensure all required variables are set:

```ts
// src/shared/config/env.ts
function validateEnv() {
  const required = [
    'EXPO_PUBLIC_PRIMARY_API_URL',
    'EXPO_PUBLIC_PRIMARY_API_KEY',
    'EXPO_PUBLIC_SECONDARY_API_URL',
    'EXPO_PUBLIC_SECONDARY_API_KEY',
  ];

  const missing = required.filter(key => !process.env[key]);

  if (missing.length > 0) {
    throw new Error(
      `Missing required environment variables: ${missing.join(', ')}`
    );
  }
}

// Call at app startup
validateEnv();
```

---

## Troubleshooting

### Variables Not Loading

1. Restart Expo dev server after changing `.env`
2. Clear cache: `npx expo start --clear`
3. Ensure variable has `EXPO_PUBLIC_` prefix

### TypeScript Errors

1. Update `src/shared/types/env.d.ts` with new variables
2. Restart TypeScript server in IDE

### Build Issues

1. Ensure `.env` file exists in project root
2. Check EAS build configuration for environment variables
3. Verify no typos in variable names

---

## Related Documentation

- [HTTP Infrastructure](./http-infrastructure.md) - How API variables are used
- [White-Label Configuration](./white-label-configuration.md) - Brand-specific configuration
- [Project Structure](./project-structure.md) - Config file locations

