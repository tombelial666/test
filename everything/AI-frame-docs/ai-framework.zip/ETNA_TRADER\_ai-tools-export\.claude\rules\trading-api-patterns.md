# REST API Patterns — ETNA_TRADER .NET Backend

> **Stack**: OWIN + ASP.NET Web API 2 (`System.Web.Http`), Unity DI, FluentValidation, Swashbuckle, Microsoft.Web.Http versioning.
> This is **NOT** ASP.NET Core. Do not use `WebApplication`, `IApplicationBuilder`, `ControllerBase`, or `ActionResult<T>`.

---

## Controller Base

Controllers inherit from the project's custom `WebApiController<TService>` base (or `ApiController` for simpler cases). Do NOT use `ControllerBase` (that's ASP.NET Core).

```csharp
using System.Web.Http;
using Etna.Trader.WebApi.Controllers.Infrastructure;

// ✅ Correct — inherits from project base
public class OrdersController : WebApiController<IOrderService>
{
    public OrdersController(IOrderService service) : base(service) { }
}

// ✅ Also acceptable for simpler controllers
public class HealthController : ApiController
{
    [HttpGet]
    [Route("health")]
    [AllowAnonymous]
    public IHttpActionResult GetHealth() => Ok(new { status = "ok" });
}

// ❌ Wrong — ASP.NET Core only
public class OrdersController : ControllerBase { ... }
```

---

## Controller Naming

- PascalCase, always suffixed with `Controller`
- One controller per resource noun

```csharp
// ✅ Correct
public class OrdersController : WebApiController<IOrderService> { ... }
public class AccountsController : WebApiController<IAccountService> { ... }
public class PositionsController : WebApiController<IPositionService> { ... }

// ❌ Avoid — action-named, not resource-named
public class PlaceOrderController : ... { }
```

---

## Route Conventions

All routes follow: `/v{version}.0/{resource}` (via `[VersionedPrefix]` and `[ApiVersion]`).

```
GET    /v1.0/orders                           → list orders (filterable)
POST   /v1.0/orders                           → place new order
GET    /v1.0/orders/{orderId}                 → get single order
DELETE /v1.0/orders/{orderId}                 → cancel order
PATCH  /v1.0/orders/{orderId}                 → amend order

GET    /v1.0/accounts                         → list accounts
GET    /v1.0/accounts/{accountId}/info        → account balance/info
GET    /v1.0/accounts/{accountId}/positions   → positions for account
GET    /v1.0/accounts/{accountId}/orders      → orders for account
```

### Controller with versioning and auth

```csharp
using Microsoft.Web.Http;
using System.Web.Http;
using Etna.Trader.WebApi.Controllers.Infrastructure;
using Etna.Trader.WebApi.Controllers.Infrastructure.AuthorizeFilters;
using Swashbuckle.Swagger.Annotations;
using System.Net;
using System.Collections.Generic;

[ApiVersion("1.0")]
[VersionedPrefix]                                       // generates route prefix /v1.0/
[AllowUserScopedRequests("userId")]                     // custom auth filter: user can only see own data
public class OrdersController : WebApiController<IOrderService>
{
    public OrdersController(IOrderService service) : base(service) { }

    /// <summary>Get orders for an account</summary>
    [SwaggerResponse(HttpStatusCode.OK, "List of orders", typeof(IEnumerable<OrderDto>))]
    [HttpGet]
    [Route("accounts/{accountId}/orders")]
    [ParamFilter(typeof(AccountOwnershipValidator), "accountId", true)]  // validate ownership
    public IHttpActionResult GetOrders(int accountId, [FromUri] OrderQueryParams query)
    {
        var orders = Service.GetOrders(accountId, query);
        return Ok(orders);
    }

    /// <summary>Place a new order</summary>
    [SwaggerResponse(HttpStatusCode.OK, "Order placed", typeof(OrderDto))]
    [HttpPost]
    [Route("accounts/{accountId}/orders")]
    [ParamFilter(typeof(AccountOwnershipValidator), "accountId", true)]
    public IHttpActionResult PlaceOrder(int accountId, [FromBody] PlaceOrderRequest request)
    {
        var result = Service.PlaceOrder(accountId, request);
        return Ok(result);
    }

    /// <summary>Cancel an order</summary>
    [SwaggerResponse(HttpStatusCode.OK, "Order cancelled")]
    [HttpDelete]
    [Route("accounts/{accountId}/orders/{orderId}")]
    [ParamFilter(typeof(AccountOwnershipValidator), "accountId", true)]
    public IHttpActionResult CancelOrder(int accountId, long orderId)
    {
        Service.CancelOrder(accountId, orderId);
        return Ok();
    }
}
```

---

## Return Type: `IHttpActionResult`

NOT `ActionResult<T>` (ASP.NET Core). Use Web API 2 result helpers.

```csharp
// ✅ Correct return types (Web API 2)
return Ok(result);                  // 200
return Created(uri, result);        // 201
return BadRequest("reason");        // 400
return BadRequest(ModelState);      // 400 with validation errors
return Unauthorized();              // 401
return StatusCode(HttpStatusCode.Forbidden);  // 403
return NotFound();                  // 404
return Conflict();                  // 409
return InternalServerError(ex);     // 500

// ❌ Wrong (ASP.NET Core)
return CreatedAtAction(...);
return ValidationProblem(...);
return Problem(...);
```

---

## Request / Response DTO Patterns

### Naming

| Pattern | Example |
|---------|---------|
| Request DTO | `PlaceOrderRequest`, `AmendOrderRequest` |
| Response DTO | `OrderDto`, `BalancesResult` |
| Paged wrapper | `PaginatedResponse<T>` |
| Query params (from URI) | `OrderQueryParams` |

### Request DTO with FluentValidation

```csharp
// Models/Orders/PlaceOrderRequest.cs
namespace Etna.Trader.WebApi.Controllers.Orders.Entity;

public class PlaceOrderRequest
{
    public int AccountId { get; set; }
    public string Symbol { get; set; }
    public string Side { get; set; }        // "Buy" | "Sell"
    public string Type { get; set; }        // "Market" | "Limit" | "Stop" | "StopLimit"
    public int Quantity { get; set; }
    public decimal? LimitPrice { get; set; }
    public decimal? StopPrice { get; set; }
    public string ClientOrderId { get; set; }
}

// Validators/PlaceOrderRequestValidator.cs (FluentValidation)
public class PlaceOrderRequestValidator : AbstractValidator<PlaceOrderRequest>
{
    public PlaceOrderRequestValidator()
    {
        RuleFor(x => x.Symbol).NotEmpty().MaximumLength(20);
        RuleFor(x => x.Quantity).GreaterThan(0);
        RuleFor(x => x.LimitPrice).GreaterThan(0)
            .When(x => x.Type is "Limit" or "StopLimit");
    }
}
```

### Response DTO

```csharp
// Etna.Trading.OmsWebService.Dto namespace (existing pattern)
public class OrderDto
{
    public long Id { get; set; }
    public int AccountId { get; set; }
    public string Symbol { get; set; }
    public string Side { get; set; }
    public string Type { get; set; }
    public string Status { get; set; }
    public int Quantity { get; set; }
    public int CumulativeQuantity { get; set; }
    public decimal? Price { get; set; }
    public decimal? AveragePrice { get; set; }
    public DateTime Date { get; set; }
}
```

---

## Authentication and Authorization

### OWIN Middleware Pipeline (Startup.cs)

```csharp
// Applied in order in Startup.Configuration(IAppBuilder app):
app.UseCorrelationIdMiddleware();
app.UseRequestLengthRestrictions();
app.UseExceptionHandlingMiddleware(configuration);
app.Use<BottleneckMiddleware>();
app.UseQueryMiddleware();
app.UseCors(...);
app.UseAppKeyMiddleware(ignorePaths);           // AppKey auth
app.UseFrontOfficeAuthenticationMiddleware(".ASPXAUTH");  // Cookie auth
UseAuthenticationPipeline(app);               // Rules-based pipeline
app.UseKeycloakOidcAuthentication();          // Keycloak OIDC
```

### Auth Filter Attributes (Controller level)

```csharp
// Restrict to authenticated users only (default — no attribute needed if global filter applied)
[Authorize]

// Custom: user can only access their own resources
[AllowUserScopedRequests("userId")]

// Custom: validate account ownership via dedicated validator
[ParamFilter(typeof(AccountOwnershipValidator), "accountId", true)]

// Public endpoint (bypasses all auth)
[AllowAnonymous]
```

### Account Ownership Validation

Every endpoint that takes `accountId` MUST validate ownership. Use the existing `AccountOwnershipValidator` via `[ParamFilter]`:

```csharp
[HttpGet]
[Route("accounts/{accountId}/positions")]
[ParamFilter(typeof(AccountOwnershipValidator), "accountId", true)]
public IHttpActionResult GetPositions(int accountId)
{
    // AccountOwnershipValidator has already verified the caller owns this account
    var positions = Service.GetPositions(accountId);
    return Ok(positions);
}
```

**Never** manually check ownership inside a controller without `[ParamFilter]` — it is easy to miss.

---

## Error Handling

Global error handling is done via `UseExceptionHandlingMiddleware` in OWIN startup. Do NOT add try/catch in every controller method.

For domain validation errors, return `BadRequest` with model state (FluentValidation integrates via `FluentValidationModelValidatorProvider.Configure`):

```csharp
if (!ModelState.IsValid)
    return BadRequest(ModelState);
```

For business rule violations, use a typed exception that the global handler maps to the correct HTTP status:

```csharp
// Throw in service layer — global handler maps to 409
throw new BusinessRuleException("Order cannot be cancelled", "ORDER_NOT_CANCELLABLE");

// Throw in service layer — global handler maps to 404
throw new NotFoundException($"Order '{orderId}' not found");
```

---

## Query Parameters

Accept via `[FromUri]` (Web API 2 convention):

```csharp
public class OrderQueryParams
{
    public string Symbol { get; set; }
    public string Status { get; set; }
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
    public int PageNumber { get; set; } = 1;
    public int PageSize { get; set; } = 50;
}

[HttpGet]
[Route("accounts/{accountId}/orders")]
public IHttpActionResult GetOrders(int accountId, [FromUri] OrderQueryParams query)
{
    var result = Service.GetOrders(accountId, query);
    return Ok(result);
}
```

---

## Swagger Documentation

Use `[SwaggerResponse]` attributes (Swashbuckle, not Swashbuckle.AspNetCore):

```csharp
using Swashbuckle.Swagger.Annotations;
using System.Net;

[SwaggerResponse(HttpStatusCode.OK, "Order placed successfully", typeof(OrderDto))]
[SwaggerResponse(HttpStatusCode.BadRequest, "Validation error")]
[SwaggerResponse(HttpStatusCode.Unauthorized, "Authentication required")]
[SwaggerResponse(HttpStatusCode.Forbidden, "Insufficient permissions")]
[HttpPost]
[Route("accounts/{accountId}/orders")]
public IHttpActionResult PlaceOrder(int accountId, [FromBody] PlaceOrderRequest request)
{ ... }
```

---

## HTTP Status Code Conventions

| Scenario | Web API 2 return |
|----------|-----------------|
| Successful read | `Ok(result)` → 200 |
| Resource created | `Created(uri, result)` → 201 |
| Accepted (async) | `StatusCode(HttpStatusCode.Accepted)` → 202 |
| Successful delete | `Ok()` → 200 (or `StatusCode(204)`) |
| Validation failure | `BadRequest(ModelState)` → 400 |
| Unauthenticated | `Unauthorized()` → 401 |
| Forbidden | `StatusCode(HttpStatusCode.Forbidden)` → 403 |
| Not found | `NotFound()` → 404 |
| Business rule conflict | Throw exception → global handler → 409 |
| Server error | `InternalServerError(ex)` → 500 |

---

## Versioning

Versioning via `Microsoft.Web.Http` (not `Asp.Versioning.Mvc`):

```csharp
[ApiVersion("1.0")]
[VersionedPrefix]               // generates /v1.0/ prefix
public class OrdersController : WebApiController<IOrderService> { ... }
```

New version of an endpoint:

```csharp
[ApiVersion("2.0")]
[VersionedPrefix]
public class OrdersV2Controller : WebApiController<IOrderServiceV2> { ... }
```

---

## Idempotency

Order placement accepts `ClientOrderId` in the request body for client-side deduplication. The service layer checks for existing orders with the same `ClientOrderId` before inserting.
