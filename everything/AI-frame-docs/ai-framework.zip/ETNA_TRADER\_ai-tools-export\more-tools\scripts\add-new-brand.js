#!/usr/bin/env node

/**
 * Interactive script to add a new brand to the white-label configuration
 * 
 * Usage: npm run add-new-brand
 * 
 * This script will:
 * 1. Prompt for brand details (with default values)
 * 2. Create brand assets directory
 * 3. Add brand to brand-config.js
 * 4. Add scripts to package.json
 * 5. Add build profiles to eas.json
 */

import {
  readFileSync, writeFileSync, mkdirSync, existsSync 
} from 'fs';
import { join } from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import readline from 'readline';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const rootDir = join(__dirname, '..');

// File paths
const BRAND_CONFIG_PATH = join(rootDir, 'brand-config.js');
const PACKAGE_JSON_PATH = join(rootDir, 'package.json');
const EAS_JSON_PATH = join(rootDir, 'eas.json');
const ASSETS_BRANDS_DIR = join(rootDir, 'assets', 'brands');

// Readline interface for user input
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

function question(query) {
  return new Promise((resolve) => {
    rl.question(query, resolve);
  });
}

function closeReadline() {
  rl.close();
}

// Helper to generate default values
function generateDefaults(brandKey) {
  const normalized = brandKey.toLowerCase().replace(/[^a-z0-9]/g, '');
  const capitalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);
  
  return {
    appName: `${capitalized}`,
    slug: `${normalized}-mobile`,
    scheme: `${normalized}-mobile`,
    bundleIdentifier: `com.${normalized}.mobile`,
    package: `com.${normalized}.mobile`,
  };
}

// Read and parse JSON files
function readJSON(path) {
  try {
    const content = readFileSync(path, 'utf-8');
    return JSON.parse(content);
  } catch (error) {
    console.error(`Error reading ${path}:`, error.message);
    process.exit(1);
  }
}

function writeJSON(path, data) {
  writeFileSync(path, JSON.stringify(data, null, 2) + '\n', 'utf-8');
}

// Read brand-config.js as text (it's a JS file, not JSON)
function readBrandConfig() {
  return readFileSync(BRAND_CONFIG_PATH, 'utf-8');
}

function writeBrandConfig(content) {
  writeFileSync(BRAND_CONFIG_PATH, content, 'utf-8');
}

// Create brand assets directory
function createBrandAssetsDir(brandKey) {
  const brandDir = join(ASSETS_BRANDS_DIR, brandKey);
  
  if (existsSync(brandDir)) {
    console.log(`⚠️  Warning: Directory ${brandDir} already exists`);
    return;
  }
  
  mkdirSync(brandDir, { recursive: true });
  console.log(`✓ Created directory: assets/brands/${brandKey}/`);
  console.log(`  ⚠️  Remember to add icon.png and splash.png to this directory`);
}

// Add brand to brand-config.js
function addBrandToConfig(brandKey, brandConfig) {
  const content = readBrandConfig();
  
  // Check if brand already exists
  if (content.includes(`${brandKey}Brand`) || content.includes(`${brandKey}:`)) {
    console.log(`⚠️  Warning: Brand "${brandKey}" already exists in brand-config.js`);
    return false;
  }
  
  // Create brand object string
  const brandObject = `const ${brandKey}Brand = {
  appName: "${brandConfig.appName}",
  slug: "${brandConfig.slug}",
  scheme: "${brandConfig.scheme}",
  bundleIdentifier: "${brandConfig.bundleIdentifier}",
  package: "${brandConfig.package}",
};`;
  
  // Find where to insert (after the last brand definition, before brandRegistry)
  // Match all brand definitions
  const brandDefRegex = /const \w+Brand = \{[\s\S]*?\};/g;
  const brandMatches = [...content.matchAll(brandDefRegex)];
  
  if (brandMatches.length === 0) {
    console.error('Error: Could not find brand definitions in brand-config.js');
    return false;
  }
  
  // Get the last brand definition
  const lastBrandMatch = brandMatches[brandMatches.length - 1];
  const lastBrandEnd = lastBrandMatch.index + lastBrandMatch[0].length;
  
  // Insert new brand definition after the last one
  const newContent = 
    content.slice(0, lastBrandEnd) + 
    '\n\n' + brandObject + 
    content.slice(lastBrandEnd);
  
  // Add to brandRegistry
  const registryRegex = /const brandRegistry = \{([\s\S]*?)\};/;
  const registryMatch = newContent.match(registryRegex);
  
  if (!registryMatch) {
    console.error('Error: Could not find brandRegistry in brand-config.js');
    return false;
  }
  
  const registryStart = newContent.indexOf('const brandRegistry = {');
  const registryContent = registryMatch[1];
  const registryEnd = newContent.indexOf('};', registryStart);
  
  // Check if registry content ends with comma or is empty
  const trimmedRegistry = registryContent.trim();
  const needsComma = trimmedRegistry.length > 0 && !trimmedRegistry.endsWith(',');
  const newline = trimmedRegistry.length > 0 ? '\n' : '';
  
  const updatedRegistry = 
    newContent.slice(0, registryEnd) + 
    (needsComma ? ',' : '') + 
    `${newline}  ${brandKey}: ${brandKey}Brand,` + 
    newContent.slice(registryEnd);
  
  writeBrandConfig(updatedRegistry);
  console.log(`✓ Added brand "${brandKey}" to brand-config.js`);
  return true;
}

// Add scripts to package.json
function addScriptsToPackageJson(brandKey) {
  const packageJson = readJSON(PACKAGE_JSON_PATH);
  
  if (!packageJson.scripts) {
    packageJson.scripts = {};
  }
  
  const newScripts = {
    [`start:${brandKey}:dev`]: `cross-env BRAND=${brandKey} APP_ENV=development expo start -c`,
    [`start:${brandKey}:prod`]: `cross-env BRAND=${brandKey} APP_ENV=production expo start -c`,
    [`ios:${brandKey}`]: `cross-env BRAND=${brandKey} expo run:ios`,
    [`android:${brandKey}`]: `cross-env BRAND=${brandKey} expo run:android`,
  };
  
  // Check if scripts already exist
  let hasExisting = false;
  for (const scriptName of Object.keys(newScripts)) {
    if (packageJson.scripts[scriptName]) {
      console.log(`⚠️  Warning: Script "${scriptName}" already exists in package.json`);
      hasExisting = true;
    }
  }
  
  if (!hasExisting) {
    // Add new scripts (preserve existing order, add at the end of brand-related scripts)
    Object.assign(packageJson.scripts, newScripts);
    writeJSON(PACKAGE_JSON_PATH, packageJson);
    console.log(`✓ Added scripts to package.json`);
  }
}

// Add build profiles to eas.json
function addProfilesToEasJson(brandKey) {
  const easJson = readJSON(EAS_JSON_PATH);
  
  if (!easJson.build) {
    easJson.build = {};
  }
  
  const newProfiles = {
    [`${brandKey}-dev`]: {
      extends: 'development',
      env: {
        BRAND: brandKey,
        APP_ENV: 'development',
      },
    },
    [`${brandKey}-prod`]: {
      extends: 'production',
      env: {
        BRAND: brandKey,
        APP_ENV: 'production',
      },
    },
  };
  
  // Check if profiles already exist
  let hasExisting = false;
  for (const profileName of Object.keys(newProfiles)) {
    if (easJson.build[profileName]) {
      console.log(`⚠️  Warning: Profile "${profileName}" already exists in eas.json`);
      hasExisting = true;
    }
  }
  
  if (!hasExisting) {
    // Add new profiles
    Object.assign(easJson.build, newProfiles);
    writeJSON(EAS_JSON_PATH, easJson);
    console.log(`✓ Added build profiles to eas.json`);
  }
}

// Main function
async function main() {
  console.log('\n🎨 Add New Brand to White-Label Configuration\n');
  console.log('This script will help you add a new brand to the app.\n');
  
  try {
    // Step 1: Get brand key
    const brandKey = (await question('Enter brand key (e.g., "etna", "sogo"): ')).trim();
    if (!brandKey) {
      console.error('Error: Brand key cannot be empty');
      closeReadline();
      process.exit(1);
    }
    
    // Step 2: Generate defaults
    const defaults = generateDefaults(brandKey);
    console.log(`\nDefault values (press Enter to accept):\n`);
    
    // Step 3: Get brand details
    const appName = (await question(`App name [${defaults.appName}]: `)).trim() || defaults.appName;
    const slug = (await question(`Slug [${defaults.slug}]: `)).trim() || defaults.slug;
    const scheme = (await question(`Scheme [${defaults.scheme}]: `)).trim() || defaults.scheme;
    const bundleIdentifier = (await question(`Bundle identifier [${defaults.bundleIdentifier}]: `)).trim() || defaults.bundleIdentifier;
    const packageName = (await question(`Package name [${defaults.package}]: `)).trim() || defaults.package;
    
    const brandConfig = {
      appName,
      slug,
      scheme,
      bundleIdentifier,
      package: packageName,
    };
    
    console.log('\n📝 Summary:');
    console.log(`  Brand key: ${brandKey}`);
    console.log(`  App name: ${appName}`);
    console.log(`  Slug: ${slug}`);
    console.log(`  Scheme: ${scheme}`);
    console.log(`  Bundle ID: ${bundleIdentifier}`);
    console.log(`  Package: ${packageName}`);
    
    const confirm = await question('\nProceed with adding this brand? (y/n): ');
    if (confirm.toLowerCase() !== 'y' && confirm.toLowerCase() !== 'yes') {
      console.log('Cancelled.');
      closeReadline();
      process.exit(0);
    }
    
    console.log('\n🚀 Adding brand...\n');
    
    // Step 4: Create assets directory
    createBrandAssetsDir(brandKey);
    
    // Step 5: Add to brand-config.js
    addBrandToConfig(brandKey, brandConfig);
    
    // Step 6: Add scripts to package.json
    addScriptsToPackageJson(brandKey);
    
    // Step 7: Add profiles to eas.json
    addProfilesToEasJson(brandKey);
    
    console.log('\n✅ Brand added successfully!\n');
    console.log('Next steps:');
    console.log(`  1. Add icon.png (1024x1024px) to assets/brands/${brandKey}/`);
    console.log(`  2. Add splash.png to assets/brands/${brandKey}/`);
    console.log(`  3. Test with: npm run start:${brandKey}:dev`);
    console.log(`  4. Build with: npx eas build --profile ${brandKey}-prod --platform ios\n`);
    
  } catch (error) {
    console.error('\n❌ Error:', error.message);
    process.exit(1);
  } finally {
    closeReadline();
  }
}

main();

