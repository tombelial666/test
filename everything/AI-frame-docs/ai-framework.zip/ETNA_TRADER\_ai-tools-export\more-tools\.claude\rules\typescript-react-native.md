# TypeScript & React Native Development Guidelines

## TypeScript Configuration

- **Strict Mode**: Enabled in `tsconfig.json`
- **Path Alias**: Use `@/*` for all imports from `src/` (e.g., `@/shared/theme/hooks`)
- **Type Safety**: Always define prop interfaces, never use implicit `any`

## Component Development

### Functional Components with Hooks

```tsx
interface Props {
  userId: string;
  onPress?: () => void;
}

export function UserCard({ userId, onPress }: Props) {
  const colors = useThemeColors();
  const { data } = useUserQuery(userId);
  // ...
}
```

### Theme-Aware Styling

Always use `useThemeColors()` from `@/shared/theme/hooks`:

```tsx
import { useThemeColors } from '@/shared/theme/hooks';

// ✅ Correct
const colors = useThemeColors();
<View style={{ backgroundColor: colors.background.base }}>

// ❌ Wrong — these files do not exist in this project
import { useThemeColor } from '@/components/Themed';
import Colors from '@/constants/Colors';
```

## State Management

| State type | Tool | Location |
|------------|------|----------|
| Server data | React Query (`useQuery`, `useMutation`) | `src/features/<feature>/hooks/queries.ts` |
| Global app | Zustand | `src/store/` |
| Local UI | `useState`, `useReducer` | Component |

## Navigation (Expo Router)

```tsx
import { router, useLocalSearchParams } from 'expo-router';

// Navigate
router.push('/profile');
router.replace('/home');
router.back();

// Params
const { id } = useLocalSearchParams<{ id: string }>();
```

## Path Aliases

```ts
// ✅ Always use @/ alias
import { useThemeColors } from '@/shared/theme/hooks';
import { useStore } from '@/store';
import { useApi } from '@/composition/ApiProvider';
import { useAccountsQuery } from '@/features/account/hooks/queries';

// ❌ Never use relative cross-feature imports
import { something } from '../../../shared/theme/hooks';
```

## Styling

```tsx
import { StyleSheet } from 'react-native';
import { useThemeColors } from '@/shared/theme/hooks';

export function MyScreen() {
  const colors = useThemeColors();

  return (
    <View style={[styles.container, { backgroundColor: colors.background.base }]}>
      <Text style={{ color: colors.text.base }}>Hello</Text>
    </View>
  );
}

// Only non-color, layout-only styles in StyleSheet
const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
});
```

## Localization

Never hardcode UI text. Always use `t("key")`:

```tsx
import { useTranslation } from 'react-i18next';

const { t } = useTranslation();
return <Text>{t('profile.title')}</Text>;
```

## Layer Import Rules

```ts
// features → may import
import { useApi } from '@/composition/ApiProvider';           // ✅ composition
import { useStore } from '@/store';                           // ✅ store
import { useThemeColors } from '@/shared/theme/hooks';        // ✅ shared
import { usePositionsQuery } from '@/features/portfolio/...'; // ✅ other feature hooks

// features → must NOT import
import { AccountRepository } from '@/infrastructure/...';     // ❌ infrastructure
```

## Code Quality

- ESLint + Prettier: `npm run lint`, `npm run format`
- Tests in `tests/unit/` and `tests/integration/` (mirror `src/` structure)
- No `console.log` in production code

## Performance

- `React.memo()` for expensive pure components
- `useCallback` for stable function references passed to list items
- `FlatList` / `FlashList` for lists (never `ScrollView` + `.map()` for long datasets)
- Never create objects/arrays inline in JSX render
