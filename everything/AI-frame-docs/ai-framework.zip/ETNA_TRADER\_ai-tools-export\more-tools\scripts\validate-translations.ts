/**
 * Validate Hardcoded Text Script
 *
 * Scans src/features/, src/shared/, and app/ for hardcoded text in React Native components.
 * Detects common patterns where text should use t() from react-i18next instead.
 *
 * Usage:
 *   npx ts-node scripts/validate-translations.ts
 *
 * Exit codes:
 *   0 - No violations found
 *   1 - Violations found (blocks commit/build)
 */

import * as fs from "fs";
import * as path from "path";

interface Violation {
  file: string;
  line: number;
  content: string;
  pattern: string;
}

// Patterns that detect hardcoded text
// Each has a regex and description
const HARDCODED_TEXT_PATTERNS = [
  {
    name: "<Text> with hardcoded content",
    // Matches <Text ...>Some hardcoded text</Text> but not {expression}
    regex: /<Text[^>]*>\s*([A-Za-z][^{<\n]{2,})\s*<\/Text>/g,
  },
  {
    name: 'placeholder="hardcoded"',
    // Matches placeholder="some text" (not {expression} or empty)
    regex: /placeholder="([A-Za-z][^"]{1,})"/g,
  },
  {
    name: 'title="hardcoded"',
    // Matches title="some text" (not {expression} or empty)
    regex: /title="([A-Za-z][^"]{1,})"/g,
  },
  {
    name: 'label="hardcoded"',
    // Matches label="some text" (not {expression} or empty)
    regex: /label="([A-Za-z][^"]{1,})"/g,
  },
  {
    name: 'accessibilityLabel="hardcoded"',
    // Matches accessibilityLabel="some text"
    regex: /accessibilityLabel="([A-Za-z][^"]{1,})"/g,
  },
];

// Patterns that are ALLOWED (not violations)
const ALLOWED_PATTERNS = [
  /^[0-9.,\s%$€£¥+\-*/=<>!?@#&()[\]{}|^~`'"\\]+$/, // Numbers and punctuation only
  /^[A-Z_][A-Z0-9_]*$/, // UPPERCASE_CONSTANTS
  /^https?:\/\//i, // URLs
  /^[a-z]+:\/\//i, // Protocol strings
  /^[a-zA-Z0-9-]+$/, // Single words (class names, IDs)
  /^\s*$/, // Whitespace only
  /^[a-z]+$/, // All lowercase single words (likely keys, not user-facing text)
];

// Files/directories to skip
const SKIP_PATTERNS = [
  "node_modules",
  ".git",
  "dist",
  "build",
  "__tests__",
  ".spec.",
  ".test.",
  "EditScreenInfo.tsx", // Unused Expo boilerplate
];

function isAllowedText(text: string): boolean {
  const trimmed = text.trim();
  return ALLOWED_PATTERNS.some((pattern) => pattern.test(trimmed));
}

function shouldSkipFile(filePath: string): boolean {
  return SKIP_PATTERNS.some((pattern) => filePath.includes(pattern));
}

function scanFile(filePath: string): Violation[] {
  const violations: Violation[] = [];
  const content = fs.readFileSync(filePath, "utf8");
  const lines = content.split("\n");

  for (const {
    name, regex 
  } of HARDCODED_TEXT_PATTERNS) {
    const freshRegex = new RegExp(regex.source, regex.flags);
    let match;

    while ((match = freshRegex.exec(content)) !== null) {
      const capturedText = match[1]?.trim();
      if (!capturedText || isAllowedText(capturedText)) continue;

      // Find line number
      const beforeMatch = content.substring(0, match.index);
      const lineNumber = beforeMatch.split("\n").length;
      const lineContent = lines[lineNumber - 1]?.trim() ?? "";

      violations.push({
        file: filePath,
        line: lineNumber,
        content: lineContent,
        pattern: name,
      });
    }
  }

  return violations;
}

function scanDirectory(dirPath: string): Violation[] {
  const violations: Violation[] = [];

  if (!fs.existsSync(dirPath)) {
    return violations;
  }

  const entries = fs.readdirSync(dirPath, { withFileTypes: true });

  for (const entry of entries) {
    const fullPath = path.join(dirPath, entry.name);

    if (shouldSkipFile(fullPath)) continue;

    if (entry.isDirectory()) {
      violations.push(...scanDirectory(fullPath));
    } else if (entry.isFile() && /\.(tsx|jsx)$/.test(entry.name)) {
      violations.push(...scanFile(fullPath));
    }
  }

  return violations;
}

function main() {
  const targetDirs = [
    path.join(process.cwd(), "src", "features"),
    path.join(process.cwd(), "src", "shared"),
    path.join(process.cwd(), "app"),
  ];
  console.log(`\n🔍 Scanning for hardcoded text in:\n${targetDirs.map((d) => `  - ${d}`).join("\n")}\n`);

  const violations = targetDirs.flatMap(scanDirectory);

  if (violations.length === 0) {
    console.log("✅ No hardcoded text found. All UI text uses translations.\n");
    process.exit(0);
  }

  console.error(`❌ Found ${violations.length} hardcoded text violation(s):\n`);

  for (const violation of violations) {
    const relativePath = path.relative(process.cwd(), violation.file);
    console.error(`  📁 ${relativePath}:${violation.line}`);
    console.error(`     Pattern: ${violation.pattern}`);
    console.error(`     Content: ${violation.content}`);
    console.error("");
  }

  console.error(
    "💡 Fix: Replace hardcoded text with t() from react-i18next:\n"
  );
  console.error('   <Text>{t("some.key")}</Text>');
  console.error('   placeholder={t("some.key")}\n');

  process.exit(1);
}

main();
