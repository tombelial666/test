# Technical Decomposition: [Task Name]
**Status**: Technical Review | **Created**: YYYY-MM-DD

**Linked Documentation**:
- Discovery: `./discovery-[feature-name].md` (if exists)
- UI Planning: `./ui-planning-analysis-[feature-name].md` (if exists)
- ADR: `../../docs/adr/NNNN-[decision].md` (if applicable)

---

## Tracking & Progress

### PR Details
- **Branch**: [feat/XXXXX-feature-name]
- **PR URL**: [Added during implementation]
- **Status**: [Draft/Review/Merged]

---

## Primary Objective
[Single clear statement of what we're building technically in MobileLiteApp]

---

## Skill Compliance (for UI/screen tasks)

_Remove this section if not a UI task._

| Skill | Rules Applied |
|-------|--------------|
| `design-tokens` | [e.g., All colors via `useThemeColors()`, no hardcoded hex] |
| `react-native-expo` | [e.g., FlatList for list, SafeAreaView on screen root] |
| `localization` | [e.g., All strings via `t("key")`] |

---

## Test Plan (TDD - Define First)

### Test Strategy
[High-level testing approach: which test types, why, coverage expectations]

**Test commands:**
```bash
# Run targeted tests
npm test -- --testPathPattern="<feature>" --no-coverage 2>&1 | tail -30

# Run all tests
npm test -- --passWithNoTests --silent 2>&1 | tail -20
```

### Test Cases to Implement

#### Test Suite 1: [Feature Area]
**Type**: Unit / Integration
**File**: `tests/unit/<feature>/<File>.spec.ts` OR `tests/integration/<feature>/<File>.integration.spec.tsx`

- [ ] **Test 1.1**: [Test name and what it validates]
  - **Given**: [Initial state / preconditions]
  - **When**: [Action taken]
  - **Then**: [Expected outcome]

- [ ] **Test 1.2**: [Test name and what it validates]
  - **Given**: [Initial state]
  - **When**: [Action taken]
  - **Then**: [Expected outcome]

#### Test Suite 2: [Feature Area]
**Type**: Unit / Integration
**File**: `tests/...`

- [ ] **Test 2.1**: [Test name and what it validates]
  - **Given**: [Initial state]
  - **When**: [Action taken]
  - **Then**: [Expected outcome]

### Coverage Requirements
- All use cases covered by tests
- Error paths tested (network error, 401, 500)
- Edge cases: [List critical edge cases]

---

## Technical Requirements

- [ ] [Specific, measurable technical requirement 1]
- [ ] [Specific, measurable technical requirement 2]
- [ ] No hardcoded colors (use `useThemeColors()` from `@/shared/theme/hooks`)
- [ ] No hardcoded UI strings (use `t("key")` from react-i18next)
- [ ] Layer boundaries respected (features don't import infrastructure)

---

## Implementation Steps & Changelog

### Step 1: [High-level action name]
- [ ] Sub-step 1.1: [Atomic action description]
  - **Layer**: feature / domain / infrastructure / shared / app
  - **Directory**: `src/features/[feature]/` (or relevant path)
  - **Files to modify/create**:
    - `src/features/[feature]/screens/[Screen].tsx` (new)
    - `src/features/[feature]/hooks/queries.ts` (modify)
  - **What to do**:
    - [Specific change 1]
    - [Specific change 2]
  - **Tests**: Reference Test Suite 1 from Test Plan above
  - **Changelog**: [Timestamped record after implementation: YYYY-MM-DDTHH:MMZ — Created/Modified `path/file.tsx`: description]

### Step 2: [High-level action name]
- [ ] Sub-step 2.1: [Atomic action description]
  - **Layer**: [layer]
  - **Directory**: `src/...`
  - **Files to modify/create**:
    - `src/...` (new/modify)
    - `tests/unit/...` (new)
  - **What to do**:
    - [Specific change 1]
  - **Tests**: Reference Test Suite 2 from Test Plan above
  - **Changelog**: [Timestamped record of actual changes made]

---

## Dependencies

- **Technical Dependencies**: [Libraries, services, other features required]
- **Blocked By**: [What must be completed first]
- **Blocks**: [Tasks waiting on this]

---

## Architecture Notes

[Any MobileLiteApp-specific architecture decisions, layer boundary notes, or DI wiring notes]

- Query hooks location: `src/features/[feature]/hooks/queries.ts`
- Repository DI: wired in `src/composition/ApiProvider.tsx`
- [Any other notes]

---

## Success Metrics
- [How we measure technical success]
- All tests pass
- TypeScript: no errors (`npx tsc --noEmit`)
- Lint: no errors (`npm run lint`)

---

## Notes

[Technical decisions, architecture choices, gotchas, or context for developers]

---

## Completion Summary (After implementation)

**Implementation Complete**: [Brief technical description]

**Files Changed**: [count] modified, [count] created

**Tests**: [count] total (unit: [n], integration: [n]) — all passing

**Quality Gate**: PASSED — `npx tsc --noEmit` clean, `npm run lint` clean, `npm test` all pass

**Technical Debt/Follow-ups**: [Any deferred work or improvements needed]
