Здесь результаты: tasks/output/<короткий-id-от-имени-vN>/withF/, withoutF/ и при входе из input/both/ ещё withFThenWithoutF/

Пример: tasks/output/rass-snoski-v1/withF/мой-файл.txt
withFThenWithoutF — финальный текст после withF/, прогнанный без цепочки навыков.

Нельзя: вложенность …/withF/withoutF/ на одном уровне внутри OUT_ID.
Нельзя: путать с tasks/input/…

Устарело: класть файлы прямо в tasks/output/withF/ без папки OUT_ID.

Подробности: .cursor/rules/input-folder-dual-output.mdc
