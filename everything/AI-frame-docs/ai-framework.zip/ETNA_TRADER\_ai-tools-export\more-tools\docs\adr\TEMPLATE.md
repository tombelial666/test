# ADR-NNNN: Title

**Status**: Proposed
**Date**: YYYY-MM-DD

## Context

<!-- What is the issue? Why do we need to decide? (2-4 sentences) -->

## Use Cases

<!-- List specific scenarios that this decision affects -->

- UC1: 
- UC2: 
- UC3: 

## Options Considered

### Option 1: Name

**Pros**:
- 

**Cons**:
- 

### Option 2: Name

**Pros**:
- 

**Cons**:
- 

<!-- Add more options if needed, but keep to realistic alternatives -->

## Decision

<!-- We chose **Option X** because... (1-2 sentences) -->

## Consequences

<!-- What changes as a result of this decision? -->

- 
- 

