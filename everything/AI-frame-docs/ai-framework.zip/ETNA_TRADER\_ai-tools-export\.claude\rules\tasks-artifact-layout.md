# Tasks Artifact Layout Rule

**Version**: 1.0.0 | **Scope**: ETNA_TRADER

## Goal

Enforce a consistent, reproducible layout for all task artifacts created by AI workflow commands (`/ct`, `/qa`, `/sr`, `/si`, `/nf`).

## When to Apply

- When any AI command produces output files
- When reviewing whether a task folder is complete
- Before closing or archiving a task

---

## Folder Naming Convention

All task folders must follow: `tasks/task-YYYY-MM-DD-<kebab-name>/`

```
tasks/task-2026-03-24-margin-balance-fix/
tasks/task-2026-03-24-account-type-validation/
tasks/task-2026-03-19-ai-tools-etna-trader/
```

**Rules:**
- Date must be the task creation date in `YYYY-MM-DD` format
- Name is lowercase kebab-case: words separated by hyphens
- No spaces, no underscores, no uppercase
- Folder must contain at least one substantive document

---

## Mandatory Files by Task Type

### `/ct` — Technical decomposition
Required:
- `tech-decomposition-<name>.md`

Optional:
- `architecture-notes.md`
- `adr/` subfolder for architectural decision records

### `/qa` — QA work
Required:
- `test-plan-<name>.md`
- `test-cases-<name>.md`

Optional but recommended:
- `evidence.md` — actual logs, SQL results, API responses, CI run links
- `automation-notes.md` — Playwright/pytest automation design
- `artifacts/` — screenshots, exported results

### `/sr` — Code review
Required:
- `code-review-<name>.md`

### `/nf` — Feature discovery
Required:
- `discovery-<name>.md`

### `/si` — Implementation
Optional but recommended:
- `implementation-notes-<name>.md`

---

## Evidence Discipline

`evidence.md` must only contain verified, traceable content:

**Allowed:**
- Direct links to CI/CD runs
- Actual log lines (verbatim excerpts, not paraphrased)
- Actual SQL query results
- Actual API responses
- Screenshots with file paths
- Links to Azure DevOps work items

**Not allowed:**
- "Tests passed" without a link or output
- "No issues found" without attached evidence
- Paraphrased log content
- Recalled/assumed results not backed by a tool run

---

## Prohibited Patterns

- No flat files directly in `tasks/` root (only named subdirectories)
- No folders named only by date with no feature name
- No spaces or special characters in folder names
- No nested task folders (one level only)

---

## Non-Standard Folders

Design, research, or architecture exploration folders (e.g., `tasks/строим FrameWork/`) are allowed but must:
- Contain a `README.md` or clearly named document explaining their purpose
- Not be treated as task artifacts by automation scripts
