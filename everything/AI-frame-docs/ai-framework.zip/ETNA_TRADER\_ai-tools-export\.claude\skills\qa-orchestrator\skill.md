---
name: qa-orchestrator
description: >-
  Context-aware entry point for QA work in ETNA_TRADER. Builds a minimal context bundle from
  available sources (task carrier, work item ID, git diff, feature name), classifies intent,
  and routes to the /qa skill with the right mode and grounded context.
  Use when you have a work item ID, task folder path, or need help gathering context before QA work starts.
  For direct QA work when context is already clear, use /qa directly.
argument-hint: "[work-item-id | task-path | feature-name]"
user-invocable: true
---

# QA Orchestrator — ETNA_TRADER

## Purpose

This skill does one thing: **build a minimal, grounded context bundle** and route to the right QA mode.

It exists to solve the "blank page" problem — when you know there's QA work to do but haven't yet gathered what's needed to do it well.

**When to use this instead of `/qa` directly:**
- You have a work item ID but no task folder yet
- You have a task folder but unclear about scope
- Multi-repo or multi-service feature where context is scattered
- First QA engagement on a feature not yet analyzed

**When to use `/qa` directly:**
- Context already gathered (tech-decomposition exists, AC is clear)
- Continuing QA work already in progress
- Quick single test case or automation snippet

---

## Step 1 — Locate context sources

**Check in order. Stop at first hit per category.**

### Requirements source
```
tasks/task-*/tech-decomposition-<feature>.md     ← primary
tasks/task-*/discovery-<feature>.md              ← secondary
[work item description from user]                ← fallback
```

### Changed code source
```bash
git diff --name-only HEAD~1     # or specified base
git log --oneline -5            # recent context
```

### Existing tests source
```
qa/                             ← C# backend tests
qa/qa/Tools/*/tests/            ← Playwright E2E tests
```

### Acceptance criteria
Extract from tech-decomposition or ask user to provide.

---

## Step 2 — Classify intent

Determine what QA output is needed:

| Signal | Mode | Delegate to /qa |
|---|---|---|
| "test plan", "QA for feature", no prior plan | FULL | Mode A |
| "test cases", "TCs" | TCs only | Mode B |
| "automate", "playwright", "pytest", "write test" | AUTOMATION | Mode C |
| "test architecture", "test structure" | ARCHITECTURE | Mode D |
| "coverage", "what's missing", "audit" | COVERAGE REVIEW | Mode E |
| Ambiguous | Ask user | — |

---

## Step 3 — Build context bundle

Collect only what is relevant. Do not load entire repos.

```
context_bundle:
  work_item: <ID or title>
  requirements_source: <path or inline AC>
  changed_files: <list from git diff>
  affected_services: <detected from changed files or stated by user>
  existing_tests: <paths of relevant test files>
  open_questions: <anything unclear before QA can proceed>
```

**Hard rule — evidence gate:**
If requirements/AC cannot be found AND user has not provided them inline:

> ⚠️ No acceptance criteria found. Proceeding based on code analysis only.
> Verify all test cases against requirements before use.
> Open questions: [list what is missing]

Do not silently proceed — make the gap visible.

---

## Step 4 — Route to /qa

Pass the context bundle to `/qa` with explicit mode:

```
Invoke /qa with:
  mode: [A|B|C|D|E]
  task_dir: tasks/task-<date>-<name>/  (create if not exists)
  context: [bundle from Step 3]
  grounding_note: [what was found vs. what is assumed]
```

---

## Step 5 — Validate output

Before returning to user, check:

- [ ] Every test case references at least one requirement or AC
- [ ] Coverage claims are based on actual test file inspection, not assumptions
- [ ] All unverified locators/endpoints are marked `[PSEUDOCODE]`
- [ ] All unresolved questions are listed as `[OPEN QUESTION]`
- [ ] Output is saved to `tasks/task-<date>-<name>/` with correct filenames
- [ ] `evidence.md` contains only traceable artifacts (no "tests passed" without links)

---

## Task Carrier support (when available)

If a `.aiqa/tasks/<ID>/task.yaml` carrier file exists:

1. Read `task.yaml` — extract goal, done_definition, scope, ownership
2. Use `scope.repos` and `scope.services` to narrow context bundle
3. Use `context.qa_evidence` section to check what evidence already exists
4. Write QA outputs back to `task.yaml` under `qa.test_plan_ref`, `qa.test_cases_ref`, `qa.evidence`
5. Append to `context.qa_evidence.test_runs` after each test run

If no carrier exists: proceed with Steps 1–5 above (task folder convention).

---

## Constraints

- Never generate test cases without grounding in provided context (AC, code, or tech-decomposition)
- Never claim coverage without reading actual test files
- Never assume endpoint URLs, field names, or role names — ask or mark as `[UNDEF]`
- Authorization/ownership checks are **mandatory** for any trading system test — flag as CRITICAL gap if missing
- External repos (mobileLiteApp, etc.) are read-only diagnostic context only
