# Discovery: [Feature Name]

**Created**: YYYY-MM-DD
**Status**: Draft | Approved

---

## Feature Overview
[High-level description of the feature and its purpose in MobileLiteApp]

### Goals
- [Goal 1]
- [Goal 2]

---

## Selected Approach
[Brief description of the chosen approach from brainstorming alternatives]

### Alternatives Considered
| Approach | Pros | Cons | Decision |
|----------|------|------|----------|
| [Approach 1] | [...] | [...] | Selected/Rejected |
| [Approach 2] | [...] | [...] | Selected/Rejected |

---

## Requirements

### Functional Requirements
- [ ] [Requirement 1]
- [ ] [Requirement 2]

### Non-Functional Requirements
- [ ] [Performance, security, accessibility, offline behavior]

---

## Technical Considerations

### Architecture Impact
- Layer(s) affected: [features / domain / infrastructure / composition]
- New feature folder: `src/features/[feature-name]/`
- State: [React Query for server state / Zustand for global state / local useState]
- HTTP: [Primary API / Secondary API / both]

### Integration Points
- Existing features that interact with this: [list]
- Shared components needed: [list or "none"]

### Dependencies
- External libraries: [list or "none"]
- Other features that must exist first: [list or "none"]

---

## UI/UX Specifications

### Screens
| Screen | Route | Purpose |
|--------|-------|---------|
| [ScreenName] | /(tabs)/[route] | [purpose] |

### Key Interactions
- [User flow 1]
- [User flow 2]

### Visual Requirements
- Loading states: [how loading is shown]
- Error states: [how errors are shown]
- Empty states: [how empty data is shown]

### Mobile-Specific
- Safe area handling: [yes/no, where]
- Keyboard behavior: [KeyboardAvoidingView needed?]
- Accessibility: [notes]

---

## Skill Compliance

_This section is filled when design exploration confirms the feature touches UI._

- **`design-tokens`**: Read and applied — all colors via `useThemeColors()`
- **`react-native-expo`**: Read and applied — [specific rules applied]
- **`localization`**: Read and applied — all strings via `t("key")`

---

## Edge Cases & Error Handling
- [Edge case 1]: [How to handle]
- [Network error]: [Recovery approach]
- [Auth error (401)]: [Handled by interceptor / explicit UI]

---

## Success Metrics
- [Metric 1]: [Target]

---

## Open Questions
- [ ] [Unresolved question 1]
- [ ] [Unresolved question 2]

---

## Notes
[Additional context from discovery process]
