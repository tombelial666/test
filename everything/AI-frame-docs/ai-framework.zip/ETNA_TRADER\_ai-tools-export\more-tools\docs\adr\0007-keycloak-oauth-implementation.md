# ADR-0007: Keycloak OAuth2/OIDC Authentication Implementation

**Status**: Accepted
**Date**: 2026-01-09

## Context

The app needs to support enterprise SSO scenarios via Keycloak in addition to the existing Public API authentication. Different deployments require different identity providers: simple deployments use Public API (direct username/password), while enterprise deployments require Keycloak for centralized identity management, SSO, MFA, and social login providers.

## Use Cases

- UC1: Enterprise customers require SSO across multiple applications (mobile, web, desktop)
- UC2: Organizations need centralized user management with role-based access control
- UC3: Users should not re-enter credentials if already authenticated in another app (SSO)
- UC4: Access tokens must automatically refresh without user interaction when expired
- UC5: Logout must invalidate tokens server-side, not just locally

## Options Considered

### Option 1: Embed Keycloak SDK in Repository

Integrate a full Keycloak SDK (keycloak-js or similar) directly into the repository layer.

**Pros**:
- Turnkey solution with built-in token management
- Less code to write initially

**Cons**:
- Heavy dependency (large bundle size)
- Keycloak SDK designed for web browsers, not React Native
- Breaks clean architecture (repository depends on heavy external SDK)
- Limited control over OAuth flow and token refresh logic
- Harder to test and mock

### Option 2: Use expo-auth-session with Custom Repository

Implement OAuth2/OIDC flow using expo-auth-session for OAuth primitives (authorize, token exchange) while building a custom repository that implements `IAuthService` interface.

**Pros**:
- expo-auth-session is lightweight, designed for React Native
- Full control over token refresh and storage logic
- Maintains clean architecture (repository implements domain port)
- Standard OAuth2/OIDC flow (no vendor lock-in)
- Easy to test with mocked dependencies
- Reuses existing token storage infrastructure (TokenStore + SecureStore)

**Cons**:
- More code to write manually (OAuth flow, token refresh)
- Need to understand OAuth2/OIDC standards

### Option 3: Separate OAuth Service Layer

Create a dedicated OAuth service layer between features and repositories, handling OAuth flows independently from auth repositories.

**Pros**:
- Clear separation of concerns (OAuth vs auth logic)
- Could support multiple OAuth providers easily

**Cons**:
- Adds complexity (another layer)
- Violates YAGNI (we only need Keycloak, not multiple OAuth providers)
- Harder for features to consume (two APIs instead of one)

## Decision

We chose **Option 2: expo-auth-session with Custom Repository** because:

1. **Maintains Clean Architecture**: `KeycloakAuthRepository` implements `IAuthService`, just like `PublicApiAuthRepository`. Features depend only on the interface.
2. **Reuses Infrastructure**: Same token storage (TokenStore + SecureStore) for both auth strategies
3. **Lightweight & Native**: expo-auth-session is specifically designed for React Native OAuth flows
4. **Full Control**: We control token refresh timing, error handling, and retry logic
5. **Testable**: Easy to mock OAuth primitives and test repository logic in isolation

## Consequences

### What Becomes Easier

- **Seamless Strategy Switching**: `AuthProvider` selects repository based on `useKeyCloakAuth` flag; features remain unchanged
- **Consistent Token Storage**: Both Public API and Keycloak use same TokenStore + SecureStore infrastructure
- **Automatic Token Refresh**: HTTP interceptor detects 401, triggers refresh, retries request transparently
- **Testing**: Mock OAuth primitives in tests; repository logic testable independently

### What Becomes Harder

- **Initial Implementation**: Must manually implement OAuth2 Authorization Code Flow with PKCE
- **Token Refresh Logic**: Must build retry mechanism with exponential backoff
- **OAuth State Management**: Must handle authorization request state (PKCE verifier, state param)

### Follow-Up Actions

1. ✅ Install `expo-auth-session` dependency
2. ✅ Create `KeycloakAuthRepository` implementing `IAuthService`
3. ✅ Implement token refresh logic in repository (use refresh token to get new access token)
4. ✅ Update `AuthProvider` to instantiate `KeycloakAuthRepository` when `useKeyCloakAuth === true`
5. ✅ Create `useKeycloakLoginMutation` hook (similar to `useLoginMutation` but triggers OAuth flow)
6. ✅ Update `SignInKeycloakForm` to use OAuth redirect flow
7. ✅ Add HTTP interceptor logic for automatic token refresh on 401
8. ✅ Store refresh token separately in SecureStore (not in memory)
9. ✅ Create unit tests for `KeycloakAuthRepository` with mocked expo-auth-session
10. ✅ Create integration tests for Keycloak login/logout/refresh flows

### Related ADRs

- [ADR-0002: AppInitializationProvider](./0002-app-initialization-provider.md) — Session restoration includes Keycloak token validation

