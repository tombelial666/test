<#
.SYNOPSIS
  Validates tasks/output layout (input-folder-dual-output rules).

.DESCRIPTION
  Mirrors tests/test_tasks_output_layout.py without Python.
  Exit 0 = OK, 1 = violations.

.EXAMPLE
  powershell -File tools/verify-tasks-output-layout.ps1
#>
$ErrorActionPreference = "Stop"
$repoRoot = Split-Path $PSScriptRoot -Parent
$tasksOutput = Join-Path $repoRoot "tasks\output"
$tasksInputBoth = Join-Path $repoRoot "tasks\input\both"

function Write-Fail([string]$Message) {
    Write-Error $Message -ErrorAction Continue
    $script:Failed = $true
}

$Failed = $false

if (-not (Test-Path $tasksOutput -PathType Container)) {
    Write-Fail "Missing directory: $tasksOutput"
    exit 1
}

Get-ChildItem $tasksOutput -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    if ($_.Name -in @("withF", "withoutF")) {
        Write-Fail "Forbidden flat folder tasks/output/$($_.Name)/ (must use OUT_ID parent)"
    }
}

$outIdRegex = '^.+[-]v\d+$'
Get-ChildItem $tasksOutput -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    if ($_.Name -notmatch $outIdRegex) {
        Write-Fail "tasks/output child must be <slug>-vN>, got: $($_.Name)"
    }
}

Get-ChildItem $tasksOutput -Recurse -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    $parts = $_.FullName.Split([IO.Path]::DirectorySeparatorChar, [StringSplitOptions]::RemoveEmptyEntries)
    for ($i = 0; $i -lt $parts.Count - 1; $i++) {
        if ($parts[$i] -eq "withF" -and $parts[$i + 1] -eq "withoutF") {
            Write-Fail "Forbidden nesting withF/withoutF at $($_.FullName)"
        }
        if ($parts[$i] -eq "withoutF" -and $parts[$i + 1] -eq "withF") {
            Write-Fail "Forbidden nesting withoutF/withF at $($_.FullName)"
        }
    }
}

$allowedBranches = @("withoutF", "withF", "withFThenWithoutF")
Get-ChildItem $tasksOutput -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match $outIdRegex } | ForEach-Object {
    $outId = $_
    Get-ChildItem $outId.FullName -Directory -ErrorAction SilentlyContinue | ForEach-Object {
        if ($allowedBranches -notcontains $_.Name) {
            Write-Fail "Unexpected branch '$($_.Name)' under $($outId.FullName)"
        }
    }
}

if (Test-Path $tasksInputBoth -PathType Container) {
    Get-ChildItem $tasksInputBoth -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -notlike ".*" } | ForEach-Object {
        $base = if ($_.Extension) { $_.BaseName } else { $_.Name }
        $slug = ($base.ToLowerInvariant() -replace "\s+", "-")
        foreach ($ch in @('<', '>', ':', '"', '/', '\', '|', '?', '*')) {
            $slug = $slug.Replace([string]$ch, "")
        }
        if ($slug.Length -gt 28) { $slug = $slug.Substring(0, 28).TrimEnd("-") }
        if (-not $slug) { $slug = "file" }

        $matches = Get-ChildItem $tasksOutput -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like "$slug-v*" }
        if (-not $matches) {
            Write-Fail ("both/{0}: expected tasks/output/{1}-v*/ (slug from filename)" -f $_.Name, $slug)
            return
        }
        $okAny = $false
        foreach ($dir in $matches) {
            $allOk = $true
            foreach ($b in $allowedBranches) {
                $bd = Join-Path $dir.FullName $b
                if (-not (Test-Path $bd -PathType Container)) { $allOk = $false; break }
                $files = Get-ChildItem $bd -File -Recurse -ErrorAction SilentlyContinue
                if (-not $files -or $files.Count -eq 0) { $allOk = $false; break }
            }
            if ($allOk) { $okAny = $true; break }
        }
        if (-not $okAny) {
            $names = ($matches | ForEach-Object { $_.Name }) -join ', '
            Write-Fail ("both/{0}: no OUT_ID with three non-empty branches (checked: {1})" -f $_.Name, $names)
        }
    }
}

if ($Failed) { exit 1 }
exit 0
