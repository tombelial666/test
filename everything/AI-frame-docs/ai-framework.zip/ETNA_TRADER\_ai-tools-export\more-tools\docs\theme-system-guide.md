# Theme System Guide

Complete guide to understanding and using the theme system in Mobile Lite App.

## Table of Contents

- [First App Launch - Theme Selection](#first-app-launch---theme-selection)
- [Disabling Dark Theme](#disabling-dark-theme)
- [Runtime Theme Changes](#runtime-theme-changes)
- [Color System Step-by-Step](#color-system-step-by-step)
- [Adding a New Brand](#adding-a-new-brand)
- [Quick Reference](#quick-reference)

---

## First App Launch - Theme Selection

On first launch, the theme is resolved by this priority order:

1. **Manual Override** (AsyncStorage key `@theme_preference`)
2. **System Theme** (via React Native `useColorScheme()`)
3. **Light Theme** (fallback)

**Implementation:** `src/shared/theme/ThemeProvider.tsx`

Simplified logic:

```ts
// src/shared/theme/ThemeProvider.tsx (simplified)
const systemColorScheme = useColorScheme();
const [manualTheme, setManualTheme] = useState<ThemeName | null>(null);

const theme: ThemeName = manualTheme ?? (systemColorScheme ?? "light");
```

---

## Disabling Dark Theme

To force the app to always use light theme, edit `src/shared/theme/ThemeProvider.tsx` and always resolve `theme` to `"light"` (ignore manual and system theme).

---

## Runtime Theme Changes

Use the `useTheme()` hook to switch theme at runtime:

```ts
import { useTheme } from "@/shared/theme/hooks";

const { theme, isDark, setTheme, toggleTheme, resetToSystem } = useTheme();

setTheme("light");
setTheme("dark");
resetToSystem(); // Auto (system)
toggleTheme();   // light ↔ dark
```

Manual selections persist via AsyncStorage key `@theme_preference`.

---

## Color System Step-by-Step

### 1) Never hardcode colors in TS/TSX

Use design tokens everywhere in UI code:

```tsx
import { useThemeColors } from "@/shared/theme/hooks";

export function MyComponent() {
  const colors = useThemeColors();
  return <View style={{ backgroundColor: colors.background.base }} />;
}
```

### 2) Where tokens live

- Base tokens:
  - `src/shared/theme/tokens/light.ts`
  - `src/shared/theme/tokens/dark.ts`
- Brand overrides (optional):
  - `src/shared/brand/*/colors.ts`

Hex/rgb values are allowed only in the files above (and tests).

For the full token reference and naming conventions, see `docs/design-tokens.md`.

---

## Adding a New Brand

There are two separate concerns:

1) **White-label app config + assets** (app name, scheme, icons, splash, EAS profiles)  
2) **Design token overrides** (optional per brand)

### 1) White-label app config + assets

Recommended:

```bash
npm run add-new-brand
```

This updates:
- `brand-config.js`
- `assets/brands/<brand>/`
- `package.json` scripts
- `eas.json` profiles

Then run:
- `npm run start:<brand>:dev` (preferred), or:
- `BRAND=<brand> APP_ENV=development npm start`

### 2) Brand design token overrides (optional)

Create `src/shared/brand/<brand>/colors.ts` (copy an existing brand file and override only the tokens you need):

```ts
import type { DesignTokens } from "@/shared/theme/tokens/types";
import { tokens as baseTokens } from "@/shared/theme/tokens";

export const colors: DesignTokens = {
  ...baseTokens,
  // Add overrides here
};
```

Wire token selection/export in `src/shared/brand/index.ts` (currently build-time selection via import).

---

## Quick Reference

**Key files:**

- Theme context/provider: `src/shared/theme/ThemeProvider.tsx`
- Theme hooks: `src/shared/theme/hooks/useTheme.ts`, `src/shared/theme/hooks/useThemeColors.ts`
- Tokens: `src/shared/theme/tokens/light.ts`, `src/shared/theme/tokens/dark.ts`
- Brand token overrides: `src/shared/brand/*/colors.ts`
- White-label brands: `brand-config.js`, `assets/brands/`

**Related docs:**

- `docs/design-tokens.md`
- `docs/white-label-configuration.md`
- `docs/project-structure.md`

---

**Last Updated:** 2026-02-27
