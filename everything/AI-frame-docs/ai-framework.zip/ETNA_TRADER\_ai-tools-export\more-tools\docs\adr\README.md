# Architecture Decision Records (ADR)

## What is ADR?

ADR is a lightweight format for capturing important architectural and technical decisions along with their context and consequences.

## Why ADR?

- **Memory**: We forget *why* we made decisions weeks/months later
- **Onboarding**: New team members understand rationale quickly
- **AI Context**: Agents can reference decisions during implementation
- **Avoid Re-debates**: Documented reasoning prevents circular discussions

## File Naming

```
NNNN-short-title.md
```

Examples:
- `0001-use-zustand-for-global-state.md`
- `0002-axios-over-fetch.md`
- `0003-react-query-caching-strategy.md`

## ADR Template

Each ADR follows this structure (keep it concise — 1-2 min read):

```markdown
# ADR-NNNN: Title

**Status**: Proposed | Accepted | Deprecated | Superseded by ADR-XXXX
**Date**: YYYY-MM-DD

## Context

What is the issue? Why do we need to decide?
(2-4 sentences max)

## Use Cases

- UC1: Brief description
- UC2: Brief description
- UC3: ...

## Options Considered

### Option 1: Name
**Pros**: ...
**Cons**: ...

### Option 2: Name
**Pros**: ...
**Cons**: ...

### Option 3: Name (if applicable)
**Pros**: ...
**Cons**: ...

## Decision

We chose **Option X** because...
(1-2 sentences)

## Consequences

- What becomes easier
- What becomes harder
- Any follow-up actions needed
```

## Guidelines

1. **Be concise** — If it takes >2 min to read, it's too long
2. **Focus on "why"** — The "what" is in the code
3. **Include real alternatives** — Don't pad with straw-man options
4. **Date your decisions** — Context changes over time
5. **Link related ADRs** — Decisions often build on each other

## When to Create ADR

✅ Create ADR for:
- Technology/library choices
- Architectural patterns
- API design decisions
- Breaking changes to conventions
- Trade-offs with long-term impact

❌ Skip ADR for:
- Implementation details
- Bug fixes
- Obvious choices with no alternatives
- Temporary solutions

## Index

| # | Title | Status | Date |
|---|-------|--------|------|
| [0001](./0001-api-versioning-strategy.md) | API Versioning Strategy | Accepted | 2025-12-03 |
| [0002](./0002-app-initialization-provider.md) | AppInitializationProvider for Startup Orchestration | Proposed | 2025-12-07 |
| [0003](./0003-environment-variable-validation.md) | Environment Variable Runtime Validation | Accepted | 2025-12-08 |
| [0004](./0004-mobile-settings-value-object.md) | MobileSettings as Value Object | Accepted | 2025-12-10 |
| [0006](./0006-navigation-layout-and-header-architecture.md) | Navigation Layout and Header Architecture | Accepted | 2025-12-29 |
| [0007](./0007-keycloak-oauth-implementation.md) | Keycloak OAuth2/OIDC Authentication Implementation | Accepted | 2026-01-09 |
| [0008](./0008-design-tokens-system.md) | Design Tokens System | Accepted | 2026-02-06 |
| [0009](./0009-localization-strategy.md) | Localization Strategy | Accepted | 2026-02-12 |

---

*To create a new ADR, copy the template above or use `docs/adr/TEMPLATE.md`*

