"""Проверки структуры каталогов (логика из .cursor/rules/input-folder-dual-output.mdc)."""

from __future__ import annotations

import re
from pathlib import Path

# OUT_ID: <slug>-v<цифры>
OUT_ID_PATTERN = re.compile(r"^.+-v\d+$")

ALLOWED_BRANCHES_BOTH = frozenset({"withoutF", "withF", "withFThenWithoutF"})
ALLOWED_BRANCHES_WITHF_ONLY = frozenset({"withF"})
ALLOWED_BRANCHES_WITHOUTF_ONLY = frozenset({"withoutF"})


def stem_from_input_path(path: Path) -> str:
    """Базовое имя исходника (как в правилах: имя файла без расширения)."""
    if path.is_file():
        return path.stem if path.suffix else path.name
    return path.name


def slug_from_stem(stem: str) -> str:
    """
    Упрощённый slug для сопоставления с OUT_ID (латиница/цифры/дефис).
    Для имён вроде «test» совпадает с ожидаемой папкой test-v1.
    """
    s = stem.strip().lower().replace(" ", "-")
    for ch in '<>:"/\\|?*':
        s = s.replace(ch, "")
    return s[:28].rstrip("-") or "file"


def iter_out_ids(tasks_output: Path) -> list[Path]:
    if not tasks_output.is_dir():
        return []
    return sorted(
        p for p in tasks_output.iterdir() if p.is_dir() and OUT_ID_PATTERN.match(p.name)
    )


def out_dirs_for_slug(tasks_output: Path, slug: str) -> list[Path]:
    """Папки tasks/output/<slug>-vN/."""
    return sorted(tasks_output.glob(f"{slug}-v*"))


def path_has_forbidden_withF_withoutF_nesting(path: Path) -> bool:
    """Запрещено: …/withF/withoutF/ и …/withoutF/withF/ как соседние сегменты."""
    parts = path.parts
    for i in range(len(parts) - 1):
        if parts[i] == "withF" and parts[i + 1] == "withoutF":
            return True
        if parts[i] == "withoutF" and parts[i + 1] == "withF":
            return True
    return False


def branch_dirs_nonempty(out_id_dir: Path, branches: frozenset[str]) -> dict[str, bool]:
    """У каждой ветки есть хотя бы один файл (не пустая выдача)."""
    result: dict[str, bool] = {}
    for name in branches:
        d = out_id_dir / name
        if not d.is_dir():
            result[name] = False
            continue
        has_file = any(p.is_file() for p in d.rglob("*"))
        result[name] = has_file
    return result


def allowed_branches_for_out_id(
    out_id_dir: Path,
    tasks_input: Path,
    slug: str,
) -> frozenset[str] | None:
    """
    Ожидаемый набор веток по расположению исходника с тем же базовым slug.
    None — если исходник не найден ни в одной из подпапок input.
    """
    for sub, allowed in (
        ("both", ALLOWED_BRANCHES_BOTH),
        ("withF", ALLOWED_BRANCHES_WITHF_ONLY),
        ("withoutF", ALLOWED_BRANCHES_WITHOUTF_ONLY),
    ):
        folder = tasks_input / sub
        if not folder.is_dir():
            continue
        for p in folder.iterdir():
            if not p.is_file():
                continue
            if slug_from_stem(stem_from_input_path(p)) == slug:
                return allowed
    return None
