# Brand & File Locations Reference

## Key Files

| File | Purpose |
|------|---------|
| `src/shared/theme/hooks/useThemeColors.ts` | `useThemeColors()` hook |
| `src/shared/theme/hooks/useTheme.ts` | `useTheme()` hook |
| `src/shared/theme/ThemeProvider.tsx` | Theme context provider (shared) |
| `src/composition/ThemeProvider.tsx` | Composition re-export (used by `app/_layout.tsx`) |
| `src/shared/theme/tokens/light.ts` | Light theme tokens (hex allowed here) |
| `src/shared/theme/tokens/dark.ts` | Dark theme tokens (hex allowed here) |
| `src/shared/theme/tokens/types.ts` | TypeScript token types |
| `src/shared/brand/etna/colors.ts` | ETNA token overrides (optional) |
| `src/shared/brand/sogo/colors.ts` | Sogo token overrides (optional) |
| `src/shared/brand/index.ts` | Brand token selection/export |

Hex/rgb values are **only** allowed in:
- `src/shared/theme/tokens/light.ts`
- `src/shared/theme/tokens/dark.ts`
- `src/shared/brand/*/colors.ts`

---

## Adding a New Brand

Full guide: `docs/white-label-configuration.md`

1. Add brand assets/config (recommended):
   - Run: `npm run add-new-brand`
   - This updates: `brand-config.js`, `assets/brands/<brand>/`, `package.json` scripts, `eas.json`

2. Add optional token overrides:
   - Create: `src/shared/brand/<brand>/colors.ts` (copy from `etna/colors.ts` and override tokens as needed)

3. Wire token export/selection:
   - Update: `src/shared/brand/index.ts` (currently build-time selection via import)

4. Run the app with the brand:
   - `npm run start:<brand>:dev` (preferred), or:
   - `BRAND=<brand> APP_ENV=development npm start`

---

## Theme Resolution Priority

1. Manual override — stored in `AsyncStorage` key `@theme_preference`
2. System theme — detected via `useColorScheme()`
3. Light — default fallback

`resetToSystem()` from `useTheme()` clears the manual override.

---

## Provider Placement

`ThemeProvider` wraps the entire app in `app/_layout.tsx`:

```tsx
<AuthProvider>
  <ThemeProvider>     ← must be inside AuthProvider, outside content
    <ToastProvider>
      <RootLayoutNav />
    </ToastProvider>
  </ThemeProvider>
</AuthProvider>
```
