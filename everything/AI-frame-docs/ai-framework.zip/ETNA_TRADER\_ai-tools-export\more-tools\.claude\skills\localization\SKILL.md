---
name: localization
description: "i18n/localization rules for the Mobile Lite App. This skill should be used when adding any UI text, labels, button titles, placeholders, or error messages to a component; creating a new screen or feature with visible text content; reviewing code for hardcoded strings; adding a new translation key or a new language; or investigating missing/inconsistent translations. CRITICAL: All UI text must use t(\"key\") from react-i18next — never hardcode strings in components."
---

# Localization (i18n)

All user-visible text in the app must be translated across 6 languages. Never hardcode strings in components.

Detailed reference → `references/languages-and-architecture.md`

---

## Core Rule

```tsx
// ✅ Always
import { useTranslation } from "react-i18next";

function MyComponent() {
  const { t } = useTranslation();
  return <Text>{t("profile.title")}</Text>;
}

// ❌ Never — blocked by pre-commit and CI/CD
function MyComponent() {
  return <Text>Profile</Text>;
}
```

---

## Adding a New Translation Key

### Step 1 — Add to English first (source of truth)

```json
// src/shared/localization/locales/en/common.json
{
  "myFeature": {
    "title": "My Feature",
    "description": "This is my feature",
    "saveButton": "Save"
  }
}
```

### Step 2 — Add to ALL 5 other languages simultaneously

```json
// es/common.json
{ "myFeature": { "title": "Mi característica", "description": "Esta es mi característica", "saveButton": "Guardar" } }

// zh-TW/common.json
{ "myFeature": { "title": "我的功能", "description": "這是我的功能", "saveButton": "儲存" } }

// zh-CN/common.json
{ "myFeature": { "title": "我的功能", "description": "这是我的功能", "saveButton": "保存" } }

// ru/common.json
{ "myFeature": { "title": "Моя функция", "description": "Это моя функция", "saveButton": "Сохранить" } }

// fr/common.json
{ "myFeature": { "title": "Ma fonctionnalité", "description": "Ceci est ma fonctionnalité", "saveButton": "Enregistrer" } }
```

### Step 3 — Validate

```bash
npm run i18n:validate-keys
```

---

## Key Naming Convention

Use dot-notation with camelCase. Group by feature:

```
profile.title           → "Profile"
auth.signIn             → "Sign In"
auth.error.invalidCreds → "Invalid credentials"
common.cancel           → "Cancel"
common.save             → "Save"
common.loading          → "Loading..."
```

---

## Usage Patterns

### With interpolation

```tsx
// Translation: "greeting": "Hello, {{name}}!"
t("greeting", { name: "Alice" }) // → "Hello, Alice!"
```

### With explicit namespace (default is "common")

```tsx
const { t } = useTranslation("common");
const label = t("languages.english"); // → "English"
```

---

## Changing Language Programmatically

```tsx
import { useStore } from "@/store";

function LanguageSelector() {
  const setLocale = useStore((state) => state.setLocale);

  return (
    <Button title="Español" onPress={() => setLocale("es")} />
  );
  // setLocale updates store + AsyncStorage + i18n simultaneously
}
```

---

## Validation Commands

```bash
# Check for hardcoded text (blocks commit if violations found)
npm run i18n:validate-hardcoded

# Check key consistency across all 6 languages (warning mode)
npm run i18n:validate-keys

# Strict mode — blocks if any keys missing (used in CI/CD)
npm run i18n:validate-keys:strict

# Run all validations
npm run i18n:validate
```

---

## Rules Checklist

- [ ] No hardcoded strings in TSX/TS component files
- [ ] New key added to **all 6** language files
- [ ] Key follows `feature.element` dot-notation camelCase
- [ ] `npm run i18n:validate-keys` passes with no errors

---

## ADR Reference

- [ADR-0009: Localization Strategy](../../../docs/adr/0009-localization-strategy.md) — decision context, supported languages, tooling choices, and key naming conventions.
